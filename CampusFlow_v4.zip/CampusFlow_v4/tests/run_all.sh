#!/bin/bash
# Lance toutes les suites de tests CampusFlow et écrit les résultats dans tests/results/
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; OUT="$ROOT/tests/results"; mkdir -p "$OUT"
echo "== 1. Base de données (RLS, triggers, RPC) =="; (cd "$ROOT/tests" && node db/test_db.mjs ../supabase/migrations) > "$OUT/db.txt" 2>&1; tail -1 "$OUT/db.txt"
echo "== 1b. Base de données — plateforme double (surveillance, séances, rendus, annonces…) =="; (cd "$ROOT/tests" && node db/test_platform.mjs ../supabase/migrations) > "$OUT/db_platform.txt" 2>&1; tail -1 "$OUT/db_platform.txt"
echo "== 2. Fonctions Edge (assistant IA, invitations) =="; (cd "$ROOT/tests" && node --experimental-strip-types --no-warnings --test functions/ai.test.ts functions/admin-users.test.ts) > "$OUT/functions.txt" 2>&1; grep -E "^# (pass|fail)" "$OUT/functions.txt"
echo "== 3. Unitaires front (dates, XSS, traductions FR/AR) =="; (cd "$ROOT/app" && node --test tests/unit/*.test.js) > "$OUT/unit.txt" 2>&1; grep -E "^# (pass|fail)" "$OUT/unit.txt"
echo "== 4. Build de production =="; (cd "$ROOT/app" && VITE_SUPABASE_URL=https://example.supabase.co VITE_SUPABASE_ANON_KEY=public-anon-placeholder npx vite build) > "$OUT/build.txt" 2>&1; tail -4 "$OUT/build.txt"
echo "== 5. Bout en bout (Chrome + Postgres) =="
(cd "$ROOT/app" && npx vite build --mode e2e --outDir dist-e2e >/dev/null 2>&1)
(cd "$ROOT/tests/e2e" && PORT=5555 node server.mjs > /tmp/cf-e2e-server.log 2>&1 &)
(cd "$ROOT/app/dist-e2e" && python3 -m http.server 5173 > /dev/null 2>&1 &)
for i in $(seq 1 40); do curl -s localhost:5555/changes >/dev/null && curl -s localhost:5173 >/dev/null && break; sleep 0.5; done
(cd "$ROOT/tests/e2e" && timeout 600 python3 e2e.py) > "$OUT/e2e.txt" 2>&1; tail -1 "$OUT/e2e.txt"
pkill -f "node server.mjs"; pkill -f "http.server 5173"
