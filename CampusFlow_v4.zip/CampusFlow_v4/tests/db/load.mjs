import { makeDb } from './pg.mjs';
const db = await makeDb(process.argv[2]);
const r = await db.query(`select count(*)::int n from information_schema.tables where table_schema='public'`);
console.log('migrations OK · tables/views:', r.rows[0].n);
