// Tests de la migration 0008 (plateforme double) : surveillant général, séances annulées, annonces brouillon/programmées/ciblées,
// rendus + retours, calendrier, contacts de covoiturage, restauration de version, notifications des formateurs, rapports.
import { makeDb, asUser } from './pg.mjs';

const db = await makeDb(process.argv[2] || '../supabase/migrations');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('✅ ' + m); } else { fail++; console.log('❌ FAIL ' + m); } };
const err = async (p) => { try { await p; return null; } catch (e) { return e.message; } };
const as = (uid, sql, params) => asUser(db, uid, sql, params);
const one = async (uid, sql, params) => (await as(uid, sql, params)).rows[0];
const su = async (sql, params) => (await db.query(sql, params)).rows;

const G = Object.fromEntries((await su(`select code, id, join_code from public.groups`)).map((r) => [r.code, r]));
const M = Object.fromEntries((await su(`select code, id from public.modules`)).map((r) => [r.code, r.id]));
const R = Object.fromEntries((await su(`select name, id from public.rooms`)).map((r) => [r.name, r.id]));
const signup = async (email, name, meta = {}) => (await su(`insert into auth.users (email, raw_user_meta_data) values ($1, $2) returning id`, [email, { full_name: name, ...meta }]))[0].id;
await su(`insert into public.roster (email, full_name, role) values ('admin@cmc.ma','Admin','admin'), ('surv@cmc.ma','Surveillant','supervisor'), ('benali@cmc.ma','Benali','teacher'), ('idrissi@cmc.ma','Idrissi','teacher')`);
const admin = await signup('admin@cmc.ma', 'Admin');
const surv = await signup('surv@cmc.ma', 'Surveillant');
const tB = await signup('benali@cmc.ma', 'Benali');
const tI = await signup('idrissi@cmc.ma', 'Idrissi');
const yas = await signup('yassine@cmc.ma', 'Yassine', { join_code: G.ID101.join_code });
const sal = await signup('salma@cmc.ma', 'Salma', { join_code: G.ID101.join_code });
const hib = await signup('hiba@cmc.ma', 'Hiba', { join_code: G.ID102.join_code });
await as(admin, `insert into public.teaching_assignments (group_id, module_id, teacher_id) values ($1,$2,$3), ($4,$5,$6)`, [G.ID101.id, M.M101, tB, G.ID102.id, M.M102, tI]);

// ---------- Rôle surveillant ----------
ok((await su(`select role::text r from public.profiles where id = $1`, [surv]))[0].r === 'supervisor', 'surveillant créé via la liste pré-inscrite');
ok((await one(surv, `select public.my_access() a`)).a.staff === true && (await one(surv, `select public.my_access() a`)).a.admin === false, 'my_access : personnel, non administrateur');
ok((await one(yas, `select public.my_access() a`)).a.staff === false, 'my_access : stagiaire non personnel');
ok((await as(surv, `select id from public.profiles where role = 'student'`)).rows.length === 3, 'surveillant : voit tous les stagiaires');
ok(!!(await err(as(surv, `insert into public.timetable_drafts (group_id, module_id, weekday, start_time, end_time) values ($1,$2,1,'08:30','10:30')`, [G.ID101.id, M.M101]))), 'surveillant : ne modifie pas l\'emploi du temps');
ok(!!(await err(as(surv, `select public.admin_set_role($1, 'teacher')`, [yas]))), 'surveillant : ne gère pas les rôles');
ok(!!(await err(as(surv, `insert into public.groups (code, label) values ('XX1', 'Pirate')`))), 'surveillant : ne crée pas de groupe');
ok((await as(surv, `select * from public.audit_log`)).rows.length === 0, 'surveillant : pas d\'accès au journal d\'audit');

// Emploi du temps publié (lundi + jour courant) pour les tests suivants
const today = (await su(`select public.local_today()::text d, extract(isodow from public.local_today())::int w`))[0];
const wd = today.w === 7 ? 1 : today.w;
await as(admin, `insert into public.timetable_drafts (group_id, module_id, teacher_id, room_id, weekday, start_time, end_time) values ($1,$2,$3,$4,$5,'08:30','10:30'), ($1,$6,null,$7,$5,'10:45','12:45')`,
  [G.ID101.id, M.M101, tB, R['Labo 1'], wd, M.M107, R['Salle 8']]);
const v1 = (await one(admin, `select public.publish_timetable($1) r`, [G.ID101.id])).r;
ok(v1.version === 1, 'publication v1');
const snap = (await su(`select snapshot from public.timetable_versions where group_id = $1 and version = 1`, [G.ID101.id]))[0].snapshot;
ok(snap.length === 2 && snap.every((s) => s.module_id), 'instantané de version avec identifiants (restauration exacte)');
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and kind = 'timetable'`, [tB]))[0].n === 1, 'formateur concerné notifié de la publication');
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and kind = 'timetable'`, [tI]))[0].n === 0, 'formateur non concerné non notifié');

// ---------- Séances ponctuellement annulées / déplacées ----------
const slot = (await su(`select * from public.timetable_slots where group_id = $1 and start_time = '08:30'`, [G.ID101.id]))[0];
const slot2 = (await su(`select * from public.timetable_slots where group_id = $1 and start_time = '10:45'`, [G.ID101.id]))[0];
const nextDate = (await su(`select (public.local_today() + ((($1::int - extract(isodow from public.local_today())::int) + 7) % 7))::text d`, [wd]))[0].d;
ok(!!(await err(as(yas, `select public.set_session_exception($1, $2::date, 'cancelled')`, [slot.id, nextDate]))), 'stagiaire : ne peut pas annuler une séance');
ok(!!(await err(as(tB, `select public.set_session_exception($1, $2::date, 'cancelled')`, [slot.id, nextDate]))), 'formateur : ne peut pas annuler une séance (passe par la surveillance)');
ok(/jour du cours/.test(await err(as(surv, `select public.set_session_exception($1, ($2::date + 1), 'cancelled')`, [slot.id, nextDate])) || ''), 'annulation : la date doit correspondre au jour du cours');
await as(surv, `select public.set_session_exception($1, $2::date, 'cancelled', null, null, null, 'Formateur en formation')`, [slot.id, nextDate]);
ok((await as(yas, `select * from public.session_exceptions`)).rows.length === 1, 'stagiaire : voit l\'annulation de son groupe');
ok((await as(hib, `select * from public.session_exceptions`)).rows.length === 0, 'autre groupe : ne voit pas l\'annulation');
ok((await su(`select count(*)::int n from public.notifications where kind = 'cancel' and group_id = $1 and important`, [G.ID101.id]))[0].n === 1, 'groupe notifié (important)');
ok((await su(`select count(*)::int n from public.notifications where kind = 'cancel' and user_id = $1`, [tB]))[0].n === 1, 'formateur notifié de l\'annulation');
if (nextDate === today.d) ok(/annulée/.test(await err(as(tB, `select public.open_session($1, $2::date)`, [slot.id, nextDate])) || ''), 'appel impossible sur une séance annulée');
ok(/occupée/.test(await err(as(surv, `select public.set_session_exception($1, $2::date, 'moved', $3, '10:00', '11:00')`, [slot.id, nextDate, R['Salle 8']])) || ''), 'déplacement : salle déjà occupée détectée');
await as(surv, `select public.set_session_exception($1, $2::date, 'moved', $3, '14:00', '16:00', 'Labo 1 en maintenance')`, [slot.id, nextDate, R['Labo 4']]);
ok((await su(`select kind from public.session_exceptions where slot_id = $1`, [slot.id]))[0].kind === 'moved', 'séance déplacée (salle + horaire), annulation remplacée');
await as(surv, `select public.clear_session_exception($1, $2::date)`, [slot.id, nextDate]);
ok((await su(`select count(*)::int n from public.session_exceptions`))[0].n === 0, 'séance rétablie');
ok((await su(`select count(*)::int n from public.audit_log where action like 'session_%'`))[0].n === 3, 'annulation / déplacement / rétablissement audités');

// ---------- Surveillant : appel et justificatifs ----------
if (today.w !== 7) {
  const sess = (await one(surv, `select public.open_session($1, public.local_today()) id`, [slot.id])).id;
  await as(surv, `select public.save_attendance($1, $2)`, [sess, JSON.stringify([{ student_id: yas, status: 'absent' }])]);
  ok((await as(surv, `select * from public.attendance_records`)).rows.length === 1, 'surveillant : fait l\'appel et lit les présences');
  await as(yas, `insert into public.absence_justifications (session_id, student_id, reason) values ($1, $2, 'Certificat médical')`, [sess, yas]);
  await as(surv, `select public.review_justification($1, $2, true)`, [sess, yas]);
  ok((await su(`select status from public.attendance_records where student_id = $1`, [yas]))[0].status === 'excused', 'surveillant : valide un justificatif');
}

// ---------- Annonces : brouillon, programmée, ciblée ----------
await as(admin, `insert into public.announcements (scope, title, body, status) values ('all', 'Brouillon examens', 'Texte en préparation', 'draft')`);
ok((await as(yas, `select * from public.announcements`)).rows.length === 0, 'brouillon invisible pour les stagiaires');
ok((await su(`select count(*)::int n from public.notifications where title = 'Brouillon examens'`))[0].n === 0, 'brouillon : aucune notification');
await as(admin, `update public.announcements set status = 'published' where title = 'Brouillon examens'`);
ok((await as(yas, `select * from public.announcements`)).rows.length === 1, 'brouillon publié → visible');
ok((await su(`select count(*)::int n from public.notifications where title = 'Brouillon examens'`))[0].n === 1, 'publication → notification envoyée une fois');
await as(admin, `update public.announcements set body = 'Texte corrigé' where title = 'Brouillon examens'`);
ok((await su(`select count(*)::int n from public.notifications where title = 'Brouillon examens'`))[0].n === 1, 'modification après publication : pas de nouvelle notification');
await as(surv, `insert into public.announcements (scope, title, body, status, publish_at) values ('group', 'Annonce programmée', 'Demain', 'scheduled', now() + interval '1 hour')`.replace("'group', 'Annonce", "'all', 'Annonce"));
ok((await as(yas, `select * from public.announcements where title = 'Annonce programmée'`)).rows.length === 0, 'annonce programmée invisible avant l\'heure');
// l'heure passe sans qu'aucune écriture ne touche l'annonce (on contourne les triggers pour simuler le temps)
await su(`set session_replication_role = replica`); await su(`update public.announcements set publish_at = now() - interval '1 minute' where title = 'Annonce programmée'`); await su(`set session_replication_role = origin`);
ok((await su(`select public.publish_due_announcements() n`))[0].n === 1, 'publication automatique à l\'heure prévue');
ok((await as(yas, `select * from public.announcements where title = 'Annonce programmée'`)).rows.length === 1 && (await su(`select count(*)::int n from public.notifications where title = 'Annonce programmée'`))[0].n === 1, 'annonce programmée publiée et notifiée');
await as(admin, `insert into public.announcements (scope, title, body, target_users) values ('users', 'Convocation', 'Passez au bureau', $1)`, [[yas]]);
ok((await as(yas, `select * from public.announcements where title = 'Convocation'`)).rows.length === 1 && (await as(sal, `select * from public.announcements where title = 'Convocation'`)).rows.length === 0, 'annonce ciblée : visible seulement par le stagiaire visé');
ok(!!(await err(as(tB, `insert into public.announcements (scope, title, body, target_users) values ('users', 'Ciblée formateur', 'x', $1)`, [[sal]]))), 'formateur : ne peut pas cibler des stagiaires précis');
ok(!!(await err(as(admin, `insert into public.announcements (scope, title, body, status) values ('all', 'Sans date', 'x', 'scheduled')`))), 'programmation sans date refusée');

// ---------- Notifications envoyées par le personnel ----------
const n1 = (await one(surv, `insert into public.notifications (target_kind, group_id, kind, title, body) values ('group', $1, 'system', 'Rappel carte', 'Badge obligatoire') returning id`, [G.ID101.id])).id;
await as(yas, `insert into public.notification_reads (notification_id, user_id) values ($1, $2)`, [n1, yas]);
const st = await one(surv, `select * from public.notification_stats($1)`, [[n1]]);
ok(st.reads === 1 && st.audience === 2, `statistiques de lecture : ${st.reads}/${st.audience}`);
ok((await as(yas, `select * from public.notification_stats($1)`, [[n1]])).rows.length === 0, 'statistiques réservées au personnel');
ok((await su(`select created_by from public.notifications where id = $1`, [n1]))[0].created_by === surv, 'auteur de la notification enregistré');
// une lecture par un membre du personnel ne compte pas dans le taux de lecture des stagiaires
await as(surv, `insert into public.notification_reads (notification_id, user_id) values ($1, $2)`, [n1, surv]);
ok((await one(surv, `select * from public.notification_stats($1)`, [[n1]])).reads === 1, 'statistiques : seules les lectures des stagiaires comptent');
// message personnel : visible par son destinataire et par le membre du personnel qui l'a envoyé, pas par les autres
const n2 = (await one(surv, `insert into public.notifications (target_kind, user_id, kind, title) values ('user', $1, 'system', 'Convocation bureau') returning id`, [sal])).id;
ok((await as(surv, `select id from public.notifications where id = $1`, [n2])).rows.length === 1, 'personnel : retrouve le message personnel qu\'il a envoyé');
ok((await as(admin, `select id from public.notifications where id = $1`, [n2])).rows.length === 0, 'autre membre du personnel : ne lit pas ce message personnel');
ok((await as(yas, `select id from public.notifications where id = $1`, [n2])).rows.length === 0 && (await as(sal, `select id from public.notifications where id = $1`, [n2])).rows.length === 1, 'message personnel : visible seulement par sa destinataire');

// ---------- Devoirs : rendus et retours ----------
const due = new Date(Date.now() + 3 * 864e5).toISOString();
const a1 = (await one(tB, `insert into public.assessments (kind, group_id, module_id, title, due_at) values ('assignment', $1, $2, 'TP VLAN', $3) returning id`, [G.ID101.id, M.M101, due])).id;
const ex = (await one(tB, `insert into public.assessments (kind, group_id, module_id, title, due_at) values ('exam', $1, $2, 'Contrôle', $3) returning id`, [G.ID101.id, M.M101, due])).id;
await as(tB, `insert into public.resources (module_id, group_id, title, kind, url, assessment_id) values ($1, $2, 'Énoncé', 'link', 'https://ex.org/tp.pdf', $3)`, [M.M101, G.ID101.id, a1]);
ok((await as(yas, `select * from public.resources where assessment_id = $1`, [a1])).rows.length === 1, 'pièce jointe du devoir visible par le groupe');
await as(yas, `insert into public.submissions (assessment_id, content, link) values ($1, 'Voici mon compte rendu', 'https://drive.example.org/tp')`, [a1]);
ok(!!(await err(as(hib, `insert into public.submissions (assessment_id, content) values ($1, 'Rendu pirate')`, [a1]))), 'rendu refusé hors du groupe');
ok(!!(await err(as(yas, `insert into public.submissions (assessment_id, content) values ($1, 'Rendu examen')`, [ex]))), 'pas de rendu pour un examen');
ok(!!(await err(as(yas, `insert into public.submissions (assessment_id, content, storage_path) values ($1, 'x', $2)`, [a1, sal + '/fichier.pdf']))), 'fichier d\'un autre stagiaire refusé');
ok((await as(sal, `select * from public.submissions`)).rows.length === 0, 'rendus privés entre stagiaires');
ok((await as(tB, `select * from public.submissions`)).rows.length === 1, 'formateur du module : voit les rendus');
ok((await as(tI, `select * from public.submissions`)).rows.length === 0, 'autre formateur : ne voit pas les rendus');
ok(!!(await err(as(yas, `update public.submissions set feedback = 'Parfait 20/20' where student_id = $1`, [yas]))), 'stagiaire : ne peut pas écrire le retour');
ok(!!(await err(as(tI, `select public.give_feedback($1, $2, 'Bien')`, [a1, yas]))), 'autre formateur : ne peut pas répondre');
await as(tB, `select public.give_feedback($1, $2, 'Bon travail, détaillez le routage.', '16/20')`, [a1, yas]);
const sub = (await one(yas, `select * from public.submissions where assessment_id = $1`, [a1]));
ok(sub.feedback && sub.grade === '16/20' && sub.content === 'Voici mon compte rendu', 'retour et note enregistrés, rendu intact');
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and title = 'Retour du formateur'`, [yas]))[0].n === 1, 'stagiaire notifié du retour');
ok(/verrouillé/.test(await err(as(yas, `update public.submissions set content = 'modifié' where assessment_id = $1`, [a1])) || ''), 'rendu verrouillé après le retour');

// ---------- Calendrier académique ----------
await as(surv, `insert into public.calendar_events (title, kind, start_date, end_date) values ('Vacances d''hiver', 'holiday', '2026-12-20', '2027-01-03')`);
await as(admin, `insert into public.calendar_events (title, kind, start_date, end_date, group_id) values ('Examens ID102', 'exam_period', '2027-01-10', '2027-01-15', $1)`, [G.ID102.id]);
ok((await as(yas, `select title from public.calendar_events`)).rows.map((r) => r.title).join() === 'Vacances d\'hiver', 'calendrier : événements généraux + de son groupe');
ok(!!(await err(as(yas, `insert into public.calendar_events (title, start_date, end_date) values ('Fête', '2026-12-01', '2026-12-01')`))), 'calendrier : stagiaire ne peut pas écrire');
ok(!!(await err(as(admin, `insert into public.calendar_events (title, start_date, end_date) values ('Inversé', '2026-12-05', '2026-12-01')`))), 'calendrier : dates incohérentes refusées');

// ---------- Covoiturage : contacts protégés ----------
await as(sal, `update public.profiles set phone = '0612345678', share_phone = true where id = $1`, [sal]);
await as(yas, `update public.profiles set phone = '0698765432' where id = $1`, [yas]);
const ride = (await one(sal, `insert into public.rides (kind, from_place, depart_at, seats) values ('offer', 'Dakhla', '07:50', 2) returning id`)).id;
ok(!!(await err(as(yas, `select * from public.ride_contacts($1)`, [ride]))), 'contacts invisibles avant réservation');
await as(yas, `insert into public.ride_bookings (ride_id) values ($1)`, [ride]);
const cY = (await as(yas, `select * from public.ride_contacts($1)`, [ride])).rows;
ok(cY.find((c) => c.is_driver).phone === '0612345678', 'passager : voit le téléphone du conducteur (partage activé)');
const cS = (await as(sal, `select * from public.ride_contacts($1)`, [ride])).rows;
ok(cS.find((c) => !c.is_driver).phone === null, 'conducteur : ne voit pas le téléphone d\'un passager qui ne le partage pas');
ok(!!(await err(as(hib, `select * from public.ride_contacts($1)`, [ride]))), 'tiers : aucun accès aux contacts');
ok(!!(await err(as(yas, `update public.profiles set status = 'suspended' where id = $1`, [yas]))), 'colonnes protégées toujours bloquées');

// ---------- Restauration de version ----------
await as(admin, `select public.start_timetable_draft($1)`, [G.ID101.id]);
await as(admin, `delete from public.timetable_drafts where group_id = $1 and start_time = '10:45'`, [G.ID101.id]);
const v2 = (await one(admin, `select public.publish_timetable($1) r`, [G.ID101.id])).r;
ok(v2.version === 2 && (await su(`select count(*)::int n from public.timetable_slots where group_id = $1`, [G.ID101.id]))[0].n === 1, 'v2 publiée (un créneau retiré)');
const ver1 = (await su(`select id from public.timetable_versions where group_id = $1 and version = 1`, [G.ID101.id]))[0].id;
ok(!!(await err(as(surv, `select public.restore_version($1)`, [ver1]))), 'restauration réservée à l\'administration');
ok((await one(admin, `select public.restore_version($1) n`, [ver1])).n === 2, 'v1 restaurée dans le brouillon (2 créneaux)');
const v3 = (await one(admin, `select public.publish_timetable($1) r`, [G.ID101.id])).r;
ok(v3.version === 3 && (await su(`select count(*)::int n from public.timetable_slots where group_id = $1`, [G.ID101.id]))[0].n === 2, 'v3 = contenu de la v1 republié');

// ---------- Rapports ----------
const rep = (await one(surv, `select public.admin_reports() r`)).r;
const g101 = rep.groups.find((g) => g.code === 'ID101');
ok(g101.students === 2 && g101.slots === 2 && g101.version === 3 && g101.assignments === 1 && g101.exams === 1, 'rapports : chiffres réels par groupe');
ok(rep.people.student === 3 && rep.people.supervisor === 1 && rep.assessments.submissions === 1 && rep.calendar === undefined, 'rapports : effectifs et rendus');
ok(!!(await err(as(tB, `select public.admin_reports()`))), 'rapports réservés au personnel');
ok(!!(await err(as(null, `select public.admin_reports()`))), 'rapports : aucun accès anonyme');

// ---------- Questions anonymes : la surveillance voit l'auteur ----------
const p1 = (await one(yas, `insert into public.posts (group_id, title, body, anonymous) values ($1, 'Question anonyme', 'Texte de la question anonyme', true) returning id`, [G.ID101.id])).id;
ok((await one(surv, `select author_id from public.posts_feed where id = $1`, [p1])).author_id === yas, 'surveillance : auteur réel visible pour modérer');
ok((await one(sal, `select author_id from public.posts_feed where id = $1`, [p1])).author_id === null, 'camarade : auteur toujours masqué');
await as(surv, `select public.moderate('post', $1, 'hide', 'Hors sujet')`, [p1]);
ok((await su(`select status from public.posts where id = $1`, [p1]))[0].status === 'hidden', 'surveillance : modère');

console.log(`\n${pass} réussis, ${fail} échoués`);
process.exit(fail ? 1 : 0);
