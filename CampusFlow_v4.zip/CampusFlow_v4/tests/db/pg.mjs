// Postgres de test (PGlite + btree_gist) avec un « faux » Supabase minimal : schéma auth, auth.uid(), rôles anon/authenticated.
import { PGlite } from '@electric-sql/pglite';
import { btree_gist } from '@electric-sql/pglite/contrib/btree_gist';
import fs from 'fs';
import path from 'path';

export async function makeDb(migrationsDir, opts = {}) {
  const db = new PGlite({ extensions: { btree_gist }, ...opts });
  await db.exec(`
    create schema if not exists auth;
    create table auth.users (id uuid primary key default gen_random_uuid(), email text unique, raw_user_meta_data jsonb default '{}'::jsonb, encrypted_password text);
    create or replace function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    do $$ begin
      if not exists (select 1 from pg_roles where rolname = 'anon') then create role anon nologin; end if;
      if not exists (select 1 from pg_roles where rolname = 'authenticated') then create role authenticated nologin; end if;
    end $$;
    grant usage on schema public, auth to anon, authenticated;
    alter default privileges in schema public grant all on tables to anon, authenticated;
    alter default privileges in schema public grant all on sequences to anon, authenticated;
    alter default privileges in schema public grant execute on functions to anon, authenticated;
  `);
  for (const f of fs.readdirSync(migrationsDir).filter((x) => x.endsWith('.sql')).sort()) {
    try { await db.exec(fs.readFileSync(path.join(migrationsDir, f), 'utf8')); }
    catch (e) { throw new Error(`${f}: ${e.message}`); }
  }
  // Le Maroc est à GMT depuis le 20/09/2026 ; la base de données de fuseaux de PGlite est antérieure → même réglage qu'en production
  await db.query(`select set_config('app.timezone', $1, false)`, [process.env.CF_TZ || 'UTC']);
  return db;
}

// Exécute une requête comme un utilisateur connecté (null = visiteur anonyme), comme le fait PostgREST
export async function asUser(db, uid, sql, params = []) {
  return db.transaction(async (tx) => {
    await tx.query(`select set_config('request.jwt.claim.sub', $1, true)`, [uid || '']);
    await tx.exec(`set local role ${uid ? 'authenticated' : 'anon'}`);
    return tx.query(sql, params);
  });
}
