// Tests de la base CampusFlow v3 : règles RLS par rôle, conflits d'horaires, publication, assiduité,
// modération, anti-spam, audit. Chaque test s'exécute comme un vrai utilisateur (rôle authenticated + auth.uid()).
import { makeDb, asUser } from './pg.mjs';

const db = await makeDb(process.argv[2] || '../supabase/migrations');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('✅ ' + m); } else { fail++; console.log('❌ FAIL ' + m); } };
const err = async (p) => { try { await p; return null; } catch (e) { return e.message; } };
const as = (uid, sql, params) => asUser(db, uid, sql, params);
const one = async (uid, sql, params) => (await as(uid, sql, params)).rows[0];
const su = async (sql, params) => (await db.query(sql, params)).rows;

// ---------- Fuseau ----------
ok((await su(`select public.app_tz() z`))[0].z === 'UTC', 'fuseau de l\'établissement configurable (app.timezone)');
await su(`select set_config('app.timezone', '', false)`);
ok((await su(`select public.app_tz() z`))[0].z === 'Africa/Casablanca', 'fuseau par défaut : Africa/Casablanca');
await su(`select set_config('app.timezone', 'UTC', false)`);

// ---------- Données de départ ----------
const G = Object.fromEntries((await su(`select code, id, join_code from public.groups`)).map((r) => [r.code, r]));
const M = Object.fromEntries((await su(`select code, id from public.modules`)).map((r) => [r.code, r.id]));
const R = Object.fromEntries((await su(`select name, id from public.rooms`)).map((r) => [r.name, r.id]));
const signup = async (email, name, meta = {}) => (await su(`insert into auth.users (email, raw_user_meta_data) values ($1, $2) returning id`, [email, { full_name: name, ...meta }]))[0].id;

await su(`insert into public.roster (email, full_name, role) values ('admin@cmc.ma', 'Admin CMC', 'admin'), ('benali@cmc.ma', 'M. Benali', 'teacher'), ('idrissi@cmc.ma', 'Mme Idrissi', 'teacher')`);
const admin = await signup('admin@cmc.ma', 'Admin CMC');
const tBenali = await signup('benali@cmc.ma', 'M. Benali');
const tIdrissi = await signup('idrissi@cmc.ma', 'Mme Idrissi');

ok(!!(await err(signup('intrus@x.ma', 'Intrus', { join_code: 'ZZZZZZ' }))), 'inscription refusée avec un code invalide');
const yas = await signup('yassine@cmc.ma', 'Yassine', { join_code: G.ID101.join_code, role: 'admin' });
ok((await su(`select role::text r from public.profiles where id = $1`, [yas]))[0].r === 'student', 'le rôle envoyé par le client est ignoré (étudiant)');
const sal = await signup('salma@cmc.ma', 'Salma', { join_code: G.ID101.join_code.toLowerCase() });
const hib = await signup('hiba@cmc.ma', 'Hiba', { join_code: G.ID102.join_code });
ok((await su(`select role::text r from public.profiles where id = $1`, [tBenali]))[0].r === 'teacher', 'pré-inscription : le formateur reçoit le rôle teacher');

await as(admin, `insert into public.teaching_assignments (group_id, module_id, teacher_id) values ($1,$2,$3), ($4,$2,$3), ($1,$5,$6)`,
  [G.ID101.id, M.M101, tBenali, G.ID102.id, M.M102, tIdrissi]);

// ---------- Comptes et droits ----------
ok(!!(await err(as(yas, `update public.profiles set role = 'admin' where id = $1`, [yas]))), 'un stagiaire ne peut pas devenir admin');
ok(!!(await err(as(yas, `update public.profiles set group_id = $2 where id = $1`, [yas, G.ID102.id]))), 'un stagiaire ne peut pas changer de groupe');
await as(yas, `update public.profiles set full_name = 'Yassine El Amrani' where id = $1`, [yas]);
ok((await su(`select full_name from public.profiles where id = $1`, [yas]))[0].full_name === 'Yassine El Amrani', 'un stagiaire peut modifier son nom');
ok(!!(await err(as(yas, `select join_code from public.groups`))), 'codes d\'accès illisibles pour un stagiaire');
ok((await as(admin, `select * from public.admin_group_codes()`)).rows.length === 3, 'l\'admin lit les codes via RPC');
ok(!!(await err(as(null, `select * from public.profiles`))), 'visiteur anonyme : aucun accès aux profils');
ok((await as(null, `select * from public.check_join_code($1)`, [G.ID102.join_code])).rows[0].code === 'ID102', 'visiteur anonyme : vérification d\'un code possible');
const ppl = (await as(yas, `select * from public.people`)).rows;
ok(ppl.length >= 6 && !('email' in ppl[0]), 'annuaire sans e-mail');
ok((await as(yas, `select id from public.profiles`)).rows.length === 1, 'un stagiaire ne lit que son propre profil');
const benaliSees = (await as(tBenali, `select id from public.profiles where role = 'student'`)).rows.map((r) => r.id);
ok(benaliSees.includes(yas) && benaliSees.includes(sal) && benaliSees.includes(hib), 'formateur : voit les stagiaires de ses groupes');
const idrissiSees = (await as(tIdrissi, `select id from public.profiles where role = 'student'`)).rows.map((r) => r.id);
ok(idrissiSees.length === 2 && !idrissiSees.includes(hib), 'formateur : ne voit pas les autres groupes');
ok(!!(await err(as(yas, `select public.admin_set_role($1, 'admin')`, [sal]))), 'RPC admin refusée à un stagiaire');
ok(!!(await err(as(admin, `select public.admin_set_role($1, 'student', $2)`, [admin, G.ID101.id]))), 'l\'admin ne peut pas se retirer ses propres droits');

// ---------- Emploi du temps : brouillon, conflits, publication ----------
const draft = (g, m, t, r, wd, s, e, extra = '') => as(admin,
  `insert into public.timetable_drafts (group_id, module_id, teacher_id, room_id, weekday, start_time, end_time${extra ? ', status, note, source_slot_id' : ''})
   values ($1,$2,$3,$4,$5,$6,$7${extra ? ',' + extra : ''}) returning id`, [g, m, t, r, wd, s, e]).then((x) => x.rows[0].id);
// ID102 publié : Benali en M101 lundi 08:30–10:30 en Labo 3
await draft(G.ID102.id, M.M101, tBenali, R['Labo 3'], 1, '08:30', '10:30');
await as(admin, `select public.publish_timetable($1)`, [G.ID102.id]);
// ID101 brouillon avec 3 conflits
const d1 = await draft(G.ID101.id, M.M101, tBenali, R['Labo 1'], 1, '09:00', '11:00');           // formateur déjà pris (ID102)
const d2 = await draft(G.ID101.id, M.M102, tIdrissi, R['Labo 3'], 1, '10:00', '12:00');           // salle prise + chevauche d1
const conflicts = (await as(admin, `select * from public.check_timetable_conflicts($1)`, [G.ID101.id])).rows;
const kinds = conflicts.map((c) => c.kind).sort().join(',');
ok(kinds.includes('teacher') && kinds.includes('room') && kinds.includes('group'), `conflits détectés (formateur, salle, groupe) : ${kinds}`);
ok(/Benali/.test(conflicts.find((c) => c.kind === 'teacher').message), 'message de conflit lisible : ' + conflicts.find((c) => c.kind === 'teacher').message);
ok(/conflit/.test(await err(as(admin, `select public.publish_timetable($1)`, [G.ID101.id]))), 'publication refusée tant qu\'il y a des conflits');
await as(admin, `update public.timetable_drafts set weekday = 2, start_time = '08:30', end_time = '10:30' where id = $1`, [d1]);
await as(admin, `update public.timetable_drafts set start_time = '10:45', end_time = '12:45', room_id = $2 where id = $1`, [d2, R['Labo 4']]);
await draft(G.ID101.id, M.M107, null, R['Salle 8'], 3, '14:00', '16:00');
ok((await as(admin, `select * from public.check_timetable_conflicts($1)`, [G.ID101.id])).rows.length === 0, 'conflits corrigés');
const pub = (await one(admin, `select public.publish_timetable($1) r`, [G.ID101.id])).r;
ok(pub.version === 1 && pub.changes.length === 3, `publication v1 avec ${pub.changes.length} changements`);
ok((await su(`select count(*)::int n from public.timetable_slots where group_id = $1`, [G.ID101.id]))[0].n === 3, '3 créneaux publiés');
ok((await su(`select count(*)::int n from public.timetable_drafts where group_id = $1`, [G.ID101.id]))[0].n === 0, 'brouillon vidé après publication');
ok((await su(`select count(*)::int n from public.notifications where group_id = $1 and kind = 'timetable'`, [G.ID101.id]))[0].n === 1, 'groupe notifié de la publication');
ok(/Aucun changement/.test(await err(as(admin, `select public.publish_timetable($1)`, [G.ID101.id])) || ''), 'publication vide refusée');
ok((await as(yas, `select group_id from public.timetable_slots`)).rows.every((r) => r.group_id === G.ID101.id), 'un stagiaire ne voit que les créneaux de son groupe');
ok(!!(await err(as(yas, `insert into public.timetable_slots (group_id, module_id, weekday, start_time, end_time) values ($1,$2,4,'08:30','10:00')`, [G.ID101.id, M.M101]))), 'un stagiaire ne peut pas créer de créneau');
ok(!!(await err(as(tBenali, `update public.timetable_slots set room_id = $1`, [R['Amphi A']]).then((r) => { if (r.affectedRows) throw new Error('modifié'); throw new Error('0'); }))), 'un formateur ne peut pas modifier l\'emploi du temps');
ok(/conflicting key|exclusion|conflict/i.test(await err(as(admin, `insert into public.timetable_slots (group_id, module_id, teacher_id, weekday, start_time, end_time) values ($1,$2,$3,1,'09:00','10:00')`, [G.DEV101.id, M.M106, tBenali])) || ''),
  'la base refuse un créneau en double pour un formateur (contrainte d\'exclusion)');
ok(!!(await err(as(admin, `insert into public.timetable_drafts (group_id, module_id, weekday, start_time, end_time) values ($1,$2,1,'12:00','11:00')`, [G.ID101.id, M.M101]))), 'horaire invalide refusé (fin avant début)');

// Annulation + changement de salle → notifications ciblées
const slots = (await su(`select * from public.timetable_slots where group_id = $1 order by weekday`, [G.ID101.id]));
ok((await su(`select count(*)::int n from public.timetable_slots where group_id = $1`, [G.ID101.id]))[0].n === 3, 'publication vide : l\'emploi du temps n\'est jamais effacé');
ok((await one(admin, `select public.start_timetable_draft($1) n`, [G.ID101.id])).n === 3, 'brouillon ouvert = copie des 3 créneaux publiés');
ok(!!(await err(as(yas, `select public.start_timetable_draft($1)`, [G.ID101.id]))), 'un stagiaire ne peut pas ouvrir de brouillon');
await as(admin, `update public.timetable_drafts set room_id = $2 where group_id = $1 and weekday = 1`, [G.ID101.id, R['Labo 2']]);
await as(admin, `update public.timetable_drafts set status = 'cancelled', note = 'Formatrice absente' where group_id = $1 and weekday = 3`, [G.ID101.id]);
const pub2 = (await one(admin, `select public.publish_timetable($1) r`, [G.ID101.id])).r;
const types = pub2.changes.map((c) => c.type).sort().join(',');
ok(pub2.version === 2 && types === 'cancel,room', `v2 : annulation + changement de salle (${types})`);
ok((await su(`select count(*)::int n from public.notifications where group_id = $1 and kind in ('cancel','room') and important`, [G.ID101.id]))[0].n === 2, 'notifications importantes pour annulation et salle');
ok((await as(yas, `select * from public.timetable_versions`)).rows.length === 2, 'historique des versions visible par le groupe');

// ---------- Assiduité ----------
const monday = (await su(`select (public.local_today() - ((extract(isodow from public.local_today())::int + 6) % 7))::date d`))[0].d;   // lundi de cette semaine (≤ aujourd'hui)
const mondayIso = monday instanceof Date ? monday.toISOString().slice(0, 10) : String(monday);
const slotMon = slots.find((s) => s.weekday === 1);
const sess = (await one(tIdrissi, `select public.open_session($1, $2::date) id`, [slotMon.id, mondayIso])).id;
ok(!!sess, 'la formatrice ouvre la séance du lundi');
ok(/jour du cours/.test(await err(as(tIdrissi, `select public.open_session($1, ($2::date + 1))`, [slotMon.id, mondayIso])) || ''), 'mauvais jour refusé');
ok(/future/.test(await err(as(tIdrissi, `select public.open_session($1, ($2::date + 7))`, [slotMon.id, mondayIso])) || ''), 'séance future refusée');
ok(/formateur du cours/.test(await err(as(tBenali, `select public.open_session($1, $2::date)`, [slotMon.id, mondayIso])) || ''), 'un autre formateur ne peut pas faire l\'appel');
ok(!!(await err(as(yas, `select public.save_attendance($1, $2)`, [sess, JSON.stringify([{ student_id: yas, status: 'present' }])]))), 'un stagiaire ne peut pas modifier l\'appel');
ok(/ne fait pas partie/.test(await err(as(tIdrissi, `select public.save_attendance($1, $2)`, [sess, JSON.stringify([{ student_id: hib, status: 'present' }])])) || ''), 'stagiaire d\'un autre groupe refusé');
await as(tIdrissi, `select public.save_attendance($1, $2)`, [sess, JSON.stringify([{ student_id: yas, status: 'absent' }, { student_id: sal, status: 'late', minutes_late: 12 }])]);
ok((await su(`select count(*)::int n from public.attendance_records where session_id = $1`, [sess]))[0].n === 2, 'appel enregistré (2 stagiaires)');
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and kind = 'attendance'`, [yas]))[0].n === 1, 'stagiaire notifié de son absence');
ok((await as(sal, `select student_id from public.attendance_records`)).rows.every((r) => r.student_id === sal), 'un stagiaire ne voit que ses propres présences');
ok(!!(await err(as(yas, `update public.attendance_records set status = 'present' where student_id = $1`, [yas]))), 'un stagiaire ne peut pas corriger sa présence');
const sumY = await one(yas, `select * from public.attendance_summary`);
ok(sumY && sumY.absent === 1 && Number(sumY.rate) === 0, `statistiques réelles : ${JSON.stringify(sumY)}`);
ok(!!(await err(as(sal, `insert into public.absence_justifications (session_id, student_id, reason) values ($1, $2, 'Je justifie pour un autre')`, [sess, yas]).then(async () => {
  const r = (await su(`select student_id from public.absence_justifications`))[0]; if (r && r.student_id !== yas) throw new Error('forcé sur soi'); }))), 'justificatif : toujours au nom de celui qui l\'envoie');
await su(`delete from public.absence_justifications`);
await as(yas, `insert into public.absence_justifications (session_id, student_id, reason) values ($1, $2, 'Rendez-vous médical (certificat)')`, [sess, yas]);
ok(!!(await err(as(tBenali, `select public.review_justification($1, $2, true)`, [sess, yas]))), 'un formateur extérieur ne peut pas valider le justificatif');
await as(tIdrissi, `select public.review_justification($1, $2, true)`, [sess, yas]);
ok((await su(`select status from public.attendance_records where session_id = $1 and student_id = $2`, [sess, yas]))[0].status === 'excused', 'justificatif accepté → absence justifiée');

// ---------- Devoirs & examens ----------
const due = new Date(Date.now() + 3 * 864e5).toISOString();
await as(tBenali, `insert into public.assessments (kind, group_id, module_id, title, due_at) values ('assignment', $1, $2, 'TP VLAN', $3)`, [G.ID101.id, M.M101, due]);
ok((await su(`select count(*)::int n from public.notifications where kind = 'assignment' and group_id = $1`, [G.ID101.id]))[0].n === 1, 'devoir créé par le formateur → groupe notifié');
ok(!!(await err(as(tBenali, `insert into public.assessments (kind, group_id, module_id, title, due_at) values ('exam', $1, $2, 'Examen hors droits', $3)`, [G.DEV101.id, M.M106, due]))), 'formateur : pas de devoir pour un groupe qu\'il n\'enseigne pas');
ok(!!(await err(as(yas, `insert into public.assessments (kind, group_id, module_id, title, due_at) values ('assignment', $1, $2, 'Faux devoir', $3)`, [G.ID101.id, M.M101, due]))), 'un stagiaire ne peut pas créer de devoir');
await as(admin, `insert into public.assessments (kind, group_id, module_id, title, due_at, duration_min) values ('exam', null, $1, 'Examen régional', $2, 120), ('exam', $3, $1, 'Contrôle ID102', $2, 60)`, [M.M107, due, G.ID102.id]);
const seen = (await as(yas, `select title from public.assessments order by title`)).rows.map((r) => r.title);
ok(seen.join('|') === 'Examen régional|TP VLAN', 'stagiaire : devoirs de son groupe + communs, pas ceux des autres');
const aId = (await su(`select id from public.assessments where title = 'TP VLAN'`))[0].id;
await as(yas, `insert into public.assessment_progress (assessment_id, student_id, status) values ($1, $2, 'done')`, [aId, yas]);
ok((await as(sal, `select * from public.assessment_progress`)).rows.length === 0, 'progression privée');

// ---------- Annonces & notifications ----------
ok(!!(await err(as(tBenali, `insert into public.announcements (scope, title, body) values ('all', 'Annonce globale', 'Texte')`))), 'formateur : pas d\'annonce à tout l\'établissement');
await as(tBenali, `insert into public.announcements (scope, group_id, title, body) values ('group', $1, 'Salle changée jeudi', 'Rendez-vous au Labo 6')`, [G.ID101.id]);
ok((await as(hib, `select * from public.announcements`)).rows.length === 0 && (await as(yas, `select * from public.announcements`)).rows.length === 1, 'annonce de groupe visible seulement par le groupe');
ok(!!(await err(as(yas, `insert into public.announcements (scope, group_id, title, body) values ('group', $1, 'Pirate', 'Annonce pirate')`, [G.ID101.id]))), 'un stagiaire ne peut pas publier d\'annonce');
await as(yas, `insert into public.notifications (target_kind, user_id, kind, title) values ('user', $1, 'reminder', 'Réseaux dans 10 min')`, [yas]);
ok(!!(await err(as(yas, `insert into public.notifications (target_kind, group_id, kind, title) values ('group', $1, 'system', 'Spam')`, [G.ID101.id]))), 'un stagiaire ne peut pas notifier son groupe');
ok(!!(await err(as(yas, `insert into public.notifications (target_kind, user_id, kind, title) values ('user', $1, 'reminder', 'Spam')`, [sal]))), 'un stagiaire ne peut pas notifier un autre stagiaire');
const nOther = (await su(`select id from public.notifications where group_id = $1 limit 1`, [G.ID102.id]))[0].id;
ok((await as(yas, `select id from public.notifications where id = $1`, [nOther])).rows.length === 0, 'notifications d\'un autre groupe invisibles');
ok(!!(await err(as(yas, `insert into public.notification_reads (notification_id, user_id) values ($1, $2)`, [nOther, yas]))), 'impossible de marquer comme lue une notification invisible');

// ---------- Communauté ----------
const post = (uid, g, anon = false, t = 'Question sur le TP VLAN') => as(uid,
  `insert into public.posts (group_id, module_id, title, body, anonymous) values ($1, $2, $3, 'Le ping inter-VLAN ne passe pas, une idée ?', $4) returning id`, [g, M.M101, t, anon]).then((r) => r.rows[0].id);
const p1 = await post(yas, G.ID101.id, true);
ok(!!(await err(post(yas, G.ID102.id))), 'publication refusée dans un autre groupe');
const fSal = await one(sal, `select * from public.posts_feed where id = $1`, [p1]);
ok(fSal && fSal.author_id === null, 'question anonyme : auteur masqué pour les camarades');
ok((await one(yas, `select author_id from public.posts_feed where id = $1`, [p1])).author_id === yas, 'l\'auteur se voit');
ok((await one(admin, `select author_id from public.posts_feed where id = $1`, [p1])).author_id === yas, 'l\'admin voit l\'auteur (modération)');
ok(!!(await err(as(sal, `select author_id, body from public.posts`))), 'table posts illisible directement (auteur protégé)');
ok((await as(hib, `select * from public.posts_feed`)).rows.length === 0, 'un autre groupe ne voit pas la question');
const r1 = (await one(sal, `insert into public.replies (post_id, body) values ($1, 'Mets le port en trunk') returning id`, [p1])).id;
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and title = 'Nouvelle réponse'`, [yas]))[0].n === 1, 'réponse → auteur notifié');
ok((await as(sal, `update public.posts set best_reply_id = $2 where id = $1`, [p1, r1])).affectedRows === 0, 'seul l\'auteur choisit la meilleure réponse');
await as(yas, `update public.posts set best_reply_id = $2 where id = $1`, [p1, r1]);
ok((await su(`select resolved from public.posts where id = $1`, [p1]))[0].resolved === true, 'meilleure réponse → question résolue');
ok(!!(await err(as(yas, `update public.posts set body = 'texte modifié en douce' where id = $1`, [p1]))), 'le contenu publié ne peut pas être réécrit');
await as(sal, `insert into public.post_votes (post_id) values ($1)`, [p1]);
ok((await one(yas, `select votes from public.posts_feed where id = $1`, [p1])).votes === 1, 'vote comptabilisé');
for (let i = 0; i < 5; i++) await post(sal, G.ID101.id, false, 'Question numéro ' + i);
ok(/Trop de publications/.test(await err(post(sal, G.ID101.id, false, 'Question numéro 5')) || ''), 'anti-spam : 6e question en 10 min refusée');
const target = (await su(`select id from public.posts where title = 'Question numéro 0'`))[0].id;
const s3 = await signup('omar@cmc.ma', 'Omar', { join_code: G.ID101.join_code });
for (const u of [yas, s3]) await as(u, `insert into public.reports (target_kind, target_id, reason) values ('post', $1, 'spam')`, [target]);
ok((await su(`select status from public.posts where id = $1`, [target]))[0].status === 'visible', '2 signalements : contenu encore visible');
await as(tBenali, `insert into public.reports (target_kind, target_id, reason) values ('post', $1, 'spam')`, [target]);
ok((await su(`select status from public.posts where id = $1`, [target]))[0].status === 'hidden', '3 signalements : contenu masqué automatiquement');
ok(!(await as(yas, `select id from public.posts_feed`)).rows.some((r) => r.id === target), 'contenu masqué invisible pour les camarades');
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and title = 'Contenu signalé'`, [admin]))[0].n >= 1, 'admin alerté');
ok(!!(await err(as(yas, `select public.moderate('post', $1, 'restore')`, [target]))), 'un stagiaire ne peut pas modérer');
await as(tBenali, `select public.moderate('post', $1, 'restore', 'Pas un spam')`, [target]);
ok((await su(`select status from public.posts where id = $1`, [target]))[0].status === 'visible', 'formateur du groupe : peut rétablir un contenu');
ok((await su(`select count(*)::int n from public.reports where target_id = $1 and status = 'open'`, [target]))[0].n === 0, 'signalements clôturés');
await as(admin, `select public.mute_user($1, 3)`, [s3]);
ok(/limité/.test(await err(post(s3, G.ID101.id, false, 'Message pendant sanction')) || ''), 'utilisateur sanctionné : publication bloquée');

// ---------- Groupes de révision & covoiturage ----------
const tomorrow = (await su(`select (public.local_today() + 1)::text d`))[0].d;
const sg = (await one(yas, `insert into public.study_groups (subject, meet_date, start_time, end_time, place, capacity) values ('Révision VLAN', $1, '12:45', '14:00', 'Bibliothèque', 2) returning id`, [tomorrow])).id;
await as(yas, `insert into public.study_group_members (study_group_id) values ($1)`, [sg]);
await as(sal, `insert into public.study_group_members (study_group_id) values ($1)`, [sg]);
ok(/complet/.test(await err(as(hib, `insert into public.study_group_members (study_group_id) values ($1)`, [sg])) || ''), 'groupe de révision : capacité respectée');
ok((await su(`select count(*)::int n from public.notifications where user_id = $1 and title = 'Nouveau membre'`, [yas]))[0].n === 1, 'créateur notifié d\'un nouveau membre');
const ride = (await one(sal, `insert into public.rides (kind, from_place, depart_at, seats) values ('offer', 'Dakhla', '07:50', 1) returning id`)).id;
ok(/propre trajet/.test(await err(as(sal, `insert into public.ride_bookings (ride_id) values ($1)`, [ride])) || ''), 'impossible de réserver son propre trajet');
await as(yas, `insert into public.ride_bookings (ride_id) values ($1)`, [ride]);
ok(/complet/.test(await err(as(hib, `insert into public.ride_bookings (ride_id) values ($1)`, [ride])) || ''), 'trajet complet refusé');
ok((await as(yas, `delete from public.rides where id = $1`, [ride])).affectedRows === 0, 'impossible de supprimer le trajet d\'un autre');

// ---------- Ressources ----------
await as(tBenali, `insert into public.resources (module_id, group_id, title, kind, url) values ($1, $2, 'Cours VLAN (PDF)', 'link', 'https://cours.example.org/vlan.pdf')`, [M.M101, G.ID101.id]);
ok(!!(await err(as(tBenali, `insert into public.resources (module_id, group_id, title, kind, url) values ($1, $2, 'Hors droits', 'link', 'https://x.org')`, [M.M106, G.DEV101.id]))), 'ressource refusée hors des modules enseignés');
ok(!!(await err(as(yas, `insert into public.resources (module_id, group_id, title, kind, url) values ($1, $2, 'Pirate', 'link', 'https://x.org')`, [M.M101, G.ID101.id]))), 'un stagiaire ne peut pas publier de ressource');
ok(!!(await err(as(admin, `insert into public.resources (module_id, title, kind, url) values ($1, 'Lien non sécurisé', 'link', 'http://x.org')`, [M.M101]))), 'lien non HTTPS refusé');
ok((await as(yas, `select * from public.resources`)).rows.length === 1 && (await as(hib, `select * from public.resources`)).rows.length === 0, 'ressources visibles par le bon groupe');

// ---------- Données personnelles ----------
await as(yas, `insert into public.tasks (title) values ('Réviser VLAN')`);
await as(yas, `insert into public.user_settings (data) values ('{"lang":"ar"}')`);
ok((await as(sal, `select * from public.tasks`)).rows.length === 0 && (await as(sal, `select * from public.user_settings`)).rows.length === 0, 'tâches et réglages privés');
ok(!!(await err(as(yas, `insert into public.ai_usage (user_id, requests) values ($1, 0)`, [yas]))), 'quota IA non modifiable par l\'utilisateur');
ok(!!(await err(as(yas, `select public.ai_consume($1, 1000)`, [yas]))), 'quota IA : la RPC n\'est pas appelable depuis le navigateur');
ok((await su(`select public.ai_consume($1, 2) r`, [yas]))[0].r === 1 && (await su(`select public.ai_consume($1, 2) r`, [yas]))[0].r === 0, 'quota IA : décompte atomique (service_role)');
ok(/quota/.test(await err(su(`select public.ai_consume($1, 2)`, [yas])) || ''), 'quota IA : refus au-delà de la limite quotidienne');

// ---------- Import de la liste des stagiaires ----------
const rows = JSON.stringify([{ email: 'nour@cmc.ma', full_name: 'Nour', group_code: 'id101' }, { email: 'pas-un-email', group_code: 'ID101' },
  { email: 'yassine@cmc.ma', group_code: 'ID101' }, { email: 'x@cmc.ma', group_code: 'ZZ' }, { email: 'nour@cmc.ma', group_code: 'ID101' }]);
const dry = (await one(admin, `select public.import_roster($1, true) r`, [rows])).r;
ok(dry.valid === 1 && dry.duplicates === 1 && dry.errors.length === 3, `import CSV (test à blanc) : ${dry.valid} valide, ${dry.duplicates} doublon, ${dry.errors.length} erreurs`);
ok(/Corrigez/.test(await err(as(admin, `select public.import_roster($1, false)`, [rows])) || ''), 'import réel bloqué tant qu\'il reste des erreurs');
await as(admin, `select public.import_roster($1, false)`, [JSON.stringify([{ email: 'nour@cmc.ma', full_name: 'Nour B.', group_code: 'ID101' }])]);
const nour = await signup('nour@cmc.ma', 'Nour Benjelloun');
ok((await su(`select group_id from public.profiles where id = $1`, [nour]))[0].group_id === G.ID101.id, 'stagiaire pré-inscrit : groupe attribué sans code');
ok(!!(await err(as(yas, `select public.import_roster('[]', true)`))), 'import réservé à l\'admin');

// ---------- Suspension ----------
ok(!!(await err(as(admin, `update public.profiles set status = 'suspended' where id = $1`, [hib]))), 'statut non modifiable directement (même admin) : passe par la RPC auditée');
await as(admin, `select public.admin_set_status($1, 'suspended')`, [hib]);
ok((await as(hib, `select * from public.timetable_slots`)).rows.length === 0 && (await as(hib, `select * from public.announcements`)).rows.length === 0, 'compte suspendu : plus accès aux données du groupe');
ok(!!(await err(as(hib, `insert into public.posts (group_id, title, body) values ($1, 'Question suspendue', 'Le compte est suspendu, refus attendu')`, [G.ID102.id]))), 'compte suspendu : publication refusée');
ok(!!(await err(as(admin, `select public.admin_set_status($1, 'suspended')`, [admin]))), 'l\'admin ne peut pas suspendre son propre compte');
ok(!!(await err(as(yas, `select public.admin_set_status($1, 'suspended')`, [sal]))), 'suspension réservée à l\'admin');
await as(admin, `select public.admin_set_status($1, 'active')`, [hib]);

// ---------- Audit ----------
const audit = (await as(admin, `select action, entity from public.audit_log`)).rows.map((r) => r.action + ':' + r.entity);
ok(audit.includes('publish:timetable') && audit.some((a) => a.endsWith(':attendance_records')) && audit.some((a) => a.endsWith(':assessments')) && audit.some((a) => a.startsWith('moderate:')),
  `journal d'audit alimenté par la base (${audit.length} entrées)`);
ok((await as(yas, `select * from public.audit_log`)).rows.length === 0, 'journal illisible pour un stagiaire');
ok(!!(await err(as(admin, `insert into public.audit_log (action, entity) values ('faux', 'x')`))), 'journal non falsifiable (pas d\'insertion directe, même admin)');
await as(admin, `select public.admin_delete_user($1)`, [s3]);
ok((await su(`select count(*)::int n from auth.users where id = $1`, [s3]))[0].n === 0, 'suppression d\'un compte par l\'admin');
ok(!!(await err(as(admin, `select public.admin_delete_user($1)`, [admin]))), 'l\'admin ne peut pas supprimer son propre compte');

console.log(`\n${pass} réussis, ${fail} échoués`);
process.exit(fail ? 1 : 0);
