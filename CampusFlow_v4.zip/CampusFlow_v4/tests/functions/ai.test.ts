// Tests de la fonction IA (Node + --experimental-strip-types) : aucune clé réelle, l'API Anthropic est simulée.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler, validate } from '../../supabase/functions/ai-assistant/handler.ts';

const q = (data: any) => { const b: any = { select: () => b, eq: () => b, order: () => b, limit: () => b, gte: () => b, maybeSingle: () => Promise.resolve({ data }), then: (r: any) => r({ data }) }; return b; };
const userDb = (ok = true) => ({
  auth: { getUser: async () => (ok ? { data: { user: { id: 'u1' } }, error: null } : { data: {}, error: { message: 'bad jwt' } }) },
  from: (t: string) => q(t === 'profiles' ? { full_name: 'Yassine', role: 'student' } : t === 'modules' ? [{ id: 'm1', name: 'Réseaux' }] : t === 'timetable_slots' ? [{ module_id: 'm1', weekday: 1, start_time: '08:30:00', end_time: '10:30:00', status: 'active' }] : []),
});
const setup = (opts: any = {}) => {
  const calls: any[] = [];
  let used = 0;
  const handler = createHandler({
    env: { get: (k: string) => ({ ANTHROPIC_API_KEY: opts.noKey ? undefined : 'test-key', AI_DAILY_LIMIT: '2' } as any)[k] },
    fetch: (async (url: string, init: any) => { calls.push({ url, init: JSON.parse(init.body), headers: init.headers }); return new Response(JSON.stringify({ content: [{ type: 'text', text: 'Révise les VLAN.' }] }), { status: 200 }); }) as any,
    userClient: () => userDb(opts.jwtOk !== false),
    serviceClient: () => ({ rpc: async () => { used++; return used > 2 ? { data: null, error: { message: 'CF:quota|Quota quotidien atteint' } } : { data: 2 - used, error: null }; } }),
  });
  const call = (body: any, auth = 'Bearer abc') => handler(new Request('http://x/ai', { method: 'POST', headers: { Authorization: auth, 'content-type': 'application/json' }, body: JSON.stringify(body) }));
  return { call, calls };
};
const good = { messages: [{ role: 'user', content: 'Comment réviser ?' }], lang: 'fr' };

test('sans clé configurée : 503 not_configured (aucune réponse inventée)', async () => {
  const r = await setup({ noKey: true }).call(good); assert.equal(r.status, 503); assert.equal((await r.json()).error, 'not_configured');
});
test('sans JWT valide : 401', async () => {
  assert.equal((await setup().call(good, '')).status, 401);
  assert.equal((await setup({ jwtOk: false }).call(good)).status, 401);
});
test('validation des messages', () => {
  assert.equal(validate({ messages: [] }), null);
  assert.equal(validate({ messages: [{ role: 'system', content: 'x' }] }), null);
  assert.equal(validate({ messages: [{ role: 'user', content: 'a' }, { role: 'user', content: 'b' }] }), null);
  assert.equal(validate({ messages: [{ role: 'assistant', content: 'a' }] }), null);
  assert.equal(validate({ messages: Array.from({ length: 11 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'x' })) }), null);
  assert.ok(validate(good));
});
test('réponse, contexte de l\'utilisateur et clé envoyée seulement au fournisseur', async () => {
  const s = setup(); const r = await s.call(good); const b = await r.json();
  assert.equal(r.status, 200); assert.equal(b.reply, 'Révise les VLAN.'); assert.equal(b.remaining, 1);
  assert.equal(s.calls[0].url, 'https://api.anthropic.com/v1/messages'); assert.equal(s.calls[0].headers['x-api-key'], 'test-key');
  assert.match(s.calls[0].init.system, /lundi 08:30-10:30 Réseaux/); assert.match(s.calls[0].init.system, /n'as PAS accès aux cours/);
  assert.ok(!JSON.stringify(b).includes('test-key'));
});
test('quota quotidien : 429 au-delà de la limite', async () => {
  const s = setup(); await s.call(good); await s.call(good); const r = await s.call(good);
  assert.equal(r.status, 429); assert.equal((await r.json()).error, 'quota'); assert.equal(s.calls.length, 2);
});
