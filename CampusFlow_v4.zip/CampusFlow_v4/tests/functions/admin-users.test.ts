// Tests de la fonction « admin-users » (aucun vrai compte créé : Auth et base simulés)
import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler, validateInvite } from '../../supabase/functions/admin-users/handler.ts';

const qb = (data: any, rec: any[]) => { const b: any = { select: () => b, eq: () => b, maybeSingle: async () => ({ data }),
  upsert: async (row: any) => { rec.push(['roster', row]); return { error: null }; }, insert: async (row: any) => { rec.push(['audit', row]); return { error: null }; } }; return b; };
const setup = (o: any = {}) => {
  const rec: any[] = [];
  const h = createHandler({
    env: { get: () => undefined },
    userClient: () => ({ auth: { getUser: async () => (o.jwt === false ? { data: {}, error: { message: 'bad' } } : { data: { user: { id: 'admin-1' } }, error: null }) },
      rpc: async () => ({ data: { role: o.role || 'admin', admin: (o.role || 'admin') === 'admin', staff: true, status: 'active' }, error: null }) }),
    serviceClient: () => ({
      from: (t: string) => qb(t === 'groups' ? (o.noGroup ? null : { id: 'g1' }) : t === 'profiles' ? (o.exists ? { id: 'x' } : null) : null, rec),
      auth: { admin: { inviteUserByEmail: async (email: string, opts: any) => { rec.push(['invite', email, opts]); return o.inviteErr ? { data: null, error: { message: o.inviteErr } } : { data: { user: { id: 'new-1' } }, error: null }; } } },
    }),
  });
  const call = (body: any, auth = 'Bearer t') => h(new Request('http://x', { method: 'POST', headers: { Authorization: auth }, body: JSON.stringify(body) }));
  return { call, rec };
};
const good = { action: 'invite', email: 'Nour@OFPPT-edu.ma', full_name: 'Nour Benali', role: 'student', group_code: 'id101' };

test('validation', () => {
  assert.equal(validateInvite({ ...good, email: 'pas-un-email' }), 'email');
  assert.equal(validateInvite({ ...good, full_name: 'X' }), 'name');
  assert.equal(validateInvite({ ...good, role: 'root' }), 'role');
  assert.equal(validateInvite({ ...good, group_code: '' }), 'group');
  const v: any = validateInvite(good); assert.equal(v.email, 'nour@ofppt-edu.ma'); assert.equal(v.group_code, 'ID101');
  assert.equal((validateInvite({ ...good, role: 'teacher' }) as any).group_code, null);
});
test('sans jeton ou jeton invalide : 401', async () => {
  assert.equal((await setup().call(good, '')).status, 401);
  assert.equal((await setup({ jwt: false }).call(good)).status, 401);
});
test('réservé à l\'administration (le rôle est lu en base)', async () => {
  assert.equal((await setup({ role: 'supervisor' }).call(good)).status, 403);
  assert.equal((await setup({ role: 'teacher' }).call(good)).status, 403);
});
test('invitation : liste pré-inscrite puis e-mail, audit', async () => {
  const s = setup(); const r = await s.call(good);
  assert.equal(r.status, 200);
  assert.deepEqual(s.rec[0], ['roster', { email: 'nour@ofppt-edu.ma', full_name: 'Nour Benali', role: 'student', group_id: 'g1' }]);
  assert.equal(s.rec[1][0], 'invite'); assert.equal(s.rec[1][1], 'nour@ofppt-edu.ma');
  assert.equal(s.rec[2][0], 'audit'); assert.equal(s.rec[2][1].actor_id, 'admin-1');
});
test('erreurs : groupe inconnu, compte existant, limite d\'e-mails', async () => {
  assert.equal((await setup({ noGroup: true }).call(good)).status, 400);
  assert.equal((await setup({ exists: true }).call(good)).status, 409);
  assert.equal((await setup({ inviteErr: 'Email rate limit exceeded' }).call(good)).status, 429);
});
