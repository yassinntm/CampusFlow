// Remplace @supabase/supabase-js dans le build de test (alias Vite, mode « e2e »).
// Même interface que la vraie bibliothèque pour ce que l'appli utilise ; le serveur de test applique les vraies règles Postgres.
const KEY = 'cf-e2e-session';
export function createClient(url) {
  const call = (path, payload) => fetch(url + path, { method: 'POST', body: JSON.stringify(payload) }).then((r) => r.json());
  let sess = null; try { sess = JSON.parse(localStorage.getItem(KEY)); } catch { /* vide */ }
  const listeners = [];
  const token = () => sess?.access_token || null;
  const setSess = (s) => { sess = s; s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY); };
  const emit = (ev) => listeners.forEach((l) => l(ev, sess));
  class Query {
    constructor(table) { this.op = { table, kind: null, filters: [], order: [] }; this.mode = null; }
    select(c = '*') { if (!this.op.kind) { this.op.kind = 'select'; this.op.cols = c; } else this.op.returning = c; return this; }
    eq(c, v) { this.op.filters.push([c, 'eq', v]); return this; }
    neq(c, v) { this.op.filters.push([c, 'neq', v]); return this; }
    gt(c, v) { this.op.filters.push([c, 'gt', v]); return this; }
    gte(c, v) { this.op.filters.push([c, 'gte', v]); return this; }
    lt(c, v) { this.op.filters.push([c, 'lt', v]); return this; }
    lte(c, v) { this.op.filters.push([c, 'lte', v]); return this; }
    in(c, v) { this.op.filters.push([c, 'in', v]); return this; }
    is(c, v) { this.op.filters.push([c, 'is', v]); return this; }
    not(c, op, v) { if (op !== 'is') throw new Error('not() : seul « is » est pris en charge'); this.op.filters.push([c, 'notis', v]); return this; }
    // or('a.eq.x,b.eq.y') : sous-ensemble de la syntaxe PostgREST (eq / is)
    or(expr) { this.op.filters.push(['_or', 'or', expr.split(',').map((x) => { const [c, o, ...v] = x.split('.'); return [c, o, v.join('.') === 'null' ? null : v.join('.')]; })]); return this; }
    order(col, o = {}) { this.op.order.push({ col, asc: o.ascending !== false, nullsFirst: o.nullsFirst }); return this; }
    limit(n) { this.op.limit = n; return this; }
    single() { this.mode = 'single'; return this; }
    maybeSingle() { this.mode = 'maybe'; return this; }
    insert(rows) { this.op.kind = 'insert'; this.op.rows = Array.isArray(rows) ? rows : [rows]; return this; }
    upsert(rows, o = {}) { this.op.kind = 'upsert'; this.op.rows = Array.isArray(rows) ? rows : [rows]; this.op.onConflict = o.onConflict || 'id'; this.op.ignoreDuplicates = !!o.ignoreDuplicates; return this; }
    update(v) { this.op.kind = 'update'; this.op.values = v; return this; }
    delete() { this.op.kind = 'delete'; return this; }
    then(ok, ko) {
      return call('/rest', { token: token(), op: this.op }).then((r) => {
        if (r.error) return { data: null, error: r.error };
        let d = r.data;
        if (this.mode === 'single') { if (!d || d.length !== 1) return { data: null, error: { message: 'JSON object requested, multiple (or no) rows returned', code: 'PGRST116' } }; d = d[0]; }
        if (this.mode === 'maybe') d = d?.[0] ?? null;
        return { data: d, error: null };
      }).then(ok, ko);
    }
  }
  const files = new Map();
  return {
    from: (t) => new Query(t),
    rpc: (fn, args) => call('/rpc', { token: token(), fn, args }).then((r) => ({ data: r.error ? null : r.data, error: r.error || null })),
    channel() {
      return { handlers: [], on(_t, _f, cb) { this.handlers.push(cb); return this; },
        subscribe() { let last = null; this.timer = setInterval(async () => { try { const n = await (await fetch(url + '/changes')).text(); if (last !== null && n !== last) this.handlers.forEach((h) => h({})); last = n; } catch { /* serveur arrêté */ } }, 500); return this; } };
    },
    removeChannel(ch) { clearInterval(ch?.timer); },
    functions: { async invoke() { return { data: null, error: { name: 'FunctionsHttpError', message: 'not deployed', context: new Response('{"error":"not_found"}', { status: 404 }) } }; } },
    storage: { from: () => ({
      async upload(p, f) { files.set(p, f); return { data: { path: p }, error: null }; },
      async createSignedUrl(p) { return files.has(p) ? { data: { signedUrl: URL.createObjectURL(files.get(p)) }, error: null } : { data: null, error: { message: 'Object not found' } }; },
      async remove(ps) { ps.forEach((p) => files.delete(p)); return { data: [], error: null }; },
    }) },
    auth: {
      async getSession() { return { data: { session: sess } }; },
      async getUser() { return { data: { user: sess?.user || null }, error: null }; },
      onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
      async signInWithPassword({ email, password }) {
        const r = await call('/auth/signin', { email, password });
        if (r.error) return { data: {}, error: r.error };
        setSess({ access_token: r.data.user.id, user: r.data.user }); emit('SIGNED_IN'); return { data: { session: sess, user: sess.user }, error: null };
      },
      async signUp({ email, password, options }) {
        // Comme Supabase avec « Leaked password protection » : mot de passe connu des fuites refusé
        if (['Password123', 'Azerty123'].includes(password)) return { data: {}, error: { name: 'AuthWeakPasswordError', code: 'weak_password', status: 422, reasons: ['pwned'], message: 'Password is known to be weak and easy to guess, please choose a different one.' } };
        const r = await call('/auth/signup', { email, password, data: options?.data });
        if (r.error) return { data: {}, error: r.error };
        setSess({ access_token: r.data.user.id, user: r.data.user }); emit('SIGNED_IN'); return { data: { session: sess, user: sess.user }, error: null };
      },
      async signOut() { setSess(null); emit('SIGNED_OUT'); return { error: null }; },
      async resetPasswordForEmail() { return { data: {}, error: null }; },
      async updateUser({ password }) { await call('/auth/password', { uid: sess?.user?.id, password }); return { data: { user: sess?.user }, error: null }; },
    },
  };
}
