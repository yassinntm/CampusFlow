# Tests de bout en bout CampusFlow v4 — deux applications (Stagiaire « / » et Administration « /admin/ ») sur le même backend.
# Vrai navigateur (Chrome) + vraie base Postgres (PGlite) avec les migrations, RLS et triggers de production.
# Chaque personne a son propre contexte de navigateur (sessions séparées).
import json, re, sys, time, urllib.request, os
from playwright.sync_api import sync_playwright, expect

BASE = os.environ.get('BASE', 'http://localhost:5173')
STU = BASE + '/index.html'
ADM = BASE + '/admin/index.html'
API = 'http://localhost:5555'
SHOTS = os.path.join(os.path.dirname(__file__), 'screenshots')
os.makedirs(SHOTS, exist_ok=True)
results, errors = [], []

def seed(sql, params=None):
    req = urllib.request.Request(API + '/seed', data=json.dumps({'sql': sql, 'params': params or []}).encode(), method='POST')
    r = json.loads(urllib.request.urlopen(req).read())
    if 'error' in r: raise Exception(r['error']['message'])
    return r['data']

def check(cond, label):
    results.append((bool(cond), label))
    print(('✅ ' if cond else '❌ FAIL ') + label, flush=True)

def step(label, fn):
    try:
        fn(); check(True, label)
    except Exception as e:
        check(False, f'{label} — {str(e).splitlines()[0][:220]}')

KEY_LEAK = re.compile(r'\b(nav|home|sched|plan|att|justif|notif|ann|res|comm|post|report|sg|ride|mod|teach|roll|admin|tt|imp|users|roster|groups|cat|room|audit|exp|profile|search|ai|auth|err|common|kind|prio|progress|due|slot|free|assess|time|config|rules|tile|role|sub|exam|cal|exc|hist|invite|staff|notify|rep|chg|campus|assign|rem)\.[a-z_]{2,}\b')

def new_page(browser, name, url, mobile=False):
    ctx = browser.new_context(viewport={'width': 390, 'height': 844} if mobile else {'width': 1280, 'height': 860}, locale='fr-FR', timezone_id='Africa/Casablanca', accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: errors.append(f'[{name}] {e}'))
    page.on('console', lambda m: errors.append(f'[{name}] console.{m.type}: {m.text}') if m.type == 'error' else None)
    page.on('dialog', lambda d: (errors.append(f'[{name}] dialogue inattendu: {d.message}'), d.dismiss()))
    page.goto(url)
    return page

def shot(page, name):
    page.wait_for_timeout(250)
    page.screenshot(path=os.path.join(SHOTS, name + '.png'), full_page=True)

def no_key_leak(page, where):
    txt = page.inner_text('body')
    leaks = sorted(set(m.group(0) for m in KEY_LEAK.finditer(txt) if not m.group(0).endswith(('.ma', '.pdf', '.co', '.csv', '.txt'))))
    check(not leaks, f'{where} : aucune clé de traduction brute {leaks[:5] if leaks else ""}')

def signup(page, name, email, code=None, password='Campus2026'):
    page.click('[data-tab=signup]')
    page.fill('#fn', name); page.fill('#em', email); page.fill('#pw', password)
    if code: page.fill('#jc', code)
    page.check('[name=consent]')
    page.click('form [type=submit]')

def login(page, email, password='Campus2026'):
    page.click('[data-tab=login]'); page.fill('#em', email); page.fill('#pw', password); page.click('form [type=submit]')

def h1(page, text, timeout=8000):
    expect(page.locator('h1').first).to_contain_text(text, timeout=timeout)

def go(page, url, route, title=None):
    if page.locator('.overlay').count(): page.keyboard.press('Escape')
    page.goto(url + '#/' + route)
    if title: h1(page, title)
    page.wait_for_timeout(300)

def modal(page):
    return page.locator('.sheet')

def toast(page, text, timeout=8000):
    expect(page.locator('#toasts')).to_contain_text(text, timeout=timeout)

def run():
    g = {r['code']: r for r in seed('select code, id, join_code from public.groups')}
    seed("insert into public.roster (email, full_name, role) values ('admin@cmc.ma','Direction CMC','admin'), ('surv@cmc.ma','Said Ouali','supervisor'), "
         "('benali@cmc.ma','Karim Benali','teacher'), ('idrissi@cmc.ma','Nadia Idrissi','teacher')")
    d = seed("""select public.local_today()::text today, extract(isodow from public.local_today())::int dow,
                (select x::date::text from generate_series(public.local_today() - 6, public.local_today() - 1, interval '1 day') x where extract(isodow from x) <> 7 order by x desc limit 1) past,
                (select x::date::text from generate_series(public.local_today(), public.local_today() + 2, interval '1 day') x where extract(isodow from x) <> 7 order by x limit 1) nxt""")[0]
    wd_past = seed(f"select extract(isodow from date '{d['past']}')::int w")[0]['w']
    wd_next = seed(f"select extract(isodow from date '{d['nxt']}')::int w")[0]['w']
    print('Aujourd’hui', d['today'], '(jour', d['dow'], ') — séance passée', d['past'], '— prochaine journée de cours', d['nxt'], flush=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])

        # ================= Comptes et séparation des deux applications =================
        adm = new_page(browser, 'admin', ADM)
        step('admin : écran de connexion de la console (badge Admin)', lambda: (expect(adm.locator('.login-card')).to_contain_text('Admin'), expect(adm.locator('[data-tab=signup]')).to_contain_text('Première connexion')))
        shot(adm, '01_admin_connexion')
        signup(adm, 'Direction CMC', 'admin@cmc.ma')
        step('admin pré-inscrit : vue d’ensemble de la console', lambda: h1(adm, 'Vue d’ensemble'))
        step('admin : barre latérale complète (personnel, audit)', lambda: (expect(adm.locator('.side-nav')).to_contain_text('Personnel'), expect(adm.locator('.side-nav')).to_contain_text('Journal d’audit')))
        no_key_leak(adm, 'vue d’ensemble admin')

        sup = new_page(browser, 'surveillance', ADM)
        signup(sup, 'Said Ouali', 'surv@cmc.ma')
        step('surveillant général : rôle attribué par la liste, menu adapté (pas de Personnel ni d’audit)', lambda: (h1(sup, 'Vue d’ensemble'),
             expect(sup.locator('.side-nav')).to_contain_text('Rapports'), expect(sup.locator('.side-nav')).not_to_contain_text('Personnel'), expect(sup.locator('.side-nav')).not_to_contain_text('Journal d’audit')))

        tch = new_page(browser, 'formateur', ADM)
        signup(tch, 'Karim Benali', 'benali@cmc.ma')
        step('formateur : tableau de bord formateur dans la console', lambda: (h1(tch, 'Bonjour Karim'), expect(tch.locator('.side-nav')).to_contain_text('Appel'), expect(tch.locator('.side-nav')).not_to_contain_text('Stagiaires')))
        tch.goto(STU); tch.wait_for_timeout(1500)
        step('formateur ouvrant l’application stagiaire : renvoyé vers la console', lambda: expect(tch).to_have_url(re.compile(r'/admin/'), timeout=6000))

        stu = new_page(browser, 'stagiaire', STU, mobile=True)
        shot(stu, '02_stagiaire_connexion_mobile')
        signup(stu, 'Intrus', 'intrus@gmail.com', code='ZZZZZZ')
        step('inscription refusée avec un code de groupe invalide', lambda: expect(stu.locator('[role=alert]')).to_contain_text('invalide', timeout=6000))
        stu.goto(STU)
        signup(stu, 'Yassine El Amrani', 'yassine@ofppt-edu.ma', code=g['ID101']['join_code'], password='Password123')
        step('mot de passe refusé : raison précise affichée', lambda: expect(stu.locator('[role=alert]')).to_contain_text('fuites', timeout=6000))
        step('après une erreur, champs conservés (sauf le mot de passe)', lambda: (expect(stu.locator('#fn')).to_have_value('Yassine El Amrani'), expect(stu.locator('#pw')).to_have_value('')))
        stu.goto(STU)
        signup(stu, 'Yassine El Amrani', 'yassine@ofppt-edu.ma', code=g['ID101']['join_code'].lower())
        step('stagiaire inscrit avec le code du groupe ID101', lambda: expect(stu.locator('.hero')).to_contain_text('Bonjour Yassine', timeout=8000))
        check(seed("select role::text r from public.profiles where email = 'yassine@ofppt-edu.ma'")[0]['r'] == 'student', 'rôle stagiaire décidé par la base (pas par le navigateur)')
        no_key_leak(stu, 'accueil stagiaire')
        stu2 = new_page(browser, 'stagiaire2', STU)
        signup(stu2, 'Salma Ait Lahcen', 'salma@ofppt-edu.ma', code=g['ID101']['join_code'])
        expect(stu2.locator('.hero')).to_be_visible(timeout=8000)
        intr = new_page(browser, 'stagiaire-console', ADM)
        login(intr, 'salma@ofppt-edu.ma')
        step('stagiaire ouvrant la console : accès refusé, lien vers son application', lambda: expect(intr.locator('body')).to_contain_text('réservé au personnel', timeout=8000))
        intr.context.close()

        # ================= Administration : référentiel et emploi du temps =================
        go(adm, ADM, 'catalog', 'Modules & salles')
        adm.click('[data-tab=teaching]')
        def assign():
            f = adm.locator('[data-ta]')
            for mod in ['M101 · Réseaux informatiques', 'M102 · Systèmes Linux']:
                f.locator('[name=group_id]').select_option(label='ID101')
                f.locator('[name=module_id]').select_option(label=mod)
                f.locator('[name=teacher_id]').select_option(label='Karim Benali')
                n = adm.locator('table tbody tr').count()
                f.locator('button').click()
                try: expect(adm.locator('table tbody tr')).to_have_count(n + 1, timeout=6000)
                except Exception: print('DEBUG affectation:', adm.inner_text('#toasts'), adm.inner_text('table')[:300]); raise
        step('admin : affectations formateur ↔ groupe ↔ module', assign)
        # Créneau déjà publié pour ID102 avec le même formateur → conflit attendu
        seed("insert into public.teaching_assignments (group_id, module_id, teacher_id) select g.id, m.id, p.id from public.groups g, public.modules m, public.profiles p where g.code='ID102' and m.code='M101' and p.email='benali@cmc.ma'")
        seed(f"insert into public.timetable_slots (group_id, module_id, teacher_id, room_id, weekday, start_time, end_time) select g.id, m.id, p.id, r.id, {wd_next}, '16:30', '18:00' from public.groups g, public.modules m, public.profiles p, public.rooms r where g.code='ID102' and m.code='M101' and p.email='benali@cmc.ma' and r.name='Labo 3'")
        go(adm, ADM, 'timetable', 'Éditeur d’emploi du temps')
        adm.locator('.tabs [data-g]', has_text='ID101').click()
        step('emploi du temps vide : bouton « Modifier » pour ouvrir un brouillon', lambda: expect(adm.locator('[data-start]')).to_be_visible(timeout=6000))
        adm.click('[data-start]')
        def add_slot(day, start, end, module_label, room, teacher='Karim Benali'):
            adm.locator(f'[data-add-day="{day}"]').click()
            m = modal(adm)
            m.locator('[name=module_id]').select_option(label=module_label)
            if teacher: m.locator('[name=teacher_id]').select_option(label=teacher)
            m.locator('[name=start_time]').fill(start); m.locator('[name=end_time]').fill(end)
            m.locator('[name=room_id]').select_option(label=room)
            m.locator('button.primary').click()
            expect(adm.locator('.overlay')).to_have_count(0, timeout=6000)
        add_slot(wd_past, '08:30', '10:30', 'M101 · Réseaux informatiques', 'Labo 1')
        add_slot(wd_next, '08:30', '10:30', 'M101 · Réseaux informatiques', 'Labo 1')
        add_slot(wd_next, '10:45', '12:45', 'M102 · Systèmes Linux', 'Labo 1', teacher=None)
        add_slot(wd_next, '17:00', '18:30', 'M101 · Réseaux informatiques', 'Labo 2')    # conflit formateur (ID102 16:30–18:00)
        step('conflit formateur détecté côté serveur, publication bloquée', lambda: (expect(adm.locator('.conflicts')).to_contain_text('Karim Benali', timeout=6000), expect(adm.locator('[data-preview]')).to_be_disabled()))
        shot(adm, '03_admin_editeur_conflit')
        adm.locator('.eslot.conflict [data-edit]').first.click()
        modal(adm).locator('[name=start_time]').fill('18:15'); modal(adm).locator('[name=end_time]').fill('19:45')
        modal(adm).locator('button.primary').click()
        step('conflit corrigé : « Prévisualiser & publier » disponible', lambda: expect(adm.locator('[data-preview]')).to_be_enabled(timeout=6000))
        adm.click('[data-preview]')
        step('aperçu avant publication : changements listés + aperçu côté stagiaire', lambda: (expect(modal(adm)).to_contain_text('Nouveau cours'), expect(modal(adm).locator('.item')).to_have_count(4), expect(modal(adm)).to_contain_text('Aperçu côté stagiaire')))
        shot(adm, '04_admin_apercu_publication')
        modal(adm).locator('[data-confirm]').click()
        step('publication v1 (stagiaires et formateurs notifiés)', lambda: toast(adm, 'Version 1 publiée'))
        check(seed("select count(*)::int n from public.timetable_slots s join public.groups g on g.id=s.group_id where g.code='ID101'")[0]['n'] == 4, '4 créneaux publiés en base')
        check(seed("select count(*)::int n from public.notifications n join public.profiles p on p.id = n.user_id where p.email='benali@cmc.ma' and n.kind='timetable'")[0]['n'] >= 1, 'formateur notifié personnellement de la publication')
        shot(adm, '05_admin_emploi_du_temps_publie')

        # ================= Stagiaire : accueil, emploi du temps =================
        stu.goto(STU + '#/home'); stu.reload()
        step('stagiaire : carte « prochain cours » avec compte à rebours', lambda: (expect(stu.locator('.next-title')).not_to_have_text('', timeout=8000), expect(stu.locator('.next .countdown')).to_be_visible()))
        step('stagiaire : notification de publication (pastille)', lambda: expect(stu.locator('.hero-bell .dot')).to_be_visible(timeout=6000))
        shot(stu, '06_stagiaire_accueil_mobile')
        go(stu, STU, 'schedule', 'Emploi du temps')
        step('emploi du temps officiel en lecture seule (version 1)', lambda: (expect(stu.locator('.version-card')).to_contain_text('Version 1'), expect(stu.locator('.version-card')).to_contain_text('Officiel')))
        stu.click('[data-mode=week]')
        step('vue semaine', lambda: expect(stu.locator('.wtable .wcell b').first).to_be_visible())
        shot(stu, '07_stagiaire_semaine_mobile')

        # ================= Surveillance : séance annulée ponctuellement =================
        go(sup, ADM, f"timetable/{g['ID101']['id']}", 'Emplois du temps')
        step('surveillance : emploi du temps en lecture seule (aucun bouton d’édition)', lambda: (expect(sup.locator('.draftbar')).to_contain_text('relèvent de l’administration'), expect(sup.locator('[data-start]')).to_have_count(0)))
        sup.locator('[data-date]').fill(d['nxt']); sup.locator('[data-date]').dispatch_event('change'); sup.wait_for_timeout(600)
        sup.locator('.slot', has_text='Systèmes Linux').locator('[data-cancel]').click()
        modal(sup).locator('[name=note]').fill('Formateur en formation')
        modal(sup).locator('button.danger').click()
        step('surveillance : séance du jour annulée et notifiée', lambda: toast(sup, 'Séance annulée'))
        check(seed("select count(*)::int n from public.session_exceptions where kind='cancelled'")[0]['n'] == 1, 'annulation ponctuelle enregistrée en base (emploi du temps hebdomadaire intact)')
        shot(sup, '08_surveillance_seance_annulee')
        stu.goto(STU + '#/schedule'); stu.reload(); stu.click('[data-mode=day]')
        stu.locator(f'[data-date="{d["nxt"]}"]').click()
        step('stagiaire : la séance apparaît « Annulé » ce jour-là', lambda: expect(stu.locator('.slot.cancelled')).to_contain_text('Systèmes Linux', timeout=6000))
        go(stu, STU, 'notifs', 'Notifications')
        step('stagiaire : notification « Séance annulée »', lambda: expect(stu.locator('.item', has_text='Séance annulée')).to_be_visible(timeout=6000))
        stu.click('[data-f=changes]')
        step('filtre « Changements »', lambda: expect(stu.locator('.item')).not_to_have_count(0))

        # ================= Formateur : appel =================
        go(tch, ADM, 'roll', 'Appel')
        tch.locator('a.item').first.click()
        def roll():
            expect(tch.locator('.att-row')).to_have_count(2, timeout=8000)
            tch.locator('.att-row', has_text='Yassine').locator('[data-st=absent]').click()
            tch.locator('.att-row', has_text='Salma').locator('[data-st=late]').click()
            tch.locator('[data-min]').fill('12'); tch.locator('[data-min]').dispatch_event('change')
            tch.click('[data-save]')
            toast(tch, 'Appel enregistré (2)')
        step('formateur : appel enregistré (absent + retard 12 min)', roll)
        shot(tch, '09_formateur_appel')
        r = seed("select a.status, a.minutes_late, p.full_name from public.attendance_records a join public.profiles p on p.id = a.student_id order by p.full_name")
        check([(x['full_name'], x['status'], x['minutes_late']) for x in r] == [('Salma Ait Lahcen', 'late', 12), ('Yassine El Amrani', 'absent', None)], 'présences en base : ' + str([(x['full_name'], x['status']) for x in r]))

        # ================= Justificatif : stagiaire → surveillance =================
        go(stu, STU, 'attendance')
        stu.locator('[data-justify]').first.click()
        modal(stu).locator('[name=reason]').fill('Rendez-vous médical, certificat disponible')
        modal(stu).locator('button.primary').click()
        step('stagiaire : justificatif envoyé (en attente)', lambda: expect(stu.locator('.chip', has_text='En attente')).to_be_visible(timeout=6000))
        go(sup, ADM, 'justifications', 'Justificatifs')
        sup.locator('[data-review$="|1"]').first.click()
        step('surveillance : justificatif accepté', lambda: toast(sup, 'Accepté'))
        check(seed("select a.status from public.attendance_records a join public.profiles p on p.id=a.student_id where p.full_name like 'Yassine%'")[0]['status'] == 'excused', 'absence devenue « justifiée » en base')

        # ================= Devoir : pièce jointe → rendu → retour =================
        att_path = '/tmp/consignes_tp_vlan.pdf'; open(att_path, 'wb').write(b'%PDF-1.4\n% consignes\n')
        go(tch, ADM, 'assessments', 'Devoirs & examens')
        tch.click('[data-new]')
        m = modal(tch)
        m.locator('[name=target]').select_option(label='Réseaux informatiques · ID101')
        m.locator('[name=title]').fill('TP VLAN : rapport de configuration')
        m.locator('[name=description]').fill('Configurez 3 VLAN et rendez le fichier de configuration.')
        m.locator('[name=files]').set_input_files(att_path)
        m.locator('button.primary').click()
        step('formateur : devoir publié avec pièce jointe', lambda: (expect(tch.locator('tr', has_text='TP VLAN')).to_contain_text('0/2', timeout=8000), expect(tch.locator('tr', has_text='TP VLAN')).to_contain_text('1')))
        go(stu, STU, 'assignments', 'Devoirs')
        stu.click('[data-tab=up]')
        stu.locator('.item', has_text='TP VLAN').click()
        step('stagiaire : consignes et pièce jointe visibles', lambda: (expect(modal(stu)).to_contain_text('Configurez 3 VLAN'), expect(modal(stu).locator('[data-att]')).to_have_count(1)))
        sub_path = '/tmp/config_vlan.txt'; open(sub_path, 'w').write('vlan 10\nvlan 20\nvlan 30\n')
        modal(stu).locator('[name=content]').fill('Rapport joint, VLAN 10/20/30 testés.')
        modal(stu).locator('[name=file]').set_input_files(sub_path)
        modal(stu).locator('[data-sub] button').click()
        step('stagiaire : devoir rendu (texte + fichier)', lambda: toast(stu, 'Rendu envoyé'))
        shot(stu, '10_stagiaire_rendu_mobile')
        check(seed("select count(*)::int n from public.submissions where file_name = 'config_vlan.txt'")[0]['n'] == 1, 'rendu enregistré en base (fichier dans le dossier du stagiaire)')
        tch.goto(ADM + '#/assessments'); tch.reload()
        tch.locator('tr', has_text='TP VLAN').locator('[data-subs]').click()
        fb = modal(tch).locator('[data-fb]').first
        fb.locator('[name=feedback]').fill('Bon travail, pensez au VLAN natif.'); fb.locator('[name=grade]').fill('16/20'); fb.locator('button').click()
        step('formateur : retour + note envoyés', lambda: toast(tch, 'Retour envoyé'))
        shot(tch, '11_formateur_rendus')
        stu.goto(STU + '#/assignments'); stu.reload(); stu.click('[data-tab=up]')
        stu.locator('.item', has_text='TP VLAN').click()
        step('stagiaire : retour du formateur visible, rendu verrouillé', lambda: (expect(modal(stu).locator('.feedback')).to_contain_text('VLAN natif', timeout=6000), expect(modal(stu).locator('[data-sub]')).to_have_count(0)))
        stu.keyboard.press('Escape')

        # ================= Examen : préparation =================
        go(tch, ADM, 'assessments', 'Devoirs & examens')
        tch.click('[data-new]')
        m = modal(tch)
        m.locator('[name=kind][value=exam]').check()
        m.locator('[name=target]').select_option(label='Réseaux informatiques · ID101')
        m.locator('[name=title]').fill('Contrôle VLAN & routage'); m.locator('[name=duration_min]').fill('90')
        m.locator('button.primary').click()
        step('formateur : examen publié', lambda: expect(tch.locator('tr', has_text='Contrôle VLAN')).to_be_visible(timeout=6000))
        stu.goto(STU + '#/exams'); stu.reload()
        step('stagiaire : carte d’examen avec compte à rebours en jours', lambda: expect(stu.locator('.exam-card', has_text='Contrôle VLAN').locator('.exam-days')).to_be_visible(timeout=8000))
        stu.locator('.exam-card [data-plan]').first.click()
        modal(stu).locator('[data-yes]').click()
        step('révisions planifiées avant l’examen', lambda: toast(stu, 'révision(s) ajoutée(s)'))

        # ================= Annonces : ciblage, programmation, brouillon =================
        go(adm, ADM, 'announcements', 'Annonces')
        def ann(title, body, target=None, mode='published', users=None):
            adm.click('[data-new]'); m = modal(adm)
            m.locator('[name=title]').fill(title); m.locator('[name=body]').fill(body)
            if target: m.locator('[name=target]').select_option(label=target)
            for u in users or []: m.locator('.picker label', has_text=u).locator('input').check()
            m.locator(f'[name=status][value={mode}]').check()
            m.locator('button.primary').click()
            expect(adm.locator('.overlay')).to_have_count(0, timeout=6000)
        ann('Convocation au bureau', 'Merci de passer au bureau de la surveillance.', target='Stagiaires précis…', users=['Salma'])
        step('annonce ciblée (un stagiaire précis) publiée', lambda: toast(adm, 'Annonce publiée'))
        ann('Journée portes ouvertes', 'Samedi prochain, présentation des filières.', target='Tout l’établissement', mode='scheduled')
        ann('Brouillon calendrier', 'À compléter', target='Tout l’établissement', mode='draft')
        step('programmées et brouillons dans leurs onglets', lambda: (expect(adm.locator('[data-tab=scheduled]')).to_contain_text('1'), expect(adm.locator('[data-tab=draft]')).to_contain_text('1')))
        shot(adm, '12_admin_annonces')
        check(seed("select count(*)::int n from public.notifications where title in ('Journée portes ouvertes', 'Brouillon calendrier')")[0]['n'] == 0, 'aucune notification pour une annonce programmée ou un brouillon')
        go(stu, STU, 'announcements', 'Annonces')
        step('annonce ciblée invisible pour un autre stagiaire ; brouillon et programmée invisibles', lambda: (expect(stu.locator('body')).not_to_contain_text('Convocation au bureau'), expect(stu.locator('body')).not_to_contain_text('Brouillon calendrier'), expect(stu.locator('body')).not_to_contain_text('portes ouvertes')))
        stu2.goto(STU + '#/announcements'); stu2.reload()
        step('annonce ciblée visible par sa destinataire', lambda: expect(stu2.locator('.item', has_text='Convocation au bureau')).to_be_visible(timeout=8000))
        seed("update public.announcements set publish_at = now() - interval '1 minute' where title = 'Journée portes ouvertes'")   # l'heure prévue est atteinte
        go(adm, ADM, 'announcements', 'Annonces')                  # la console publie les annonces échues (en plus du pg_cron serveur)
        stu.goto(STU + '#/announcements'); stu.reload()
        step('annonce programmée publiée à l’heure prévue', lambda: expect(stu.locator('.item', has_text='portes ouvertes')).to_be_visible(timeout=8000))
        go(tch, ADM, 'announcements', 'Annonces')
        tch.click('[data-new]'); m = modal(tch)
        step('formateur : seulement ses groupes (ni « tout l’établissement », ni stagiaires précis)', lambda: (expect(m.locator('[name=target] option', has_text='Tout l’établissement')).to_have_count(0), expect(m.locator('[name=target] option', has_text='Stagiaires précis')).to_have_count(0)))
        m.locator('[name=title]').fill('TP reporté'); m.locator('[name=body]').fill('Le TP de vendredi est reporté à lundi.'); m.locator('[name=important]').check(); m.locator('button.primary').click()
        step('formateur : annonce de groupe publiée', lambda: toast(tch, 'Annonce publiée'))

        # ================= Notification ciblée + taux de lecture =================
        go(sup, ADM, 'notify', 'Envoyer une notification')
        f = sup.locator('[data-compose]')
        f.locator('[name=target]').select_option(value='g:' + g['ID101']['id'])
        f.locator('[name=title]').fill('Badge obligatoire'); f.locator('[name=body]').fill('Contrôle des badges à l’entrée dès lundi.')
        f.locator('button.primary').click()
        step('aperçu de la notification avant envoi', lambda: expect(modal(sup)).to_contain_text('2 stagiaire(s) la recevront'))
        modal(sup).locator('[data-send]').click()
        step('notification envoyée au groupe', lambda: toast(sup, 'Notification envoyée à 2'))
        stu.goto(STU + '#/notifs'); stu.reload()
        stu.locator('.item', has_text='Badge obligatoire').click(); stu.wait_for_timeout(600)
        sup.reload(); h1(sup, 'Envoyer une notification')
        step('taux de lecture réel (1/2 lus)', lambda: expect(sup.locator('.audit', has_text='Badge obligatoire')).to_contain_text('1/2 lus', timeout=6000))
        shot(sup, '13_surveillance_notifications')

        # ================= Calendrier académique =================
        go(adm, ADM, 'calendar', 'Calendrier académique')
        adm.click('[data-new]'); m = modal(adm)
        m.locator('[name=title]').fill('Vacances de mi-année'); m.locator('[name=kind]').select_option('holiday')
        m.locator('[name=start_date]').fill(d['today']); m.locator('[name=end_date]').fill(d['nxt'])
        m.locator('button.primary').click()
        step('admin : événement ajouté au calendrier académique', lambda: expect(adm.locator('tr', has_text='Vacances de mi-année')).to_be_visible(timeout=6000))
        go(stu, STU, 'planner/cal')
        step('stagiaire : événement visible dans son calendrier', lambda: expect(stu.locator('body')).to_contain_text('Vacances de mi-année', timeout=8000))
        shot(stu, '14_stagiaire_calendrier_mobile')

        # ================= Communauté et modération par la surveillance =================
        go(stu, STU, 'community', 'Communauté')
        stu.click('[data-new-post]'); m = modal(stu)
        m.locator('[name=title]').fill('<img src=x onerror=alert(1)> VLAN ?')
        m.locator('[name=body]').fill('Le ping inter-VLAN ne passe pas <script>alert(2)</script>, une idée ?')
        m.locator('[name=anonymous]').check(); m.locator('button.primary').click()
        step('question anonyme publiée', lambda: expect(stu.locator('article h2')).to_contain_text('<img src=x', timeout=6000))
        check(stu.locator('article img').count() == 0 and stu.locator('article script').count() == 0, 'XSS : HTML saisi affiché comme texte, jamais exécuté')
        stu2.goto(STU + '#/community'); stu2.reload()
        step('camarade : auteur masqué « Anonyme »', lambda: expect(stu2.locator('.qcard').first).to_contain_text('Anonyme', timeout=8000))
        stu2.locator('.qcard a').first.click()
        stu2.locator('[data-report][data-kind=post]').click(); modal(stu2).locator('button.danger').click()
        step('signalement envoyé', lambda: toast(stu2, 'Signalement envoyé'))
        go(sup, ADM, 'moderation', 'Modération')
        step('surveillance : signalement avec motif et auteur réel', lambda: (expect(sup.locator('.card', has_text='Spam')).to_be_visible(timeout=8000), expect(sup.locator('.card', has_text='Spam')).to_contain_text('Yassine')))
        sup.locator('[data-mod=hide]').first.click()
        modal(sup).locator('[name=r]').fill('Contenu à reformuler'); modal(sup).locator('button.primary').click()
        step('surveillance : contenu masqué', lambda: toast(sup, 'Contenu masqué'))
        stu2.goto(STU + '#/community'); stu2.reload()
        step('contenu masqué invisible pour les camarades', lambda: expect(stu2.locator('.qcard')).to_have_count(0, timeout=8000))

        # ================= Covoiturage : contacts selon le consentement =================
        seed("update public.profiles set phone = '0612345678' where email = 'yassine@ofppt-edu.ma'")
        stu.goto(STU + '#/profile'); stu.reload(); h1(stu, 'Mon profil')
        stu.locator('[data-share]').evaluate('e => e.click()'); stu.wait_for_timeout(800)
        check(seed("select share_phone from public.profiles where email = 'yassine@ofppt-edu.ma'")[0]['share_phone'] is True, 'confidentialité : partage du téléphone activé par le stagiaire lui-même')
        go(stu, STU, 'rides', 'Covoiturage')
        stu.click('[data-new-ride]'); m = modal(stu)
        m.locator('[name=from_place]').fill('Dakhla'); m.locator('button.primary').click()
        step('stagiaire : trajet proposé', lambda: expect(stu.locator('.card', has_text='Dakhla')).to_be_visible(timeout=6000))
        go(stu2, STU, 'rides', 'Covoiturage')
        stu2.locator('[data-book]').first.click(); stu2.wait_for_timeout(900)
        stu2.locator('[data-contacts]').first.click()
        step('passager : téléphone du conducteur (partage accepté)', lambda: expect(modal(stu2)).to_contain_text('0612345678', timeout=6000))
        stu2.keyboard.press('Escape')

        # ================= Recherche globale, assistant =================
        stu.goto(STU + '#/home'); stu.locator('[data-open-search]').first.click()
        stu.locator('[data-q]').fill('vlan')
        step('recherche globale : devoir et examen trouvés, terme surligné', lambda: (expect(stu.locator('.search-res')).to_contain_text('Contrôle VLAN', timeout=6000), expect(stu.locator('.search-res mark').first).to_be_visible()))
        shot(stu, '15_stagiaire_recherche_mobile')
        stu.keyboard.press('Escape')
        go(stu, STU, 'ai')
        stu.locator('[data-s]').first.click()
        step('assistant non déployé : message honnête, aucune réponse inventée', lambda: (expect(stu.locator('.warn')).to_contain_text('pas activé', timeout=6000), expect(stu.locator('.bubble.assistant')).to_have_count(0)))

        # ================= Administration : comptes, invitations, import =================
        go(adm, ADM, 'students', 'Stagiaires')
        step('stagiaires : présences réelles dans le tableau', lambda: expect(adm.locator('tr', has_text='Salma')).to_contain_text('1', timeout=6000))
        adm.click('[data-invite]'); m = modal(adm)
        m.locator('[name=full_name]').fill('Nour Badri'); m.locator('[name=email]').fill('nour@ofppt-edu.ma'); m.locator('[name=group_code]').select_option('ID101')
        m.locator('button.primary').click()
        step('invitation sans fonction e-mail déployée : ajout honnête à la liste pré-inscrite', lambda: toast(adm, 'ajouté à la liste pré-inscrite'))
        check(seed("select count(*)::int n from public.roster where email = 'nour@ofppt-edu.ma'")[0]['n'] == 1, 'invitation : adresse pré-inscrite en base')
        adm.locator('tr', has_text='salma@ofppt-edu.ma').locator('[data-status]').click(); adm.locator('.sheet [data-yes]').click()
        step('admin : compte suspendu', lambda: expect(adm.locator('tr', has_text='salma@ofppt-edu.ma')).to_contain_text('Suspendu', timeout=6000))
        stu2.goto(STU + '#/home'); stu2.reload()
        step('compte suspendu : accès coupé', lambda: expect(stu2.locator('body')).to_contain_text('suspendu', timeout=8000))
        adm.click('[data-tab=roster]')
        csv_path = '/tmp/liste.csv'
        open(csv_path, 'w', encoding='utf-8').write('email;full_name;role;group_code\nomar@ofppt-edu.ma;Omar;student;ID101\npas-un-email;X;student;ID101\nali@ofppt-edu.ma;Ali;student;ZZ9\n')
        adm.click('[data-import]'); modal(adm).locator('[data-file]').set_input_files(csv_path)
        step('import CSV : test à blanc, erreurs par ligne, import bloqué', lambda: (expect(modal(adm)).to_contain_text('2 erreur', timeout=6000), expect(modal(adm).locator('[data-go]')).to_be_disabled()))
        open(csv_path, 'w', encoding='utf-8').write('email;full_name;role;group_code\nomar@ofppt-edu.ma;Omar;student;ID101\nidrissi@cmc.ma;Nadia Idrissi;teacher;\n')
        modal(adm).locator('[data-file]').set_input_files(csv_path)
        step('import CSV : doublon détecté', lambda: expect(modal(adm)).to_contain_text('1 déjà présent', timeout=6000))
        modal(adm).locator('[data-go]').click()
        step('import CSV réel', lambda: expect(adm.locator('table')).to_contain_text('omar@ofppt-edu.ma', timeout=6000))
        go(adm, ADM, 'staff', 'Personnel')
        step('personnel : formateurs avec leurs enseignements, surveillance', lambda: (expect(adm.locator('tr', has_text='Karim Benali')).to_contain_text('Réseaux informatiques'), expect(adm.locator('tr', has_text='Said Ouali')).to_contain_text('Surveillance')))
        adm.locator('tr', has_text='Karim Benali').locator('[data-sched]').click()
        step('emploi du temps d’un formateur (tous groupes)', lambda: expect(modal(adm).locator('.wcell b').first).to_be_visible(timeout=6000))
        adm.keyboard.press('Escape')

        # ================= Historique, rapports, audit, exports =================
        go(adm, ADM, 'history', 'Historique')
        step('historique : v1 actuelle de ID101', lambda: expect(adm.locator('.card', has_text='Version 1')).to_contain_text('Actuelle'))
        adm.locator('.card', has_text='Version 1').locator('[data-view]').first.click()
        step('historique : aperçu de la version (grille)', lambda: expect(modal(adm).locator('.wtable')).to_be_visible())
        adm.keyboard.press('Escape')
        go(adm, ADM, 'reports', 'Rapports')
        step('rapports : chiffres réels par groupe', lambda: expect(adm.locator('tr', has_text='ID101')).to_contain_text('v1'))
        with adm.expect_download() as dl: adm.click('[data-csv=groups]')
        check('groupe;stagiaires' in open(dl.value.path(), encoding='utf-8-sig').read().replace('\r', ''), 'rapport CSV par groupe téléchargé')
        shot(adm, '16_admin_rapports')
        go(adm, ADM, 'audit', 'Journal d’audit')
        step('journal d’audit : publication, annulation de séance, retour sur rendu', lambda: (expect(adm.locator('table')).to_contain_text('Publication'), expect(adm.locator('table')).to_contain_text('Séance annulée'), expect(adm.locator('table')).to_contain_text('Retour sur un rendu')))
        shot(adm, '17_admin_audit')
        sup.goto(ADM + '#/audit'); sup.wait_for_timeout(800)
        step('surveillance : pas d’accès au journal d’audit', lambda: expect(sup.locator('h1').first).not_to_contain_text('audit'))
        check(len(seed("select 1 from public.audit_log")) > 0, 'journal d’audit non vide en base')
        go(adm, ADM, 'exports', 'Exports')
        with adm.expect_download() as dl: adm.click('[data-x=attendance]')
        content = open(dl.value.path(), encoding='utf-8-sig').read()
        check('stagiaire' in content and 'excused' in content, 'export CSV des présences (UTF-8, « ; »)')
        go(adm, ADM, 'overview', 'Vue d’ensemble')
        step('vue d’ensemble : vrais chiffres (1 stagiaire actif après suspension)', lambda: expect(adm.locator('.kpis .stat').first).to_contain_text('1', timeout=8000))
        step('vue d’ensemble : carte de groupe ID101 v1 « À jour »', lambda: expect(adm.locator('.gcards .card', has_text='ID101')).to_contain_text('v1'))
        shot(adm, '18_admin_vue_ensemble')
        go(adm, ADM, 'history', 'Historique')
        adm.locator('.card', has_text='Version 1').locator('[data-view]').first.wait_for()
        seed(f"""insert into public.timetable_versions (group_id, version, changes, snapshot) values ('{g['ID101']['id']}', 2, '[{{"type":"edit","text":"Version de test"}}]', '[]')""")
        adm.reload(); h1(adm, 'Historique')
        adm.locator('.card', has_text='Version 1').locator('[data-restore]').click(); modal(adm).locator('[data-yes]').click()
        step('restauration d’une ancienne version dans le brouillon', lambda: (toast(adm, 'copiés dans le brouillon'), expect(adm.locator('.draftbar')).to_be_visible(timeout=6000)))
        seed(f"delete from public.timetable_drafts where group_id = '{g['ID101']['id']}'"); seed(f"delete from public.timetable_versions where group_id = '{g['ID101']['id']}' and version = 2")

        # ================= Profil et accessibilité =================
        go(stu, STU, 'profile', 'Mon profil')
        stu.locator('[data-font=large]').click()
        step('accessibilité : taille du texte appliquée', lambda: expect(stu.locator('html')).to_have_attribute('data-fontsize', 'large'))
        stu.locator('[data-font=normal]').click()

        # ================= Arabe / RTL — les deux applications =================
        go(stu, STU, 'profile', 'Mon profil'); stu.locator('[data-lang=ar]').click()
        step('stagiaire en arabe : RTL', lambda: (expect(stu.locator('html')).to_have_attribute('dir', 'rtl', timeout=6000), expect(stu.locator('html')).to_have_attribute('lang', 'ar')))
        for route in ['home', 'schedule', 'assignments', 'exams', 'planner', 'planner/cal', 'announcements', 'community', 'campus', 'attendance', 'notifs', 'profile', 'ai', 'freetime', 'rides']:
            stu.goto(STU + '#/' + route); stu.wait_for_timeout(450); no_key_leak(stu, f'stagiaire {route} (arabe)')
        stu.goto(STU + '#/home'); shot(stu, '19_stagiaire_accueil_arabe_mobile')
        stu.goto(STU + '#/schedule'); shot(stu, '20_stagiaire_emploi_du_temps_arabe_mobile')
        go(adm, ADM, 'overview', 'Vue d’ensemble')
        adm.locator('.side-foot [data-lang]').click()
        step('console en arabe : RTL', lambda: expect(adm.locator('html')).to_have_attribute('dir', 'rtl', timeout=6000))
        for route in ['overview', 'timetable', 'history', 'roll', 'attendance', 'justifications', 'assessments', 'resources', 'calendar', 'announcements', 'notify', 'students', 'staff', 'groups', 'catalog', 'moderation', 'reports', 'audit', 'exports', 'notifs']:
            adm.goto(ADM + '#/' + route); adm.wait_for_timeout(450); no_key_leak(adm, f'console {route} (arabe)')
        adm.goto(ADM + '#/overview'); shot(adm, '21_admin_vue_ensemble_arabe')
        adm.goto(ADM + '#/timetable'); shot(adm, '22_admin_editeur_arabe')
        adm.locator('.side-foot [data-lang]').click()
        for route in ['overview', 'timetable', 'history', 'roll', 'attendance', 'justifications', 'assessments', 'resources', 'calendar', 'announcements', 'notify', 'students', 'staff', 'groups', 'catalog', 'moderation', 'reports', 'audit', 'exports', 'notifs']:
            adm.goto(ADM + '#/' + route); adm.wait_for_timeout(350); no_key_leak(adm, f'console {route} (français)')
        go(stu, STU, 'profile'); stu.locator('[data-lang=fr]').click(); stu.wait_for_timeout(500)

        # ================= Thème sombre, mobile =================
        adm.locator('.side-foot [data-theme-toggle]').click()
        step('console : thème sombre', lambda: expect(adm.locator('html')).to_have_attribute('data-theme', 'dark'))
        go(adm, ADM, 'overview'); shot(adm, '23_admin_sombre'); adm.locator('.side-foot [data-theme-toggle]').click()
        am = new_page(browser, 'admin-mobile', ADM, mobile=True)
        login(am, 'admin@cmc.ma'); h1(am, 'Vue d’ensemble')
        shot(am, '24_admin_mobile')
        am.goto(ADM + '#/timetable'); am.wait_for_timeout(600); shot(am, '25_admin_editeur_mobile')
        tm = new_page(browser, 'formateur-mobile', ADM, mobile=True)
        login(tm, 'benali@cmc.ma'); h1(tm, 'Bonjour Karim')
        tm.goto(ADM + '#/roll'); tm.wait_for_timeout(600); shot(tm, '26_formateur_appel_mobile')
        for page_, nm in [(am, 'console admin'), (tm, 'console formateur'), (stu, 'stagiaire')]:
            for route in (['overview', 'timetable', 'students', 'reports'] if page_ is am else ['overview', 'roll', 'assessments'] if page_ is tm else ['home', 'schedule', 'planner', 'community']):
                page_.goto((ADM if page_ is not stu else STU) + '#/' + route); page_.wait_for_timeout(350)
                w = page_.evaluate('document.documentElement.scrollWidth')
                check(w <= 392, f'mobile {nm} {route} : pas de défilement horizontal ({w}px)')
        browser.close()

if __name__ == '__main__':
    t0 = time.time()
    try:
        run()
    except Exception as e:
        import traceback
        where = [f'ligne {fr.lineno}' for fr in traceback.extract_tb(e.__traceback__) if fr.filename.endswith('e2e.py')][-1:]
        check(False, f'scénario interrompu ({", ".join(where)}) : ' + str(e).splitlines()[0][:300])
    real_errors = [e for e in errors if 'favicon' not in e]
    check(not real_errors, f'aucune erreur JavaScript / console ({len(real_errors)})')
    for e in real_errors[:15]: print('   ', e[:300])
    ok = sum(1 for c, _ in results if c)
    print(f'\n{ok} réussis, {len(results) - ok} échoués — {time.time() - t0:.0f} s')
    sys.exit(0 if ok == len(results) else 1)
