// Serveur de test « façon PostgREST/GoTrue » : chaque requête de l'appli s'exécute dans Postgres (PGlite)
// avec le rôle authenticated/anon et auth.uid() = l'utilisateur connecté → les vraies règles RLS, droits de colonnes et triggers s'appliquent.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { makeDb, asUser } from '../db/pg.mjs';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
// Comme PostgREST : les dates (type 1082) sont renvoyées en texte 'YYYY-MM-DD', pas en objets Date
const db = await makeDb(path.join(ROOT, 'supabase/migrations'), { parsers: { 1082: (v) => v } });
let changes = 0;
const ID = /^[a-z_][a-z0-9_]*$/;
const id = (x) => { if (!ID.test(x)) throw Object.assign(new Error('identifiant invalide: ' + x), { code: 'PGRST100' }); return x; };
const hash = (p) => crypto.createHash('sha256').update('cf:' + p).digest('hex');
const OPS = { eq: '=', neq: '<>', gt: '>', gte: '>=', lt: '<', lte: '<=' };

const val = (v) => (v !== null && typeof v === 'object' ? JSON.stringify(v) : v);
// Les tableaux JS (ex. days smallint[]) sont convertis en littéraux Postgres
const arrLit = (a) => '{' + a.map((x) => (x === null ? 'NULL' : '"' + String(x).replace(/["\\]/g, '\\$&') + '"')).join(',') + '}';
const param = (v) => (Array.isArray(v) && v.every((x) => typeof x !== 'object' || x === null) ? arrLit(v) : val(v));

function where(filters, params) {
  if (!filters?.length) return '';
  const one = ([c, op, v]) => {
    if (op === 'or') return '(' + v.map(one).join(' or ') + ')';
    id(c);
    if (op === 'notis') return `${c} is not ${v === null ? 'null' : v ? 'true' : 'false'}`;
    if (op === 'in') { params.push(arrLit(v)); return `${c}::text = any($${params.length}::text[])`; }
    if (op === 'is') return `${c} is ${v === null ? 'null' : v ? 'true' : 'false'}`;
    params.push(val(v)); return `${c} ${OPS[op]} $${params.length}`;
  };
  return ' where ' + filters.map(one).join(' and ');
}
const cols = (c) => (!c || c.trim() === '*' ? '*' : c.split(',').map((x) => id(x.trim())).join(', '));

async function rest(uid, op) {
  const t = 'public.' + id(op.table);
  const p = [];
  let sql;
  if (op.kind === 'select') {
    sql = `select ${cols(op.cols)} from ${t}${where(op.filters, p)}`;
    if (op.order?.length) sql += ' order by ' + op.order.map((o) => `${id(o.col)} ${o.asc ? 'asc' : 'desc'}${o.nullsFirst === true ? ' nulls first' : o.nullsFirst === false ? ' nulls last' : ''}`).join(', ');
    if (op.limit) sql += ' limit ' + Number(op.limit);
  } else if (op.kind === 'insert' || op.kind === 'upsert') {
    const keys = [...new Set(op.rows.flatMap((r) => Object.keys(r)))].map(id);
    const values = op.rows.map((r) => '(' + keys.map((k) => (k in r ? (p.push(param(r[k])), `$${p.length}`) : 'default')).join(', ') + ')').join(', ');
    sql = `insert into ${t} (${keys.join(', ')}) values ${values}`;
    if (op.kind === 'upsert') {
      const conflict = op.onConflict.split(',').map((x) => id(x.trim()));
      const upd = keys.filter((k) => !conflict.includes(k));
      sql += ` on conflict (${conflict.join(', ')}) ` + (op.ignoreDuplicates || !upd.length ? 'do nothing' : 'do update set ' + upd.map((k) => `${k} = excluded.${k}`).join(', '));
    }
  } else if (op.kind === 'update') {
    const keys = Object.keys(op.values).map(id);
    sql = `update ${t} set ` + keys.map((k) => (p.push(param(op.values[k])), `${k} = $${p.length}`)).join(', ') + where(op.filters, p);
  } else if (op.kind === 'delete') {
    sql = `delete from ${t}` + where(op.filters, p);
  } else throw new Error('opération inconnue');
  if (op.kind !== 'select' && op.returning) sql += ` returning ${cols(op.returning)}`;      // comme PostgREST : « return=representation » seulement si demandé
  const r = await asUser(db, uid, sql, p);
  if (op.kind !== 'select') changes++;
  return op.kind === 'select' || op.returning ? r.rows : null;
}
async function rpc(uid, fn, args) {
  id(fn);
  const info = (await db.query(`select p.proretset, t.typname from pg_proc p join pg_type t on t.oid = p.prorettype join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and p.proname = $1`, [fn])).rows[0];
  if (!info) throw Object.assign(new Error('fonction inconnue'), { code: 'PGRST202' });
  const keys = Object.keys(args || {}).map(id);
  const p = keys.map((k) => param(args[k]));        // tableaux de valeurs simples → littéral Postgres (ex. uuid[]), objets → JSON
  const call = `public.${fn}(${keys.map((k, i) => `${k} => $${i + 1}`).join(', ')})`;
  const r = await asUser(db, uid, info.proretset ? `select * from ${call}` : `select ${call} as v`, p);
  changes++;
  return info.proretset ? r.rows : info.typname === 'void' ? null : r.rows[0].v;
}
async function auth(action, body) {
  if (action === 'signup') {
    try {
      const u = (await db.query(`insert into auth.users (email, raw_user_meta_data, encrypted_password) values (lower($1), $2, $3) returning id, email`, [body.email, JSON.stringify(body.data || {}), hash(body.password)])).rows[0];
      changes++; return { user: u };
    } catch (e) {
      // Comme GoTrue : l'erreur du trigger n'est pas transmise telle quelle
      throw Object.assign(new Error(/unique|duplicate/.test(e.message) ? 'User already registered' : 'Database error saving new user'), { code: 'unexpected_failure' });
    }
  }
  if (action === 'signin') {
    const u = (await db.query(`select id, email from auth.users where email = lower($1) and encrypted_password = $2`, [body.email, hash(body.password)])).rows[0];
    if (!u) throw Object.assign(new Error('Invalid login credentials'), { code: 'invalid_credentials' });
    return { user: u };
  }
  if (action === 'password') { await db.query(`update auth.users set encrypted_password = $2 where id = $1`, [body.uid, hash(body.password)]); return {}; }
  throw new Error('action inconnue');
}
// Outils réservés aux tests (préparation des données, horloge) — jamais exposés par l'appli
async function seed(sql, params) { const r = await db.query(sql, params); changes++; return r.rows; }

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') return res.end();
  if (req.url === '/changes') return res.end(String(changes));
  let body = '';
  for await (const c of req) body += c;
  const b = body ? JSON.parse(body) : {};
  const uid = b.token || null;
  try {
    let data;
    if (req.url === '/rest') data = await rest(uid, b.op);
    else if (req.url === '/rpc') data = await rpc(uid, b.fn, b.args);
    else if (req.url.startsWith('/auth/')) data = await auth(req.url.slice(6), b);
    else if (req.url === '/seed') data = await seed(b.sql, b.params);
    else { res.statusCode = 404; return res.end(JSON.stringify({ error: { message: 'not found' } })); }
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ data }));
  } catch (e) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ error: { message: e.message, code: e.code || null, details: e.detail || null } }));
  }
});
server.listen(Number(process.env.PORT || 5555), () => console.log('backend de test prêt sur', server.address().port));
