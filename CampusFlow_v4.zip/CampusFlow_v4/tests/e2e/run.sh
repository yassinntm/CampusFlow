#!/usr/bin/env bash
# Lance les tests de bout en bout : build de test des deux applications, backend PGlite neuf, serveur statique, Chrome.
set -euo pipefail
cd "$(dirname "$0")/../../app"
npx vite build --mode e2e --outDir dist-e2e >/dev/null
node ../tests/e2e/server.mjs > /tmp/cf-e2e-api.log 2>&1 & API=$!
python3 -m http.server 5173 -d dist-e2e > /tmp/cf-e2e-web.log 2>&1 & WEB=$!
trap 'kill $API $WEB 2>/dev/null || true' EXIT
for i in $(seq 1 60); do curl -sf -X POST http://localhost:5555/changes >/dev/null 2>&1 && break; curl -s http://localhost:5555/changes >/dev/null 2>&1 && break; sleep 0.5; done
python3 ../tests/e2e/e2e.py
