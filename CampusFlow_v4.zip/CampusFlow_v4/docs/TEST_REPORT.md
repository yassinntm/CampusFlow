# Rapport de tests — CampusFlow v4 (22/11/2026)

Tous les chiffres ci-dessous viennent d'exécutions réelles (`tests/run_all.sh`). Résultats bruts : `tests/results/*.txt` ; captures : `tests/e2e/screenshots/`.

| Suite | Ce qui est testé | Résultat |
|---|---|---|
| Base de données (`tests/db/test_db.mjs`) | RLS, triggers, fonctions (inscription, rôles, emploi du temps, appel, communauté, anti-spam, audit) sur Postgres avec les migrations 0001→0009 | **112 / 112** |
| Base — plateforme double (`tests/db/test_platform.mjs`) | surveillance (droits et limites), séances annulées/déplacées, annonces brouillon/programmées/ciblées, statistiques de lecture, messages personnels, rendus et retours, calendrier, contacts de covoiturage, restauration de version, rapports | **72 / 72** |
| Fonctions Edge (`tests/functions/*.test.ts`) | assistant IA (validation, quota, clé absente) ; invitations (jeton, rôle admin relu en base, validation, doublons, erreurs e-mail) | **10 / 10** |
| Unitaires front (`app/tests/unit`) | échappement XSS, liens https, dates et fuseau Africa/Casablanca, traductions FR/AR (mêmes clés, mêmes variables, aucune clé manquante y compris dynamiques) | **10 / 10** |
| Build de production | Vite : `index.html` + `admin/index.html` | **OK** |
| Bout en bout (`tests/e2e/e2e.py`) | Chrome réel, 9 sessions séparées (administration, surveillance, formateur, 2 stagiaires, intrus, mobiles), 1280 px et 390 px, contre Postgres avec les migrations de production — les deux applications et leur intégration | **163 / 163**, 0 erreur JavaScript/console ; relancé 4 fois de suite sans échec |

## Détail du scénario de bout en bout
    ✅ admin : écran de connexion de la console (badge Admin)
    ✅ admin pré-inscrit : vue d’ensemble de la console
    ✅ admin : barre latérale complète (personnel, audit)
    ✅ vue d’ensemble admin : aucune clé de traduction brute 
    ✅ surveillant général : rôle attribué par la liste, menu adapté (pas de Personnel ni d’audit)
    ✅ formateur : tableau de bord formateur dans la console
    ✅ formateur ouvrant l’application stagiaire : renvoyé vers la console
    ✅ inscription refusée avec un code de groupe invalide
    ✅ mot de passe refusé : raison précise affichée
    ✅ après une erreur, champs conservés (sauf le mot de passe)
    ✅ stagiaire inscrit avec le code du groupe ID101
    ✅ rôle stagiaire décidé par la base (pas par le navigateur)
    ✅ accueil stagiaire : aucune clé de traduction brute 
    ✅ stagiaire ouvrant la console : accès refusé, lien vers son application
    ✅ admin : affectations formateur ↔ groupe ↔ module
    ✅ emploi du temps vide : bouton « Modifier » pour ouvrir un brouillon
    ✅ conflit formateur détecté côté serveur, publication bloquée
    ✅ conflit corrigé : « Prévisualiser & publier » disponible
    ✅ aperçu avant publication : changements listés + aperçu côté stagiaire
    ✅ publication v1 (stagiaires et formateurs notifiés)
    ✅ 4 créneaux publiés en base
    ✅ formateur notifié personnellement de la publication
    ✅ stagiaire : carte « prochain cours » avec compte à rebours
    ✅ stagiaire : notification de publication (pastille)
    ✅ emploi du temps officiel en lecture seule (version 1)
    ✅ vue semaine
    ✅ surveillance : emploi du temps en lecture seule (aucun bouton d’édition)
    ✅ surveillance : séance du jour annulée et notifiée
    ✅ annulation ponctuelle enregistrée en base (emploi du temps hebdomadaire intact)
    ✅ stagiaire : la séance apparaît « Annulé » ce jour-là
    ✅ stagiaire : notification « Séance annulée »
    ✅ filtre « Changements »
    ✅ formateur : appel enregistré (absent + retard 12 min)
    ✅ présences en base : [('Salma Ait Lahcen', 'late'), ('Yassine El Amrani', 'absent')]
    ✅ stagiaire : justificatif envoyé (en attente)
    ✅ surveillance : justificatif accepté
    ✅ absence devenue « justifiée » en base
    ✅ formateur : devoir publié avec pièce jointe
    ✅ stagiaire : consignes et pièce jointe visibles
    ✅ stagiaire : devoir rendu (texte + fichier)
    ✅ rendu enregistré en base (fichier dans le dossier du stagiaire)
    ✅ formateur : retour + note envoyés
    ✅ stagiaire : retour du formateur visible, rendu verrouillé
    ✅ formateur : examen publié
    ✅ stagiaire : carte d’examen avec compte à rebours en jours
    ✅ révisions planifiées avant l’examen
    ✅ annonce ciblée (un stagiaire précis) publiée
    ✅ programmées et brouillons dans leurs onglets
    ✅ aucune notification pour une annonce programmée ou un brouillon
    ✅ annonce ciblée invisible pour un autre stagiaire ; brouillon et programmée invisibles
    ✅ annonce ciblée visible par sa destinataire
    ✅ annonce programmée publiée à l’heure prévue
    ✅ formateur : seulement ses groupes (ni « tout l’établissement », ni stagiaires précis)
    ✅ formateur : annonce de groupe publiée
    ✅ aperçu de la notification avant envoi
    ✅ notification envoyée au groupe
    ✅ taux de lecture réel (1/2 lus)
    ✅ admin : événement ajouté au calendrier académique
    ✅ stagiaire : événement visible dans son calendrier
    ✅ question anonyme publiée
    ✅ XSS : HTML saisi affiché comme texte, jamais exécuté
    ✅ camarade : auteur masqué « Anonyme »
    ✅ signalement envoyé
    ✅ surveillance : signalement avec motif et auteur réel
    ✅ surveillance : contenu masqué
    ✅ contenu masqué invisible pour les camarades
    ✅ confidentialité : partage du téléphone activé par le stagiaire lui-même
    ✅ stagiaire : trajet proposé
    ✅ passager : téléphone du conducteur (partage accepté)
    ✅ recherche globale : devoir et examen trouvés, terme surligné
    ✅ assistant non déployé : message honnête, aucune réponse inventée
    ✅ stagiaires : présences réelles dans le tableau
    ✅ invitation sans fonction e-mail déployée : ajout honnête à la liste pré-inscrite
    ✅ invitation : adresse pré-inscrite en base
    ✅ admin : compte suspendu
    ✅ compte suspendu : accès coupé
    ✅ import CSV : test à blanc, erreurs par ligne, import bloqué
    ✅ import CSV : doublon détecté
    ✅ import CSV réel
    ✅ personnel : formateurs avec leurs enseignements, surveillance
    ✅ emploi du temps d’un formateur (tous groupes)
    ✅ historique : v1 actuelle de ID101
    ✅ historique : aperçu de la version (grille)
    ✅ rapports : chiffres réels par groupe
    ✅ rapport CSV par groupe téléchargé
    ✅ journal d’audit : publication, annulation de séance, retour sur rendu
    ✅ surveillance : pas d’accès au journal d’audit
    ✅ journal d’audit non vide en base
    ✅ export CSV des présences (UTF-8, « ; »)
    ✅ vue d’ensemble : vrais chiffres (1 stagiaire actif après suspension)
    ✅ vue d’ensemble : carte de groupe ID101 v1 « À jour »
    ✅ restauration d’une ancienne version dans le brouillon
    ✅ accessibilité : taille du texte appliquée
    ✅ stagiaire en arabe : RTL
    ✅ stagiaire home (arabe) : aucune clé de traduction brute 
    ✅ stagiaire schedule (arabe) : aucune clé de traduction brute 
    ✅ stagiaire assignments (arabe) : aucune clé de traduction brute 
    ✅ stagiaire exams (arabe) : aucune clé de traduction brute 
    ✅ stagiaire planner (arabe) : aucune clé de traduction brute 
    ✅ stagiaire planner/cal (arabe) : aucune clé de traduction brute 
    ✅ stagiaire announcements (arabe) : aucune clé de traduction brute 
    ✅ stagiaire community (arabe) : aucune clé de traduction brute 
    ✅ stagiaire campus (arabe) : aucune clé de traduction brute 
    ✅ stagiaire attendance (arabe) : aucune clé de traduction brute 
    ✅ stagiaire notifs (arabe) : aucune clé de traduction brute 
    ✅ stagiaire profile (arabe) : aucune clé de traduction brute 
    ✅ stagiaire ai (arabe) : aucune clé de traduction brute 
    ✅ stagiaire freetime (arabe) : aucune clé de traduction brute 
    ✅ stagiaire rides (arabe) : aucune clé de traduction brute 
    ✅ console en arabe : RTL
    ✅ console overview (arabe) : aucune clé de traduction brute 
    ✅ console timetable (arabe) : aucune clé de traduction brute 
    ✅ console history (arabe) : aucune clé de traduction brute 
    ✅ console roll (arabe) : aucune clé de traduction brute 
    ✅ console attendance (arabe) : aucune clé de traduction brute 
    ✅ console justifications (arabe) : aucune clé de traduction brute 
    ✅ console assessments (arabe) : aucune clé de traduction brute 
    ✅ console resources (arabe) : aucune clé de traduction brute 
    ✅ console calendar (arabe) : aucune clé de traduction brute 
    ✅ console announcements (arabe) : aucune clé de traduction brute 
    ✅ console notify (arabe) : aucune clé de traduction brute 
    ✅ console students (arabe) : aucune clé de traduction brute 
    ✅ console staff (arabe) : aucune clé de traduction brute 
    ✅ console groups (arabe) : aucune clé de traduction brute 
    ✅ console catalog (arabe) : aucune clé de traduction brute 
    ✅ console moderation (arabe) : aucune clé de traduction brute 
    ✅ console reports (arabe) : aucune clé de traduction brute 
    ✅ console audit (arabe) : aucune clé de traduction brute 
    ✅ console exports (arabe) : aucune clé de traduction brute 
    ✅ console notifs (arabe) : aucune clé de traduction brute 
    ✅ console overview (français) : aucune clé de traduction brute 
    ✅ console timetable (français) : aucune clé de traduction brute 
    ✅ console history (français) : aucune clé de traduction brute 
    ✅ console roll (français) : aucune clé de traduction brute 
    ✅ console attendance (français) : aucune clé de traduction brute 
    ✅ console justifications (français) : aucune clé de traduction brute 
    ✅ console assessments (français) : aucune clé de traduction brute 
    ✅ console resources (français) : aucune clé de traduction brute 
    ✅ console calendar (français) : aucune clé de traduction brute 
    ✅ console announcements (français) : aucune clé de traduction brute 
    ✅ console notify (français) : aucune clé de traduction brute 
    ✅ console students (français) : aucune clé de traduction brute 
    ✅ console staff (français) : aucune clé de traduction brute 
    ✅ console groups (français) : aucune clé de traduction brute 
    ✅ console catalog (français) : aucune clé de traduction brute 
    ✅ console moderation (français) : aucune clé de traduction brute 
    ✅ console reports (français) : aucune clé de traduction brute 
    ✅ console audit (français) : aucune clé de traduction brute 
    ✅ console exports (français) : aucune clé de traduction brute 
    ✅ console notifs (français) : aucune clé de traduction brute 
    ✅ console : thème sombre
    ✅ mobile console admin overview : pas de défilement horizontal (390px)
    ✅ mobile console admin timetable : pas de défilement horizontal (390px)
    ✅ mobile console admin students : pas de défilement horizontal (390px)
    ✅ mobile console admin reports : pas de défilement horizontal (390px)
    ✅ mobile console formateur overview : pas de défilement horizontal (390px)
    ✅ mobile console formateur roll : pas de défilement horizontal (390px)
    ✅ mobile console formateur assessments : pas de défilement horizontal (390px)
    ✅ mobile stagiaire home : pas de défilement horizontal (390px)
    ✅ mobile stagiaire schedule : pas de défilement horizontal (390px)
    ✅ mobile stagiaire planner : pas de défilement horizontal (390px)
    ✅ mobile stagiaire community : pas de défilement horizontal (390px)
    ✅ aucune erreur JavaScript / console (0)


## Ce qui n'a pas pu être testé automatiquement
- **Projet Supabase hébergé** : les tests utilisent le même SQL dans un Postgres local (PGlite) et un serveur qui reproduit PostgREST/GoTrue. Sur le projet réel, j'ai vérifié : migrations appliquées sans erreur, conseiller de sécurité (une seule alerte restante : réglage « Leaked password protection »), accès anonymes refusés (`admin_reports`, `calendar_events` → 401/permission refusée), fonction `admin-users` → 401 sans jeton, fonction `ai-assistant` → 503 « non configurée » (secret absent).
- **Envoi réel d'e-mails** (confirmation, invitation) : dépend du SMTP (action manuelle 3). En test, la fonction d'invitation est absente : le repli « liste pré-inscrite » est testé.
- **Storage** : dépôt et lecture de fichiers testés côté interface avec un stockage simulé ; les politiques `storage.objects` du bucket `submissions` sont créées sur le projet mais non exercées par un test automatique.
- **Temps réel WebSocket** : simulé en test par interrogation d'un compteur de changements.
- **pg_cron** : la tâche existe sur le projet ; en test, la publication à l'heure prévue passe par le trigger et par l'ouverture de la console.
