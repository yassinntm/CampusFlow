# Premiers pas (mise en service à la CMC)

Ordre recommandé pour l'administration, une fois l'installation faite :

1. **Groupes & codes** : créer / renommer les groupes (code `ID101`, intitulé, filière, année). Chaque groupe a un **code d'inscription** (à régénérer en cas de fuite).
2. **Modules & salles** : vérifier la liste des modules (code + nom) et des salles (type, capacité).
3. **Comptes → Liste pré-inscrite** : importer le CSV des formateurs (`role = teacher`) et, idéalement, des stagiaires (`role = student`, `group_code`). Le fichier est **d'abord vérifié à blanc** : erreurs par ligne et doublons sont affichés, rien n'est importé tant qu'il reste une erreur. Modèle téléchargeable dans l'écran.
4. Les formateurs s'inscrivent avec leur e-mail : rôle formateur automatique.
5. **Modules & salles → Affectations** : qui enseigne quel module à quel groupe. Cela donne au formateur le droit de faire l'appel, publier des devoirs/annonces/ressources et modérer son groupe.
6. **Emplois du temps** : choisir un groupe → *Modifier (ouvrir un brouillon)* → ajouter les créneaux (ou *Importer CSV*). Les conflits **groupe / formateur / salle** (y compris avec les autres groupes) s'affichent en rouge ; la publication est bloquée tant qu'il en reste. *Publier* crée une version (historique) et notifie le groupe. Les stagiaires ne voient jamais un brouillon.
7. Communiquer aux stagiaires non pré-inscrits le **code de leur groupe** (QR / affichage en classe / WhatsApp de la classe).

Au quotidien :
- **Formateur** : *Accueil* → *Faire l'appel* sur la séance commencée (P/A/R/J, minutes de retard) ; *Justificatifs* ; *Devoirs* ; *Annonces* (son groupe).
- **Stagiaire** : *Accueil* (prochain cours, compte à rebours), *Emploi du temps* (jour/semaine/mois + historique), *Planning* (devoirs, tâches, révisions proposées avant les examens), *Présences* (taux réel + justifier), *Communauté*.
- **Administration** : *Vue d'ensemble*, *Assiduité* (export CSV), *Modération* (signalements), *Journal d'audit*, *Exports*.

Annuler un cours : *Emplois du temps* → brouillon → modifier le créneau → statut **Annulé** + note → Publier : le groupe reçoit une notification importante.
