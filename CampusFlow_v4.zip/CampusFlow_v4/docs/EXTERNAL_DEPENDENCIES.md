# Dépendances externes

| Dépendance | Rôle | Obligatoire | Compte / coût | Configuration |
|---|---|---|---|---|
| **Supabase** (Auth, Postgres, PostgREST, Realtime, Storage, Edge Functions) | Backend complet | Oui | Offre gratuite pour démarrer (quotas de base, fichiers et mise en pause en cas d’inactivité : vérifier https://supabase.com/pricing). Offre payante recommandée en production (sauvegardes, pas de mise en pause) | docs/INSTALLATION.md |
| **@supabase/supabase-js** 2.x (npm) | Client JavaScript | Oui | Libre (MIT) | `app/package.json` |
| **Vite** 8.x (npm, développement uniquement) | Build | Oui (build) | Libre (MIT) | `app/vite.config.js` |
| Hébergement statique HTTPS (Netlify, Vercel, Cloudflare Pages, Hostinger…) | Servir `app/dist` | Oui | Gratuit à faible coût | docs/DEPLOYMENT.md |
| Serveur SMTP | E-mails de confirmation / réinitialisation | Fortement recommandé | Messagerie de l'établissement | Supabase → Auth → SMTP |
| Google Fonts (Inter, IBM Plex Sans Arabic) | Typographies | Non (repli sur polices système) | Gratuit | `app/index.html` |
| **API Anthropic** (Claude) | Assistant d'étude | Non | Payant à l'usage (clé du compte de l'établissement), plafonné par `AI_DAILY_LIMIT` | `supabase secrets set ANTHROPIC_API_KEY=…` |
| Supabase CLI | Déployer la fonction IA, migrations | Non (SQL Editor suffit) | Libre | docs/DEPLOYMENT.md |

Outils de test (non déployés) : PGlite 0.2.17 + btree_gist (Postgres en mémoire), Playwright + Chrome, Node.js 22.

Aucune intégration externe n'est simulée en production : sans clé IA, l'assistant affiche « non activé » ; sans SMTP, Supabase utilise son service d'e-mail limité.
