# Installation (Supabase + application)

Durée : ~30 minutes. Prérequis : un compte https://supabase.com, Node.js 20+ et npm.

## 1. Créer le projet Supabase
1. Supabase → **New project**. Région conseillée : la plus proche du Maroc (ex. *West EU (Paris)* ou *Central EU (Frankfurt)*).
2. Notez le mot de passe de la base dans un gestionnaire de mots de passe (il ne va **jamais** dans l'application).

## 2. Créer la base (migrations)
Supabase → **SQL Editor** → *New query*. Collez puis exécutez **dans cet ordre**, un fichier à la fois :

| Ordre | Fichier | Rôle |
|---|---|---|
| 1 | `supabase/migrations/0001_schema.sql` | Tables, contraintes, anti-chevauchement des créneaux |
| 2 | `supabase/migrations/0002_functions.sql` | Fonctions, triggers (inscription, notifications, audit, anti-spam) |
| 3 | `supabase/migrations/0003_security.sql` | RLS sur toutes les tables, droits par colonne, stockage, temps réel |
| 4 | `supabase/migrations/0004_reference_data.sql` | Groupes / modules / salles d'exemple (CMC). **À adapter** ou à modifier ensuite depuis l'écran admin |
| 5 | `supabase/migrations/0005_ai_quota.sql` | Quota de l'assistant IA |
| 6 | `supabase/migrations/0006_hardening.sql` | Durcissement (recommandations du conseiller de sécurité Supabase) |
| 7 | `supabase/migrations/0007_supervisor_role.sql` | Rôle « surveillant général » (à exécuter **seul**, avant 0008) |
| 8 | `supabase/migrations/0008_dual_platform.sql` | Plateforme double : séances annulées/déplacées, annonces brouillon/programmées/ciblées, rendus et retours, calendrier académique, contacts de covoiturage, rapports, droits de la surveillance |
| 9 | `supabase/migrations/0009_storage_path_owner_search_path.sql` | Correctif du conseiller de sécurité |

Avec la CLI (alternative) : `supabase link --project-ref <ref>` puis `supabase db push`.

## 3. Vérifier le fuseau horaire (important au Maroc)
Le Maroc est passé à **GMT permanent le 20 septembre 2026**. Si les données de fuseau du serveur sont antérieures,
`Africa/Casablanca` y est encore calculé en GMT+1. Vérifiez :
```sql
select now() at time zone 'Africa/Casablanca' as heure_base;   -- doit être l'heure réelle d'Agadir
```
Si l'heure a 1 h d'avance :
```sql
alter database postgres set app.timezone = 'UTC';   -- le Maroc = GMT = UTC
```
(L'interface, elle, utilise les données de fuseau du navigateur, à jour sur les téléphones récents.)

## 4. Réglages d'authentification
Supabase → **Authentication** :
- **Sign In / Providers → Email** : activé ; *Confirm email* : **activé** (recommandé).
- **Passwords** : longueur minimale **8** ; exigence de caractères : *Letters and digits* (recommandé). Si vous choisissez une règle plus stricte
  (majuscules, symboles) ou *Leaked password protection*, l'écran d'inscription affiche la raison exacte du refus.
  Mot de passe valide dans tous les cas : 10+ caractères avec minuscule, MAJUSCULE, chiffre et symbole, pas un mot courant (ex. `Cmc!Agadir2026`).
- **URL Configuration** : *Site URL* = l'adresse publique de l'appli (ex. `https://campusflow.cmc-agadir.ma`) ; ajoutez-la aussi aux *Redirect URLs* (et `http://localhost:5173` pour le développement).
- **Rate limits** : laissez les limites par défaut.
- **SMTP** : configurez un SMTP de l'établissement (le service d'e-mails intégré de Supabase est limité à quelques messages/heure).

## 5. Premier administrateur
L'inscription n'accorde **jamais** de rôle choisi par le navigateur. Pour créer le premier admin, ajoutez son e-mail à la liste pré-inscrite (SQL Editor) :
```sql
insert into public.roster (email, full_name, role) values ('direction@cmc-agadir.ma', 'Direction CMC', 'admin');
```
Puis cette personne s'inscrit dans l'appli avec cet e-mail (sans code) : elle reçoit le rôle admin.

## 6. Configurer l'application
```bash
cd app
cp .env.example .env.local
```
Dans **Project Settings → API** copiez :
- `VITE_SUPABASE_URL` = *Project URL*
- `VITE_SUPABASE_ANON_KEY` = clé **anon** / **publishable** (publique)

⚠️ Jamais la clé `service_role` / `sb_secret_…` : l'appli refuse de démarrer si elle la détecte. Voir [SECURITY.md](SECURITY.md).

```bash
npm install
npm run dev      # développement
npm run build    # production → app/dist/
```

## 7. (Facultatif) Assistant IA
Voir [DEPLOYMENT.md § Assistant IA](DEPLOYMENT.md#assistant-ia). Sans cette étape, l'écran « Assistant » l'indique clairement ; rien n'est simulé.

## Dépannage
**« Could not query the database for the schema cache. Retrying. » (PGRST002)** : l'API de données n'expose aucun schéma.
Supabase → *Integrations → Data API → Settings* → *Exposed schemas* : `public` (et `graphql_public`) → *Save*.
Ou en SQL : `alter role authenticator set pgrst.db_schemas = 'public, graphql_public'; notify pgrst, 'reload config';` (prise en compte en ~1 min).
