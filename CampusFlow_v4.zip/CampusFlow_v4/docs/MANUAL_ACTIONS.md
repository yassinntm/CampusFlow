# Actions manuelles restantes

Fait directement sur le projet Supabase `ikslygftxspszaqyqkxn` le 22/11/2026 :
- migrations 0007, 0008, 0009 appliquées (0001–0006 l'étaient déjà) ; tâche `pg_cron` « campusflow-publish-announcements » active ; bucket privé `submissions` créé ; 4 tables ajoutées au temps réel ;
- fonctions `admin-users` et `ai-assistant` déployées (JWT obligatoire) ;
- conseiller de sécurité : il reste uniquement « Leaked password protection » (réglage du tableau de bord, voir 2).

À faire par vous (impossible sans vos accès ou vos décisions) :

| # | Action | Où | Pourquoi |
|---|---|---|---|
| 1 | Ajouter le secret `ANTHROPIC_API_KEY` (facultatif : `AI_DAILY_LIMIT`, `AI_MODEL`) | Supabase → Edge Functions → Secrets | sans lui l'assistant reste désactivé (l'appli l'affiche) |
| 2 | Activer **Leaked password protection** | Supabase → Authentication → Providers → Email (offre Pro) | refuser les mots de passe connus des fuites |
| 3 | Configurer un **SMTP** (e-mail de l'établissement, Brevo, Resend…) | Authentication → Emails → SMTP | le SMTP par défaut de Supabase limite fortement les e-mails (confirmations, invitations) |
| 4 | *Site URL* = adresse publique ; *Redirect URLs* : `https://<site>/` **et** `https://<site>/admin/` | Authentication → URL Configuration | liens de confirmation, d'invitation et de mot de passe oublié |
| 5 | Héberger `app/dist/` en HTTPS (voir DEPLOYMENT.md) avec `VITE_SUPABASE_URL` et la clé **publishable** | Netlify / Vercel / Hostinger | mise en ligne |
| 6 | Remplacer les groupes/modules/salles d'exemple par les vrais | Console → Groupes, Modules & salles | données réelles |
| 7 | Informer les stagiaires (loi 09-08) et déclaration CNDP si nécessaire | établissement | conformité |
| 8 | Vérifier les sauvegardes | Database → Backups | reprise après incident |
