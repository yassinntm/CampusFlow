# Architecture

```
Navigateur (PWA)                         Supabase
┌──────────────────────────┐   HTTPS    ┌───────────────────────────────────────────────┐
│ app/  Vite + ES modules  │──────────▶│ Auth (GoTrue) : comptes, sessions, e-mails     │
│  core/   gabarits échappés,│ clé anon  │ PostgREST : API REST générée depuis Postgres   │
│          i18n FR/AR, dates│  + JWT    │ Postgres 15 : 31 tables, RLS partout,          │
│          routeur, UI      │──────────▶│   64 règles, 48 fonctions/triggers, audit       │
│  services/ api, cache     │  WebSocket│ Realtime : 11 tables diffusées (RLS appliquée) │
│  views/ student, teacher, │◀──────────│ Storage : bucket privé « resources »           │
│         admin, shared     │           │ Edge Function ai-assistant ──▶ API IA          │
└──────────────────────────┘           └───────────────────────────────────────────────┘
```

## Choix techniques
- **Vite + JavaScript modulaire, sans React.** La v2 était un fichier unique de 178 Ko ; le découpage en modules suffit à la rendre maintenable.
  Pas de framework : un étudiant ou formateur de la CMC peut lire et modifier le code sans apprendre React/TypeScript, le bundle reste léger
  (≈113 Ko gzip, dont ≈90 % pour supabase-js), et le rendu par gabarits échappés par défaut donne une protection XSS systématique.
  Coût assumé : pas de DOM virtuel (chaque vue se redessine entièrement, ce qui reste instantané à cette échelle).
- **Sécurité dans la base, pas dans l'interface.** L'interface n'est qu'un client : RLS + droits de colonnes + fonctions `security definer` (`set search_path = public`).
  Les opérations multi-étapes (publication d'emploi du temps, appel, modération, import) sont des **fonctions SQL transactionnelles**.
- **Erreurs lisibles** : les fonctions lèvent `CF:code|message` ; l'interface traduit le code (FR/AR).
- **Notifications créées par la base** (triggers) : impossible d'en forger depuis le navigateur pour un autre utilisateur ou groupe.
- **Jointures côté client** : modules, salles, groupes et annuaire sont chargés une fois (cache) ; les listes sont filtrées par RLS côté serveur.

## Modèle de données (supabase/migrations/0001_schema.sql)
| Domaine | Tables |
|---|---|
| Comptes | `profiles` (rôle, groupe, statut, limitation), `roster` (liste pré-inscrite), `user_settings` |
| Référentiel | `groups` (code d'inscription), `modules`, `rooms`, `teaching_assignments` (formateur ↔ groupe ↔ module) |
| Emploi du temps | `timetable_slots` (publié, contraintes d'exclusion groupe/formateur/salle), `timetable_drafts`, `timetable_versions` (instantané + changements) |
| Assiduité | `class_sessions` (séance datée), `attendance_records` (présent/absent/retard/justifié), `absence_justifications` ; vue `attendance_summary` |
| Travail | `assessments` (devoir/examen, priorité), `assessment_progress`, `tasks`, `study_sessions` |
| Communication | `announcements` (général/groupe/module), `notifications` (général/groupe/utilisateur), `notification_reads` |
| Communauté | `posts` (question/discussion, anonymat), `replies`, `post_votes`, `reports`, `study_groups`, `study_group_members`, `rides`, `ride_bookings`; vue `posts_feed` |
| Divers | `resources` (lien/fichier), `audit_log`, `ai_usage` |

Fonctions principales : `publish_timetable`, `start_timetable_draft`, `check_timetable_conflicts`, `open_session`, `save_attendance`,
`review_justification`, `moderate`, `mute_user`, `admin_set_role`, `admin_set_status`, `admin_delete_user`, `admin_group_codes`,
`regenerate_join_code`, `import_roster`, `check_join_code` (seule fonction accessible sans connexion), `ai_consume` (serveur uniquement).

## Arborescence de l'interface
```
app/src/
  main.js                 démarrage, session, mise en page par rôle, temps réel, hors ligne
  core/  html.js (échappement) · i18n.js · dates.js (Africa/Casablanca) · router.js · store.js · ui.js · icons.js
  services/ api.js (client Supabase, erreurs) · data.js (chargement + cache invalidé par le temps réel)
  i18n/  fr.js · ar.js    (≈600 clés, parité testée)
  views/ student/ (accueil, emploi du temps, planning, présences, pauses)
         teacher/ (accueil, appel, devoirs, justificatifs)
         admin/   (vue d'ensemble, emplois du temps, comptes, groupes, référentiel, assiduité, modération, audit, exports)
         shared/  (connexion, notifications, annonces, ressources, profil, communauté, recherche, assistant)
  styles/ base.css (système de design de la v2) · app.css (compléments)
public/  manifest, service worker, icônes, en-têtes de sécurité
```

## Hors ligne (PWA)
Interface mise en cache (réseau d'abord pour la page, cache d'abord pour les fichiers versionnés). Les données ne sont **pas** stockées hors ligne :
en cas de coupure, la dernière vue chargée reste affichée avec un bandeau « Hors ligne », les modifications échouent proprement.
Choix volontaire : présences et profils sont des données personnelles qui ne doivent pas rester en clair dans le cache d'un téléphone partagé.

## v4 — deux applications, un backend
```
app/index.html ─▶ src/student/main.js ─┐                 ┌─ src/admin/main.js ◀─ app/admin/index.html
                                       ├─ src/shared/ (démarrage, connexion, composants de la démo)
                                       ├─ src/core/   (gabarits échappés, routeur, i18n, dates, UI)
                                       └─ src/services/ (client Supabase, cache + temps réel)
```
- `shared/boot.js` : session, profil, choix de l'application (`accept`/`redirect`), temps réel, hors ligne.
- Routeur : la page est construite hors écran puis insérée d'un bloc (pas d'écran blanc) ; une mise à jour en temps réel
  ne remplace jamais un formulaire en cours de saisie et n'annule jamais un affichage demandé par l'utilisateur.
- Nouvelles tables (0008) : `session_exceptions`, `submissions`, `calendar_events` ; colonnes : annonces (`status`, `publish_at`, `target_users`),
  `notifications.created_by`, `resources.assessment_id`, `profiles.share_phone`. Fonctions : `is_staff`, `my_access`, `set/clear_session_exception`,
  `restore_version`, `give_feedback`, `notification_stats`, `ride_contacts`, `admin_reports`, `publish_due_announcements`.
