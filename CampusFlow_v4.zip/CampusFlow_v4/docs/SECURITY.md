# Sécurité

## Principe : le navigateur n'est jamais une barrière de sécurité
Tout code envoyé au navigateur peut être lu et modifié. CampusFlow ne s'y fie donc pas : masquer un bouton n'empêche rien.
**Chaque règle est appliquée par Postgres** (RLS, droits par colonne, triggers, fonctions `security definer`), et testée (`tests/db/test_db.mjs`, 112 contrôles).

## Clés Supabase : publique vs secrète
| Clé | Où | Ce qu'elle permet |
|---|---|---|
| **anon / publishable** (`sb_publishable_…` ou JWT `role: anon`) | Interface (`VITE_SUPABASE_ANON_KEY`) | Identifie le projet. Sans connexion : seulement ce que les règles autorisent à `anon` (ici : vérifier un code de groupe). Connecté : les droits du compte, filtrés par RLS. **Publique par conception.** |
| **service_role / secret** (`sb_secret_…` ou JWT `role: service_role`) | Serveur uniquement (Edge Function, fournie automatiquement par Supabase) | **Ignore toutes les règles RLS.** Ne doit jamais apparaître dans le code, le dépôt Git, un `.env` d'interface ou une capture d'écran. |

Tout ce qui commence par `VITE_` est intégré au JavaScript public. L'appli **refuse de démarrer** si la clé configurée est une clé secrète (contrôle dans `app/src/services/api.js`).
En cas de fuite d'une clé secrète : Supabase → Settings → API → la régénérer immédiatement.

## Rôles
`student` (stagiaire), `teacher` (formateur), `admin` (administration). Le rôle est stocké dans `profiles` et :
- attribué à l'inscription **par la base** : liste pré-inscrite (`roster`) sinon code de groupe ⇒ stagiaire ; les métadonnées envoyées par le navigateur (`role`, etc.) sont ignorées ;
- modifiable uniquement via `admin_set_role` (admin, audité) ; un admin ne peut pas se retirer ses droits ni se suspendre ;
- les droits de colonnes n'autorisent l'utilisateur à modifier que `full_name` et `phone` ; un trigger bloque en plus toute modification de rôle/groupe/statut.
Compte suspendu (`admin_set_status`) : perd immédiatement l'accès aux données de groupe (les fonctions de rôle ne considèrent que les comptes actifs).

## Qui voit quoi (résumé des règles RLS)
| Donnée | Stagiaire | Formateur | Admin |
|---|---|---|---|
| Profils | le sien | ses stagiaires (groupes affectés) | tous |
| Annuaire (`people`) | noms/rôles/groupes, **sans e-mail ni téléphone** | idem | idem |
| Emploi du temps publié | son groupe | ses groupes + ses créneaux | tout ; brouillons = admin seul |
| Présences | les siennes | ses groupes, saisie via `save_attendance` (séance de son cours, pas de date future, ≤ 30 jours) | tout |
| Devoirs/examens | son groupe + communs | création pour (groupe, module) affectés | tout |
| Annonces | son groupe / module / générales | création pour ses groupes uniquement | tout |
| Notifications | les siennes, de son groupe, générales | idem | tout |
| Tâches, révisions, réglages, progression | les siennes uniquement | — | — |
| Publications | son groupe ; auteur d'une question anonyme masqué | ses groupes, modération | tout, auteur réel visible |
| Signalements | les siens | — | tout |
| Journal d'audit | — | — | lecture seule (personne ne peut écrire directement) |

## Protections
- **XSS** : tout le rendu passe par un gabarit qui échappe chaque valeur (`app/src/core/html.js`) ; liens externes limités à `https://` ; CSP stricte (`script-src 'self'`, pas de script en ligne). Testé avec `<img onerror>` et `<script>` dans une publication (affichés comme texte).
- **Injection SQL** : aucune requête SQL construite côté client ; PostgREST paramètre tout ; fonctions SQL sans SQL dynamique sur des valeurs utilisateur (sauf `enforce_rate`, qui n'y insère que des noms de tables fixes avec `format('%I')`).
- **Anti-spam / débit** : questions 5/10 min et 30/jour, réponses 15/10 min, signalements 20/jour, groupes de révision et trajets 5/jour ; utilisateur « limité » (`mute_user`) bloqué.
- **Signalements** : 3 signalements distincts masquent automatiquement un contenu ; un utilisateur ne peut signaler le même contenu qu'une fois.
- **Emploi du temps** : contraintes d'exclusion Postgres (aucun chevauchement groupe/formateur/salle possible, même en contournant l'interface) ; publication atomique et versionnée.
- **Audit** : triggers sur rôles/comptes, groupes, liste pré-inscrite, modules, salles, affectations, présences, devoirs, annonces, ressources ; publication, modération et suppression de compte.
- **Fichiers** : bucket privé, 25 Mo, types autorisés listés, liens signés de 5 minutes, dépôt réservé formateurs/admin dans leur dossier.
- **Exports CSV** : neutralisation des formules (`=`, `+`, `-`, `@`) contre l'injection dans Excel.
- **IA** : clé uniquement en secret serveur ; quota atomique ; contexte limité aux données de l'utilisateur ; consigne de ne pas prétendre avoir lu des documents.
- **Mots de passe / sessions** : gérés par Supabase Auth (hachage, jetons à durée limitée, rafraîchissement). Réinitialisation sans révéler si un e-mail existe.
- **Hors ligne** : le service worker ne met en cache que l'interface ; aucune donnée personnelle ni jeton n'est mis en cache par l'appli.

## Limites connues (honnêtes)
- La limitation de débit de connexion dépend des réglages Supabase Auth (pas de limite propre à l'appli).
- Un compte suspendu garde une session valide jusqu'à expiration du jeton, mais n'accède plus aux données de groupe.
- Les tâches/réglages personnels restent accessibles à un compte suspendu (données propres).
- Pas d'antivirus sur les fichiers déposés (formateurs/admin uniquement, types limités).

## Ajouts v4 (plateforme double)
- **Rôle surveillance** : `is_staff()` (admin + surveillance) remplace `is_admin()` là où la surveillance doit agir ; les opérations réservées (comptes, construction/publication de l'emploi du temps, référentiel, audit, restauration) restent `is_admin()`. Testé : 72 tests `tests/db/test_platform.mjs`.
- **Séparation des applications** : confort uniquement — un stagiaire qui force `/admin/` n'obtient aucune donnée supplémentaire (RLS), la console lui affiche « réservé au personnel ».
- **Invitations** : fonction `admin-users` ; jeton vérifié, rôle relu en base (`my_access`), entrées validées, clé `service_role` uniquement côté serveur, action auditée.
- **Rendus** : bucket privé `submissions` (10 Mo, types limités) ; dépôt seulement dans son propre dossier ; lecture par l'auteur et par ceux qui peuvent lire le rendu en base ; rendu verrouillé après retour ; le formateur ne peut pas modifier le contenu d'un rendu.
- **Annonces ciblées / programmées / brouillons** : invisibles pour les stagiaires tant qu'elles ne sont pas publiées (RLS) ; seul le personnel cible des stagiaires précis.
- **Téléphone** : jamais affiché par défaut ; partagé seulement si le stagiaire l'active, et seulement au conducteur et aux passagers d'un même trajet (`ride_contacts`).
- **Statistiques de lecture** : agrégats uniquement, réservés au personnel ; les lectures du personnel ne sont pas comptées.
- **Messages personnels** envoyés par un membre du personnel : visibles par le destinataire et par l'expéditeur, pas par les autres membres du personnel.
