# Problèmes corrigés

## A. Version de départ `CampusFlow_Yassine_v2.html` (fichier unique, données dans le navigateur)
| # | Problème | Gravité | Correction v3 |
|---|---|---|---|
| 1 | **Aucune authentification** : on choisissait son nom dans une liste, ou le rôle « Surveillant général », sans mot de passe | Critique | Supabase Auth (e-mail + mot de passe, confirmation, réinitialisation) |
| 2 | Contrôle des rôles uniquement en JavaScript (`session.role === 'supervisor'`), modifiable dans la console | Critique | Rôles en base, RLS + droits de colonnes + triggers ; rôle jamais choisi par le client |
| 3 | Toutes les données dans `localStorage` : rien n'était partagé entre téléphones, effaçable, falsifiable | Critique | Postgres partagé, temps réel |
| 4 | Emploi du temps en texte libre (formateur, salle, module) : aucune détection de conflit possible | Élevée | Tables liées + contraintes d'exclusion groupe/formateur/salle + vérification avant publication |
| 5 | Publication non atomique, sans historique exploitable | Élevée | `publish_timetable` transactionnelle, versions + instantanés + résumé des changements |
| 6 | Compteurs d'absences saisis à la main (chiffres non fiables) | Élevée | Appel par séance ; taux calculés depuis les enregistrements (`attendance_summary`) |
| 7 | Pas de rôle formateur | Élevée | Rôle `teacher` + affectations groupe/module |
| 8 | Notifications et journal créés par le navigateur (forgeables) | Élevée | Créés par triggers/fonctions en base |
| 9 | 12 insertions `innerHTML` avec échappement manuel, oublis possibles | Élevée | Gabarit à échappement par défaut, CSP sans script en ligne, test XSS |
| 10 | Horaires de bus codés en dur (« Démo ») présentés à côté de vraies données | Moyenne | Supprimés ; covoiturage réel entre stagiaires |
| 11 | Espace admin uniquement en français ; 57 textes codés en dur hors traduction | Moyenne | 606 clés FR/AR, parité et couverture vérifiées par test |
| 12 | Pas de modération, d'anti-spam, d'export CSV, de recherche transversale ni d'assistant | Moyenne | Ajoutés (voir FEATURES.md) |
| 13 | Fichier unique de 178 Ko, impossible à maintenir à plusieurs | Moyenne | Projet modulaire Vite (≈30 fichiers par responsabilité) |

## B. Problèmes trouvés et corrigés pendant le développement de la v3 (grâce aux tests)
| # | Problème | Comment il a été trouvé | Correction |
|---|---|---|---|
| 1 | Publier un brouillon **vide** supprimait tout l'emploi du temps publié du groupe (ex. double clic sur « Publier ») | Test base « publication vide refusée » | Publication refusée sans brouillon ; brouillon ouvert par copie du publié (`start_timetable_draft`) |
| 2 | Impossible de créer le **premier** emploi du temps d'un groupe (brouillon vide = pas de mode édition) | Test de bout en bout | État « brouillon ouvert » explicite |
| 3 | L'admin ne pouvait pas suspendre un compte (droits de colonnes trop stricts, même pour l'admin) | Revue de code + test | RPC auditée `admin_set_status` |
| 4 | Heure de la base décalée d'1 h : Postgres utilise encore GMT+1 pour Casablanca alors que le Maroc est à GMT depuis le 20/09/2026 | Test de bout en bout (compte à rebours faux de 1 h côté base) | Fuseau configurable `app.timezone` + procédure de vérification ; interface basée sur les données de fuseau du navigateur |
| 5 | Un formateur inscrit pendant la session admin n'apparaissait pas dans les listes | Test de bout en bout | Annuaire rechargé à l'ouverture des écrans concernés |
| 6 | `import_roster` renvoyait un booléen comme nombre de lignes importées (« true ligne(s) ») | Test de bout en bout | Renvoie le nombre réel |
| 7 | Recharger le même fichier CSV corrigé ne relançait pas la vérification | Test de bout en bout | Champ fichier réinitialisé après lecture |
| 8 | Directive CSP `frame-ancestors` ignorée dans une balise `<meta>` | Console du navigateur | Déplacée dans les en-têtes HTTP (`_headers`, `vercel.json`, Nginx) |
| 9 | Liens soulignés et bouton « Se déconnecter » mal aligné ; « Activité récente » débordait horizontalement | Captures d'écran | CSS corrigé |
