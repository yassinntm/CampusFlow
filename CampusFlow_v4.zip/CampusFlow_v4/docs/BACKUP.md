# Sauvegardes et restauration

## Automatiques
Supabase → **Database → Backups**. Offre Pro : sauvegarde quotidienne conservée 7 jours (PITR en option). Offre gratuite : **aucune garantie** → faire des sauvegardes manuelles.

## Manuelle (recommandée chaque semaine et avant chaque migration)
Chaîne de connexion : Supabase → Project Settings → Database → *Connection string* (mot de passe de la base, à ne jamais partager).
```bash
pg_dump "postgresql://postgres:<MOT_DE_PASSE>@db.<ref>.supabase.co:5432/postgres" \
  --schema=public --no-owner --no-privileges -F c -f campusflow_$(date +%F).dump
# comptes (e-mails, hachages de mots de passe) — fichier sensible, à chiffrer
pg_dump "…" --schema=auth --table=auth.users --data-only -F c -f campusflow_auth_$(date +%F).dump
```
Stockez les fichiers **chiffrés** (ex. `gpg -c`) hors du poste de travail. Ils contiennent des données personnelles (loi 09-08).

## Restauration (sur un projet vide)
1. Exécuter les migrations 0001→0005.
2. `pg_restore --data-only --disable-triggers -d "<connexion>" campusflow_auth_<date>.dump` puis le dump `public`.
3. Vérifier : `select count(*) from profiles; select count(*) from timetable_slots;` et une connexion de test.
**Testez la restauration** au moins une fois par trimestre sur un projet séparé.

## Exports CSV
L'écran *Exports* produit des CSV lisibles (Excel) : utiles pour l'archivage administratif, ils **ne remplacent pas** une sauvegarde (pas de comptes, pas de relations).
