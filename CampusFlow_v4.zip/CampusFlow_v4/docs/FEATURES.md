# Fonctionnalités — état réel (v4)

« Fait » = branché sur la base réelle et couvert par au moins un test exécuté (voir TEST_REPORT.md). Aucune donnée fictive n'est utilisée par l'application.

## Application Stagiaire (`/`)
| Écran | Fait |
|---|---|
| Connexion / inscription | code de groupe, liste pré-inscrite, messages d'erreur Supabase précis (mot de passe compromis, trop court…), champs conservés, mot de passe oublié, FR/AR, thème |
| Accueil | carte « prochain cours » avec compte à rebours (secondes), cours du jour avec annulations/déplacements du jour, échéances, annonces, 8 raccourcis de la démo + « Vie du campus » |
| Emploi du temps | carte de version officielle (lecture seule), bandeau des changements de la dernière version, vue Jour (puces de jours, semaine précédente/suivante, séances annulées ou déplacées à la date) et vue Semaine (grille), historique des versions |
| Devoirs | Cette semaine / À venir / Passés, fiche détaillée : consignes, pièces jointes (lien signé 5 min), avancement, **rendu** (texte, lien https, fichier ≤ 10 Mo), retour et note du formateur, rendu verrouillé après correction |
| Examens | compte à rebours en jours, salle, durée, préparation (séances de révision proposées selon l'emploi du temps) |
| Planning | Départ (heure de départ conseillée, chronologie, réglages de trajet), calendrier Mois/Semaine/Jour (cours, échéances, tâches, révisions, **événements académiques**), tâches avec priorité, révisions avec objectif hebdomadaire |
| Annonces, notifications | annonces publiées qui le concernent (générales, groupe, module, personnelles) ; notifications avec filtres Tous / Non lus / Important / Changements / Rappels, « Tout lire », lien vers l'écran concerné |
| Assiduité | taux réel, historique, justificatif d'absence/retard |
| Communauté | Questions & réponses (anonymat, votes, meilleure réponse, signalement), groupes de révision (créer, rejoindre, modifier, quitter), covoiturage (proposer, réserver, **contacts avec consentement**) |
| Vie du campus | créneaux libres entre les cours, ressources des modules, assistant d'étude |
| Recherche globale | fenêtre de recherche : cours, modules, formateurs, salles, devoirs, examens, annonces, ressources, publications ; terme surligné |
| Profil & réglages | identité et téléphone, langue FR/AR (RTL), thème clair/sombre, notifications du navigateur, taille du texte, réduction des animations, partage du téléphone (opt-in), mot de passe, export de ses données (JSON), déconnexion |
| Rappels | départ et début de cours, quand l'application est ouverte |

## Application Administration (`/admin/`) — menu selon le rôle
| Écran | Administration | Surveillance générale | Formateur |
|---|---|---|---|
| Vue d'ensemble (KPI réels, cartes par groupe : version, taux de lecture, brouillon, journal) | ✔ | ✔ (activité = notifications) | tableau de bord formateur : séances du jour, rendus à corriger, justificatifs |
| Emplois du temps : brouillon, ajout/modification/suppression de créneaux, import CSV, conflits formateur/salle/groupe vérifiés par le serveur, **aperçu des changements + aperçu côté stagiaire**, publication versionnée, notification stagiaires **et formateurs** | ✔ | lecture seule | « Mon emploi du temps » (tous groupes) |
| Séances ponctuelles : annuler ou déplacer un cours à une date (salle libre vérifiée), rétablir | ✔ | ✔ | — |
| Historique : versions, aperçu en grille, **restauration dans le brouillon** | ✔ | lecture | — |
| Appel (7 derniers jours, séances annulées exclues), corrections | ✔ | ✔ | ses cours |
| Assiduité par groupe : taux, stagiaires sous 80 %, historique des séances, export CSV | ✔ | ✔ | — |
| Justificatifs | ✔ | ✔ | ses séances |
| Devoirs & examens : création, pièces jointes, rendus, retours + note, export CSV des rendus | ✔ | — | ses modules |
| Ressources | ✔ | — | ses modules |
| Calendrier académique | ✔ | ✔ | — |
| Annonces : publier, **programmer**, **brouillon**, épingler, cibler établissement / groupe / module / **stagiaires précis** | ✔ | ✔ | ses groupes et modules |
| Notifications : composition, aperçu, envoi (tous / groupe / un stagiaire), **taux de lecture** | ✔ | ✔ | — |
| Stagiaires : tableau avec présences/absences/retards, **invitation par e-mail**, liste pré-inscrite, import CSV avec test à blanc, rôle, groupe, limitation, suspension, suppression | ✔ | consultation + limitation | — |
| Personnel : formateurs, surveillance, administration ; enseignements ; emploi du temps de chaque formateur ; invitation | ✔ | — | — |
| Groupes & codes, modules, salles, affectations | ✔ | — | — |
| Modération : signalements groupés, auteur réel, masquer/rétablir/supprimer, limiter 3 jours, contenus masqués, historique des décisions | ✔ | ✔ | publications de ses groupes |
| Rapports : par groupe, absences par module, modération, justificatifs, communication ; CSV | ✔ | ✔ | — |
| Journal d'audit (filtres, CSV, lecture seule, aucune écriture possible) | ✔ | — | — |
| Exports CSV | ✔ | — | — |
| Mes notifications, FR/AR, thème | ✔ | ✔ | ✔ |

Intégration : chaque action de la console écrit dans la base ; l'application Stagiaire la reçoit en temps réel (publication, annulation, annonce, notification, devoir, retour, calendrier). Les deux applications partagent la même session : un membre du personnel qui ouvre `/` est renvoyé vers `/admin/`, un stagiaire qui ouvre `/admin/` voit « réservé au personnel ».

## Non fait / limité (dit clairement dans l'interface)
| Sujet | État |
|---|---|
| Notifications push application fermée (Web Push, SMS, WhatsApp) | **non implémentées** ; notifications dans l'application + notification du navigateur quand l'onglet est ouvert |
| Assistant IA | fonction déployée, **inactive tant que le secret `ANTHROPIC_API_KEY` n'est pas ajouté** ; l'écran l'indique, aucune réponse inventée |
| Invitations e-mail | fonction déployée ; avec le SMTP par défaut de Supabase l'envoi est limité (quelques e-mails/heure). Sans envoi possible, la personne est ajoutée à la liste pré-inscrite et crée son compte elle-même (message honnête) |
| Notes / bulletins officiels | seulement une note libre sur un rendu ; pas de moyenne ni de relevé |
| Messagerie privée | non (choix de sécurité) |
| Stockage des fichiers en test | les politiques `storage.objects` sont en place sur Supabase mais les tests automatiques utilisent un stockage simulé (voir TEST_REPORT) |
