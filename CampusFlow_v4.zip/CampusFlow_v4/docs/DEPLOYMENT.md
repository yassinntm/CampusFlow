# Déploiement

L'interface est un site **statique** (`app/dist/`) qui contient **les deux applications** : `index.html` (Stagiaire) et `admin/index.html` (Administration). Toute la logique sensible est dans Supabase.
Aucune réécriture d'URL n'est nécessaire (navigation par `#/…`). Pour séparer les domaines (ex. `admin.campusflow.ma`), pointez ce domaine sur le même dossier et redirigez `/` vers `/admin/`.

## Hébergement de l'interface
**Netlify / Cloudflare Pages** : dossier de base `app`, commande `npm run build`, dossier publié `app/dist`, variables
`VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` dans les réglages du site. Le fichier `app/public/_headers` ajoute les en-têtes de sécurité.

**Vercel** : *Root directory* `app`, framework *Vite* ; `app/vercel.json` contient les en-têtes.

**Hostinger / serveur Nginx** : `npm run build` en local, envoyer `app/dist/` puis ajouter :
```nginx
add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob: https:; connect-src 'self' https://*.supabase.co wss://*.supabase.co; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'" always;
add_header X-Frame-Options DENY always;
add_header X-Content-Type-Options nosniff always;
add_header Referrer-Policy strict-origin-when-cross-origin always;
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
location = /sw.js { add_header Cache-Control "no-cache"; }
```
HTTPS est **obligatoire** (le service worker et les sessions l'exigent). Si Supabase est servi sur un domaine personnalisé, ajoutez-le à `connect-src`.

Après chaque mise à jour de l'interface, incrémentez `VERSION` dans `app/public/sw.js` pour forcer le rafraîchissement du cache.

## Base de données
Nouvelle migration = nouveau fichier `supabase/migrations/0010_….sql`, jamais de modification d'un fichier déjà exécuté en production.
Testez d'abord : `cd tests && npm run db` (Postgres local, RLS compris).

## Fonctions serveur (déjà déployées sur le projet actuel)
| Fonction | Rôle | Secrets |
|---|---|---|
| `admin-users` | invitation de comptes par l'administration (vérifie le jeton puis `my_access()` = admin actif ; la clé service ne quitte jamais le serveur) | aucun (fournis par Supabase) |
| `ai-assistant` | assistant d'étude | `ANTHROPIC_API_KEY` (+ `AI_DAILY_LIMIT`, `AI_MODEL`) |

Redéployer : `supabase functions deploy admin-users` / `supabase functions deploy ai-assistant`.

## Annonces programmées
`pg_cron` exécute `publish_due_announcements()` chaque minute (créé par 0008). Sans `pg_cron`, la console les publie à son ouverture.

## Assistant IA
1. Installer la CLI : https://supabase.com/docs/guides/cli
2. ```bash
   supabase link --project-ref <ref>
   supabase secrets set ANTHROPIC_API_KEY=<clé>          # stockée côté serveur, jamais dans l'appli
   supabase secrets set AI_DAILY_LIMIT=30 AI_MODEL=claude-haiku-5-5   # facultatif
   supabase functions deploy ai-assistant
   ```
3. La fonction vérifie le jeton de l'utilisateur, décompte le quota quotidien en base (`ai_consume`, exécutable seulement par la clé service du serveur),
   lit uniquement l'emploi du temps et les échéances **de cet utilisateur** (avec ses droits RLS), puis appelle l'API.
Coût : facturé par le fournisseur IA selon l'usage ; la limite quotidienne par compte le plafonne.

## Notifications push (non activées)
Les notifications fonctionnent dans l'appli (centre de notifications, temps réel, alerte navigateur quand l'onglet est ouvert).
Les notifications **application fermée** demandent une infrastructure Web Push (clés VAPID, table d'abonnements, fonction d'envoi) : **non incluse**, et l'appli ne prétend pas le contraire.

## Liste de contrôle avant mise en production
- [ ] Migrations 0001→0009 exécutées sans erreur ; `select count(*) from pg_tables where schemaname='public' and rowsecurity = false;` renvoie **0**
- [ ] Heure de la base vérifiée (`app.timezone`, voir INSTALLATION §3)
- [ ] *Redirect URLs* : `https://<site>/` et `https://<site>/admin/`
- [ ] *Confirm email* activé, mot de passe ≥ 8, SMTP de l'établissement configuré, *Site URL* et *Redirect URLs* corrects
- [ ] Seule la clé **anon/publishable** est dans les variables de l'interface ; clé `service_role` jamais copiée hors de Supabase
- [ ] Premier admin créé via la liste pré-inscrite ; aucun compte de test restant (`select email, role from profiles`)
- [ ] Données d'exemple de `0004_reference_data.sql` remplacées par les vrais groupes/modules/salles
- [ ] HTTPS + en-têtes de sécurité actifs (vérifier sur https://securityheaders.com)
- [ ] Sauvegardes vérifiées (Supabase → Database → Backups) et procédure de restauration testée (docs/BACKUP.md)
- [ ] Information des stagiaires (loi 09-08) : finalités, durée de conservation, contact ; déclaration CNDP faite par l'établissement si nécessaire
- [ ] `tests/run_all.sh` vert sur la version déployée
