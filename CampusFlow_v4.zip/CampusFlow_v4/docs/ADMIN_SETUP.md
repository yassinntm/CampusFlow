# Mise en route de l'administration

## 1. Premier compte administrateur
Personne ne peut s'inscrire « administrateur » depuis le navigateur : le rôle vient de la **liste pré-inscrite** (`roster`), écrite côté base.
Dans Supabase → SQL Editor :
```sql
insert into public.roster (email, full_name, role) values ('direction@votre-domaine.ma', 'Direction CMC', 'admin');
```
Puis ouvrir `https://<site>/admin/` → onglet **Première connexion** → nom, cette adresse, mot de passe (8 caractères min.) → confirmer l'e-mail.
(Projet actuel : `yassinntm18@gmail.com` est déjà administrateur.)

## 2. Rôles
| Rôle | Application | Ce qu'il peut faire (vérifié par la base) |
|---|---|---|
| `admin` — Administration | `/admin/` | tout : comptes, emplois du temps (construction, publication, restauration), référentiel, audit |
| `supervisor` — Surveillance générale | `/admin/` | tous les groupes en lecture, appel, justificatifs, annulation/déplacement ponctuel de séances, annonces et notifications à tous, calendrier, modération, rapports. **Pas** : comptes, construction de l'emploi du temps, référentiel, audit |
| `teacher` — Formateur | `/admin/` | uniquement ses groupes/modules (affectations) : appel, devoirs/examens, rendus et retours, ressources, annonces de groupe, modération de ses groupes |
| `student` — Stagiaire | `/` | ses données et celles de son groupe |

## 3. Ajouter des personnes
- **Console → Stagiaires → Ajouter** (ou **Personnel → Ajouter un membre**) : invitation par e-mail via la fonction serveur `admin-users`. La personne choisit son mot de passe et arrive dans la bonne application.
- **Import CSV** (Stagiaires → Liste pré-inscrite → Importer) : `email;full_name;role;group_code` ; test à blanc ligne par ligne avant import. Les personnes importées créent ensuite leur compte avec leur adresse.
- Alternative pour les stagiaires : **code de groupe** (Groupes & codes) à communiquer en classe.

## 4. Ordre conseillé au démarrage
1. Groupes & codes → vos groupes réels (supprimer les groupes d'exemple sans stagiaires).
2. Modules & salles → modules, salles ; onglet Affectations → formateur ↔ groupe ↔ module.
3. Personnel → inviter formateurs et surveillance.
4. Emplois du temps → par groupe : Modifier → ajouter les créneaux (ou import CSV) → corriger les conflits → Prévisualiser & publier.
5. Calendrier académique → vacances, périodes d'examens.
6. Communiquer les codes de groupe / inviter les stagiaires.

## 5. Au quotidien
- Absence d'un formateur : **Emplois du temps → Séances ponctuelles** → choisir la date → *Annuler ce jour* (ou *Déplacer*). Stagiaires et formateur sont notifiés ; l'emploi du temps hebdomadaire ne change pas.
- Annonce pour demain matin : **Annonces → Nouvelle annonce → Programmer** (publication automatique chaque minute par `pg_cron`).
- Convocation individuelle : annonce ciblée « Stagiaires précis… » ou notification « Un stagiaire précis… ».
