# CampusFlow v4 — CMC Agadir

**Une plateforme, deux applications, un seul backend Supabase.**

| Application | Adresse | Pour qui | Contenu |
|---|---|---|---|
| **CampusFlow Stagiaire** | `/` | stagiaires | accueil (prochain cours + compte à rebours), emploi du temps jour/semaine, devoirs (pièces jointes, rendu, retour du formateur), examens et révisions, planning (départ, calendrier, tâches, révisions), annonces, notifications, assiduité et justificatifs, communauté (Q&R, groupes de révision, covoiturage), créneaux libres, ressources, recherche globale, assistant d'étude, profil, confidentialité, accessibilité, FR/AR |
| **CampusFlow Administration** | `/admin/` | administration, surveillance générale, formateurs (menu selon le rôle) | vue d'ensemble, éditeur d'emploi du temps (brouillon → conflits → aperçu → publication), séances ponctuelles annulées/déplacées, historique et restauration, appel, assiduité, justificatifs, devoirs & examens (rendus, retours, pièces jointes), ressources, calendrier académique, annonces (brouillon, programmées, ciblées), notifications avec taux de lecture, stagiaires (invitation, import CSV), personnel, groupes & codes, modules & salles, modération, rapports CSV, journal d'audit, exports |

Le design reprend celui de la démo d'origine (même système de design, mêmes écrans, même navigation) ; la console reprend la
barre latérale et les écrans « Vue d'ensemble », « Éditeur », « Historique », « Étudiants » de la démo.

Toutes les règles d'accès sont dans la base (RLS, droits de colonnes, fonctions `security definer`) : l'interface n'est jamais la barrière.

| Dossier | Contenu |
|---|---|
| `app/` | les deux applications (Vite, JavaScript modulaire) : `src/student/`, `src/admin/`, `src/shared/`, `src/core/` |
| `supabase/migrations/` | SQL 0001 → 0009, à exécuter dans l'ordre |
| `supabase/functions/` | `admin-users` (invitations), `ai-assistant` (assistant d'étude) |
| `tests/` | base de données, fonctions, unitaires, bout en bout (Chrome) |
| `docs/` | installation, déploiement, mise en route admin, actions manuelles, sécurité, architecture, fonctionnalités, tests |

## Démarrage rapide
```bash
cd app
cp .env.example .env.local     # VITE_SUPABASE_URL + clé PUBLIQUE (anon / publishable) uniquement
npm install
npm run dev                    # http://localhost:5173 (stagiaire) et http://localhost:5173/admin/ (console)
npm run build                  # app/dist/ : index.html + admin/index.html
cd ../tests && npm install && ./run_all.sh
```

Lire : [Actions manuelles restantes](docs/MANUAL_ACTIONS.md) · [Mise en route de l'administration](docs/ADMIN_SETUP.md) ·
[Installation](docs/INSTALLATION.md) · [Déploiement](docs/DEPLOYMENT.md) · [Fonctionnalités](docs/FEATURES.md) ·
[Sécurité](docs/SECURITY.md) · [Architecture](docs/ARCHITECTURE.md) · [Rapport de tests](docs/TEST_REPORT.md) · [Sauvegardes](docs/BACKUP.md)
