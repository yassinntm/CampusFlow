// Création de comptes par l'administration (invitation par e-mail).
// Créer un compte Auth exige la clé service_role : elle reste ici, côté serveur, jamais dans le navigateur.
// Le rôle et le groupe passent par la liste pré-inscrite (roster), donc par les mêmes règles que l'inscription normale.

export interface Env { get(name: string): string | undefined }
export interface Deps {
  env: Env;
  userClient: (authHeader: string) => any;   // client avec le jeton de l'appelant (RLS appliqué)
  serviceClient: () => any;                  // client service_role (serveur uniquement)
}
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,}$/i;
const ROLES = ['student', 'teacher', 'supervisor', 'admin'];

export function validateInvite(b: any): { email: string; full_name: string; role: string; group_code: string | null; redirect_to: string | null } | string {
  if (!b || typeof b !== 'object') return 'invalid';
  const email = String(b.email || '').trim().toLowerCase();
  const full_name = String(b.full_name || '').trim();
  const role = String(b.role || 'student');
  const group_code = b.group_code ? String(b.group_code).trim().toUpperCase() : null;
  if (!EMAIL.test(email)) return 'email';
  if (full_name.length < 3 || full_name.length > 80) return 'name';
  if (!ROLES.includes(role)) return 'role';
  if (role === 'student' && !group_code) return 'group';
  const redirect_to = typeof b.redirect_to === 'string' && /^https?:\/\/[^\s]+$/.test(b.redirect_to) ? b.redirect_to : null;
  return { email, full_name, role, group_code: role === 'student' ? group_code : null, redirect_to };
}

export function createHandler(deps: Deps) {
  return async (req: Request): Promise<Response> => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
    if (req.method !== 'POST') return json(405, { error: 'method' });
    const auth = req.headers.get('Authorization') || '';
    if (!/^Bearer\s+\S+/.test(auth)) return json(401, { error: 'unauthorized' });
    const user = deps.userClient(auth);
    const { data: u, error: ue } = await user.auth.getUser(auth.replace(/^Bearer\s+/, ''));
    if (ue || !u?.user) return json(401, { error: 'unauthorized' });
    // Vérification du rôle par la base (jamais par le navigateur)
    const { data: access, error: ae } = await user.rpc('my_access');
    if (ae || !access?.admin || access.status !== 'active') return json(403, { error: 'forbidden' });

    let body: any;
    try { body = await req.json(); } catch { return json(400, { error: 'invalid' }); }
    if (body?.action !== 'invite') return json(400, { error: 'action' });
    const v = validateInvite(body);
    if (typeof v === 'string') return json(400, { error: v });

    const svc = deps.serviceClient();
    let group_id: string | null = null;
    if (v.group_code) {
      const { data: g } = await svc.from('groups').select('id').eq('code', v.group_code).maybeSingle();
      if (!g) return json(400, { error: 'group' });
      group_id = g.id;
    }
    const { data: existing } = await svc.from('profiles').select('id').eq('email', v.email).maybeSingle();
    if (existing) return json(409, { error: 'exists' });
    const { error: re } = await svc.from('roster').upsert({ email: v.email, full_name: v.full_name, role: v.role, group_id }, { onConflict: 'email' });
    if (re) return json(400, { error: 'roster', message: re.message });
    const { data: inv, error: ie } = await svc.auth.admin.inviteUserByEmail(v.email, {
      data: { full_name: v.full_name },
      ...(v.redirect_to ? { redirectTo: v.redirect_to } : {}),
    });
    if (ie) {
      if (/already|registered|exists/i.test(ie.message || '')) return json(409, { error: 'exists' });
      if (/rate|limit/i.test(ie.message || '')) return json(429, { error: 'email_rate_limit' });
      return json(502, { error: 'invite_failed', message: ie.message });
    }
    await svc.from('audit_log').insert({ actor_id: u.user.id, action: 'invite', entity: 'profiles', entity_id: inv?.user?.id ?? null,
      details: { email: v.email, role: v.role, group: v.group_code } });
    return json(200, { ok: true, user_id: inv?.user?.id ?? null });
  };
}
