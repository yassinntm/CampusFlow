// Fonction Edge Supabase « admin-users » : invitation de comptes par l'administration. Voir docs/DEPLOYMENT.md
// SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis automatiquement côté serveur par Supabase.
import { createClient } from 'jsr:@supabase/supabase-js@2';
import { createHandler } from './handler.ts';

const url = Deno.env.get('SUPABASE_URL')!;
Deno.serve(createHandler({
  env: Deno.env,
  userClient: (authHeader) => createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } }),
  serviceClient: () => createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false, autoRefreshToken: false } }),
}));
