// Fonction Edge Supabase « ai-assistant » (Deno). Déploiement : voir docs/DEPLOYMENT.md
// Secrets nécessaires (supabase secrets set) : ANTHROPIC_API_KEY ; facultatifs : AI_MODEL, AI_DAILY_LIMIT.
// SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis automatiquement par Supabase côté serveur.
import { createClient } from 'jsr:@supabase/supabase-js@2';
import { createHandler } from './handler.ts';

const url = Deno.env.get('SUPABASE_URL')!;
const handler = createHandler({
  env: Deno.env,
  fetch,
  userClient: (authHeader) => createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } }),
  serviceClient: () => createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } }),
});
Deno.serve(handler);
