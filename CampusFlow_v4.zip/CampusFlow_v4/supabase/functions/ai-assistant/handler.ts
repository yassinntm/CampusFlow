// Logique de l'assistant d'étude, sans dépendance à Deno (testable avec Node).
// Sécurité : JWT de l'utilisateur vérifié, quota quotidien atomique en base, clé IA lue uniquement depuis les secrets serveur.

export interface Env { get(name: string): string | undefined }
export interface Deps {
  env: Env;
  fetch: typeof fetch;
  // client Supabase « utilisateur » (RLS appliqué) et « service » (pour le quota uniquement)
  userClient: (authHeader: string) => any;
  serviceClient: () => any;
}
type Msg = { role: 'user' | 'assistant'; content: string };

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

export function validate(body: any): { messages: Msg[]; lang: 'fr' | 'ar' } | null {
  if (!body || !Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 10) return null;
  const messages: Msg[] = [];
  for (const m of body.messages) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string') return null;
    const content = m.content.trim().slice(0, 2000);
    if (!content) return null;
    messages.push({ role: m.role, content });
  }
  if (messages[messages.length - 1].role !== 'user' || messages[0].role !== 'user') return null;
  for (let i = 1; i < messages.length; i++) if (messages[i].role === messages[i - 1].role) return null;
  return { messages, lang: body.lang === 'ar' ? 'ar' : 'fr' };
}

const WD = ['', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
// Contexte : uniquement les données de l'utilisateur, lues avec SES droits (RLS) — jamais d'autres stagiaires
export async function buildContext(db: any, userId: string): Promise<string> {
  const [{ data: p }, { data: mods }, { data: slots }, { data: assess }] = await Promise.all([
    db.from('profiles').select('full_name,role,group_id').eq('id', userId).maybeSingle(),
    db.from('modules').select('id,name'),
    db.from('timetable_slots').select('module_id,weekday,start_time,end_time,status,note').order('weekday').order('start_time').limit(60),
    db.from('assessments').select('kind,title,module_id,due_at').gte('due_at', new Date().toISOString()).order('due_at').limit(15),
  ]);
  const name = (id: string) => (mods || []).find((m: any) => m.id === id)?.name || 'module';
  const lines = [`Utilisateur : ${p?.full_name ?? 'inconnu'} (${p?.role ?? '?'})`];
  if (slots?.length) lines.push('Emploi du temps hebdomadaire : ' + slots.map((s: any) => `${WD[s.weekday]} ${String(s.start_time).slice(0, 5)}-${String(s.end_time).slice(0, 5)} ${name(s.module_id)}${s.status === 'cancelled' ? ' (annulé)' : ''}`).join(' ; '));
  if (assess?.length) lines.push('Échéances à venir : ' + assess.map((a: any) => `${a.kind === 'exam' ? 'Examen' : 'Devoir'} « ${a.title} » (${name(a.module_id)}) le ${a.due_at.slice(0, 10)}`).join(' ; '));
  return lines.join('\n');
}

export const systemPrompt = (ctx: string, lang: 'fr' | 'ar') => `Tu es l'assistant d'étude de CampusFlow pour les stagiaires de la CMC Agadir (OFPPT).
Réponds en ${lang === 'ar' ? 'arabe standard simple' : 'français simple'}, de façon courte et concrète.
Règles :
- Aide à comprendre, réviser, s'organiser et planifier. Pour un devoir noté, explique la méthode et donne des indices : ne rédige pas le travail complet à la place du stagiaire.
- Tu n'as accès qu'aux informations ci-dessous (emploi du temps et échéances de l'utilisateur). Tu n'as PAS accès aux cours, documents, notes ni messages : ne prétends jamais les avoir lus.
- Si tu ne sais pas, dis-le et propose de demander au formateur.
- Ne demande ni ne répète jamais de données personnelles (mot de passe, CIN, téléphone).
Contexte de l'utilisateur :
${ctx}`;

export function createHandler(deps: Deps) {
  return async (req: Request): Promise<Response> => {
    if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
    if (req.method !== 'POST') return json(405, { error: 'method' });
    const apiKey = deps.env.get('ANTHROPIC_API_KEY');
    if (!apiKey) return json(503, { error: 'not_configured' });
    const auth = req.headers.get('Authorization') || '';
    if (!/^Bearer\s+\S+/.test(auth)) return json(401, { error: 'unauthorized' });
    const user = deps.userClient(auth);
    const { data: u, error: ue } = await user.auth.getUser(auth.replace(/^Bearer\s+/, ''));
    if (ue || !u?.user) return json(401, { error: 'unauthorized' });
    let body: any;
    try { body = await req.json(); } catch { return json(400, { error: 'invalid' }); }
    const input = validate(body);
    if (!input) return json(400, { error: 'invalid' });
    const limit = Number(deps.env.get('AI_DAILY_LIMIT') || 30);
    const { data: remaining, error: qe } = await deps.serviceClient().rpc('ai_consume', { p_user: u.user.id, p_limit: limit });
    if (qe) return /quota/.test(qe.message || '') ? json(429, { error: 'quota' }) : json(403, { error: 'forbidden' });
    const ctx = await buildContext(user, u.user.id).catch(() => '');
    const r = await deps.fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: deps.env.get('AI_MODEL') || 'claude-haiku-5-5', max_tokens: 800, system: systemPrompt(ctx, input.lang), messages: input.messages }),
    });
    if (!r.ok) return json(502, { error: 'upstream', status: r.status });
    const out = await r.json();
    const reply = (out.content || []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join('\n').trim();
    if (!reply) return json(502, { error: 'empty' });
    return json(200, { reply, remaining });
  };
}
