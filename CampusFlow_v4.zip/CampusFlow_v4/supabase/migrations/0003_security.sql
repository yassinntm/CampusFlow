-- =====================================================================
--  CampusFlow v3 · 0003 · Sécurité : Row Level Security, droits par colonne, Storage, temps réel
--  Principe : tout est interdit par défaut ; chaque règle ouvre un accès précis.
-- =====================================================================

do $$ declare t text; begin
  foreach t in array array['groups','profiles','roster','modules','rooms','teaching_assignments','timetable_slots','timetable_drafts',
    'timetable_versions','class_sessions','attendance_records','absence_justifications','assessments','assessment_progress','tasks',
    'study_sessions','user_settings','announcements','notifications','notification_reads','posts','replies','post_votes','reports',
    'study_groups','study_group_members','rides','ride_bookings','resources','audit_log','ai_usage'] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;

-- ---------- Référentiels : lecture pour tous les comptes, écriture admin ----------
create policy groups_read on public.groups for select to authenticated using (true);
create policy groups_admin on public.groups for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy modules_read on public.modules for select to authenticated using (true);
create policy modules_admin on public.modules for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy rooms_read on public.rooms for select to authenticated using (true);
create policy rooms_admin on public.rooms for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy teaching_read on public.teaching_assignments for select to authenticated using (true);
create policy teaching_admin on public.teaching_assignments for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy roster_admin on public.roster for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ---------- Profils : soi-même, les stagiaires de ses groupes (formateur), tout (admin) ----------
create policy profiles_read on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin() or (role = 'student' and public.teaches_group(group_id)));
create policy profiles_update_self on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

-- ---------- Emploi du temps ----------
create policy slots_read on public.timetable_slots for select to authenticated
  using (public.can_see_group(group_id) or teacher_id = auth.uid());
create policy slots_admin on public.timetable_slots for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy drafts_admin on public.timetable_drafts for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy versions_read on public.timetable_versions for select to authenticated using (public.can_see_group(group_id));

-- ---------- Séances & assiduité (écriture uniquement via open_session / save_attendance) ----------
create policy sessions_read on public.class_sessions for select to authenticated
  using (group_id = public.my_group() or teacher_id = auth.uid() or public.is_admin());
create policy attendance_read on public.attendance_records for select to authenticated
  using (student_id = auth.uid() or public.is_admin()
         or exists (select 1 from public.class_sessions s where s.id = session_id and s.teacher_id = auth.uid()));
create policy justif_read on public.absence_justifications for select to authenticated
  using (student_id = auth.uid() or public.is_admin()
         or exists (select 1 from public.class_sessions s where s.id = session_id and s.teacher_id = auth.uid()));
create policy justif_insert on public.absence_justifications for insert to authenticated with check (student_id = auth.uid());

-- ---------- Devoirs & examens ----------
create policy assess_read on public.assessments for select to authenticated
  using (group_id is null or public.can_see_group(group_id));
create policy assess_write on public.assessments for all to authenticated
  using (public.is_admin() or (created_by = auth.uid() and public.teaches(group_id, module_id)))
  with check (public.is_admin() or (group_id is not null and module_id is not null and public.teaches(group_id, module_id)));
create policy progress_own on public.assessment_progress for all to authenticated
  using (student_id = auth.uid()) with check (student_id = auth.uid());

-- ---------- Données personnelles ----------
create policy tasks_own on public.tasks for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy study_own on public.study_sessions for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy settings_own on public.user_settings for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------- Annonces ----------
create policy ann_read on public.announcements for select to authenticated
  using (scope = 'all' or public.can_see_group(group_id));
create policy ann_write on public.announcements for all to authenticated
  using (public.is_admin() or (author_id = auth.uid() and public.teaches_group(group_id)))
  with check (public.is_admin() or (scope <> 'all' and public.teaches_group(group_id)
              and (scope = 'group' or public.teaches(group_id, module_id))));

-- ---------- Notifications ----------
create policy notif_read on public.notifications for select to authenticated
  using (target_kind = 'all' or (target_kind = 'group' and public.can_see_group(group_id)) or user_id = auth.uid());
create policy notif_insert on public.notifications for insert to authenticated
  with check (public.is_admin()
    or (target_kind = 'user' and user_id = auth.uid() and kind = 'reminder')
    or (target_kind = 'group' and kind in ('announcement', 'system') and public.teaches_group(group_id)));
create policy notif_admin_delete on public.notifications for delete to authenticated using (public.is_admin());
create policy reads_own on public.notification_reads for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy reads_insert on public.notification_reads for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.notifications n where n.id = notification_id));

-- ---------- Communauté (lecture des questions via la vue posts_feed) ----------
create policy posts_read on public.posts for select to authenticated
  using (group_id = public.my_group() or author_id = auth.uid() or public.teaches_group(group_id) or public.is_admin());
create policy posts_insert on public.posts for insert to authenticated with check (author_id = auth.uid());
create policy posts_update on public.posts for update to authenticated using (author_id = auth.uid()) with check (author_id = auth.uid());
create policy posts_delete on public.posts for delete to authenticated using (author_id = auth.uid() or public.is_admin());

create policy replies_read on public.replies for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id
                 and (p.group_id = public.my_group() or p.author_id = auth.uid() or public.teaches_group(p.group_id) or public.is_admin()))
         and (status = 'visible' or author_id = auth.uid() or public.is_admin()));
create policy replies_insert on public.replies for insert to authenticated
  with check (author_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id
              and (p.group_id = public.my_group() or p.author_id = auth.uid() or public.teaches_group(p.group_id) or public.is_admin())));
create policy replies_delete on public.replies for delete to authenticated using (author_id = auth.uid() or public.is_admin());

create policy votes_read on public.post_votes for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy votes_insert on public.post_votes for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id and p.status = 'visible'
              and (p.group_id = public.my_group() or public.teaches_group(p.group_id))));
create policy votes_delete on public.post_votes for delete to authenticated using (user_id = auth.uid());

create policy reports_insert on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy reports_read on public.reports for select to authenticated using (reporter_id = auth.uid() or public.is_admin());

-- ---------- Groupes de révision & covoiturage (visibles par tout l'établissement) ----------
create policy sg_read on public.study_groups for select to authenticated using (status = 'visible' or created_by = auth.uid() or public.is_admin());
create policy sg_insert on public.study_groups for insert to authenticated with check (created_by = auth.uid());
create policy sg_delete on public.study_groups for delete to authenticated using (created_by = auth.uid() or public.is_admin());
create policy sgm_read on public.study_group_members for select to authenticated using (true);
create policy sgm_insert on public.study_group_members for insert to authenticated with check (user_id = auth.uid());
create policy sgm_delete on public.study_group_members for delete to authenticated using (user_id = auth.uid() or public.is_admin());

create policy rides_read on public.rides for select to authenticated using (status = 'visible' or author_id = auth.uid() or public.is_admin());
create policy rides_insert on public.rides for insert to authenticated with check (author_id = auth.uid());
create policy rides_delete on public.rides for delete to authenticated using (author_id = auth.uid() or public.is_admin());
create policy rb_read on public.ride_bookings for select to authenticated using (true);
create policy rb_insert on public.ride_bookings for insert to authenticated with check (user_id = auth.uid());
create policy rb_delete on public.ride_bookings for delete to authenticated using (user_id = auth.uid() or public.is_admin());

-- ---------- Ressources ----------
create policy res_read on public.resources for select to authenticated
  using (public.is_admin() or (group_id is null and (public.my_role() is not null)) or public.can_see_group(group_id));
create policy res_write on public.resources for insert to authenticated
  with check (public.is_admin() or (group_id is not null and public.teaches(group_id, module_id))
              or (group_id is null and exists (select 1 from public.teaching_assignments t where t.teacher_id = auth.uid() and t.module_id = resources.module_id)));
create policy res_delete on public.resources for delete to authenticated using (public.is_admin() or created_by = auth.uid());

-- ---------- Journal & quotas ----------
create policy audit_admin on public.audit_log for select to authenticated using (public.is_admin());
create policy ai_usage_own on public.ai_usage for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- =====================================================================
--  Droits par colonne et par opération (en plus de RLS)
-- =====================================================================
revoke all on all tables in schema public from anon;
revoke all on all functions in schema public from anon, public;

-- Codes d'accès : jamais lisibles directement (RPC admin_group_codes)
revoke select on public.groups from authenticated;
grant select (id, code, label, filiere, year, created_at) on public.groups to authenticated;
-- Profils : seuls le nom et le téléphone sont modifiables par l'utilisateur (le reste via RPC admin)
revoke update on public.profiles from authenticated;
grant update (full_name, phone) on public.profiles to authenticated;
revoke insert, delete on public.profiles from authenticated;
-- Séances et appel : uniquement par les fonctions open_session / save_attendance / review_justification
revoke insert, update, delete on public.class_sessions, public.attendance_records from authenticated;
revoke update, delete on public.absence_justifications from authenticated;
-- Questions : lecture via posts_feed ; l'auteur ne peut modifier que « résolu » et « meilleure réponse »
revoke select, update on public.posts from authenticated;
grant select (id, group_id, author_id, status) on public.posts to authenticated;
grant update (resolved, best_reply_id) on public.posts to authenticated;
revoke update on public.replies, public.post_votes, public.reports, public.ride_bookings, public.study_group_members from authenticated;
-- Journal et quotas : lecture seule
revoke insert, update, delete on public.audit_log, public.ai_usage, public.timetable_versions from authenticated;
revoke update, delete on public.notifications from authenticated;
grant delete on public.notifications to authenticated;   -- limité à l'admin par RLS

grant select on public.people, public.posts_feed, public.attendance_summary to authenticated;
revoke all on public.people, public.posts_feed, public.attendance_summary from anon;

-- Fonctions appelables par l'appli (les autres sont internes)
grant execute on function public.check_join_code(text) to anon, authenticated;
grant execute on function public.my_role(), public.is_admin(), public.is_teacher(), public.my_group(), public.teaches_group(uuid),
  public.teaches(uuid, uuid), public.can_see_group(uuid), public.local_today(), public.module_name(uuid) to authenticated;
grant execute on function public.check_timetable_conflicts(uuid), public.publish_timetable(uuid), public.start_timetable_draft(uuid, boolean), public.open_session(uuid, date),
  public.save_attendance(uuid, jsonb), public.review_justification(uuid, uuid, boolean), public.moderate(text, uuid, text, text),
  public.mute_user(uuid, int), public.admin_set_role(uuid, public.app_role, uuid), public.admin_set_status(uuid, text), public.admin_delete_user(uuid),
  public.admin_group_codes(), public.regenerate_join_code(uuid), public.import_roster(jsonb, boolean) to authenticated;

-- =====================================================================
--  Storage : bucket privé « resources » (fichiers de cours)
-- =====================================================================
do $$ begin
  if exists (select 1 from pg_namespace where nspname = 'storage') and exists (select 1 from information_schema.tables where table_schema = 'storage' and table_name = 'buckets') then
    insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    values ('resources', 'resources', false, 26214400, array['application/pdf', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/zip', 'image/png', 'image/jpeg', 'text/plain'])
    on conflict (id) do nothing;
    execute $p$ create policy resources_read on storage.objects for select to authenticated
      using (bucket_id = 'resources' and exists (select 1 from public.resources r where r.storage_path = name)) $p$;
    execute $p$ create policy resources_upload on storage.objects for insert to authenticated
      with check (bucket_id = 'resources' and (public.is_admin() or public.is_teacher()) and (storage.foldername(name))[1] = auth.uid()::text) $p$;
    execute $p$ create policy resources_remove on storage.objects for delete to authenticated
      using (bucket_id = 'resources' and (public.is_admin() or (storage.foldername(name))[1] = auth.uid()::text)) $p$;
  end if;
end $$;

-- =====================================================================
--  Temps réel : tables diffusées (les règles RLS s'appliquent aussi aux messages)
-- =====================================================================
do $$ declare t text; begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['notifications','announcements','assessments','timetable_slots','attendance_records','replies',
      'study_groups','study_group_members','rides','ride_bookings','resources'] loop
      if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;
