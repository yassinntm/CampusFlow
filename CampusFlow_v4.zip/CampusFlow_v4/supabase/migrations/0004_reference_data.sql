-- =====================================================================
--  CampusFlow v3 · 0004 · Données de départ (à adapter à votre établissement)
--  Aucune donnée personnelle : seulement des groupes, modules et salles d'exemple.
--  Vous pouvez tout modifier ensuite dans l'espace admin.
-- =====================================================================
insert into public.groups (code, label, filiere, year) values
  ('ID101', 'Infrastructure Digitale · G1', 'Infrastructure Digitale', 1),
  ('ID102', 'Infrastructure Digitale · G2', 'Infrastructure Digitale', 1),
  ('DEV101', 'Développement Digital · G1', 'Développement Digital', 1)
on conflict (code) do nothing;

insert into public.modules (code, name) values
  ('M101', 'Réseaux informatiques'),
  ('M102', 'Systèmes Linux'),
  ('M103', 'Windows Server'),
  ('M104', 'Sécurité informatique'),
  ('M105', 'Cloud computing'),
  ('M106', 'Développement web'),
  ('M107', 'Français professionnel'),
  ('M108', 'Anglais technique'),
  ('M109', 'Culture entrepreneuriale')
on conflict (code) do nothing;

insert into public.rooms (name, kind, capacity) values
  ('Labo 1', 'labo', 24), ('Labo 2', 'labo', 24), ('Labo 3', 'labo', 24), ('Labo 4', 'labo', 24),
  ('Salle 8', 'salle', 32), ('Salle 12', 'salle', 32), ('Salle B4', 'salle', 28), ('Amphi A', 'amphi', 150)
on conflict (name) do nothing;
