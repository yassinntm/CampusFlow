-- =====================================================================
--  CampusFlow v3 — 0006 : durcissement (conseiller de sécurité Supabase)
-- =====================================================================
alter function public.app_tz() set search_path = '';
alter function public.local_today() set search_path = '';
alter function public.fail(text, text) set search_path = '';
alter function public.touch_updated_at() set search_path = '';
create schema if not exists extensions;
alter extension btree_gist set schema extensions;
