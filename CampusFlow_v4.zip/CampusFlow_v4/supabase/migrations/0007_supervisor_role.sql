-- =====================================================================
--  CampusFlow v3 — 0007 : rôle « surveillant général » (personnel de la vie scolaire)
--  Fichier séparé : une nouvelle valeur d'enum ne peut pas être utilisée dans la transaction qui la crée.
-- =====================================================================
alter type public.app_role add value if not exists 'supervisor';
