-- =====================================================================
--  CampusFlow v3 · 0002 · Fonctions serveur, triggers et RPC
--  Toute la logique sensible (droits, publication, assiduité, modération, notifications, audit)
--  s'exécute ici, dans la base : le navigateur ne peut pas la contourner.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Fonctions d'aide (lecture des droits de l'utilisateur courant)
-- ---------------------------------------------------------------------
-- Fuseau de l'établissement. Par défaut Africa/Casablanca ; configurable si les données de fuseau du serveur sont anciennes
-- (le Maroc est passé à GMT permanent le 20/09/2026) :  alter database postgres set app.timezone = 'UTC';
create or replace function public.app_tz() returns text
language sql stable as $$ select coalesce(nullif(current_setting('app.timezone', true), ''), 'Africa/Casablanca') $$;

create or replace function public.local_today() returns date
language sql stable as $$ select (now() at time zone public.app_tz())::date $$;

create or replace function public.my_role() returns public.app_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and status = 'active'
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() = 'admin', false)
$$;

create or replace function public.is_teacher() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() = 'teacher', false)
$$;

create or replace function public.my_group() returns uuid
language sql stable security definer set search_path = public as $$
  select group_id from public.profiles where id = auth.uid() and status = 'active'
$$;

create or replace function public.teaches_group(g uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_teacher() and exists (select 1 from public.teaching_assignments where teacher_id = auth.uid() and group_id = g)
$$;

create or replace function public.teaches(g uuid, m uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_teacher() and exists (select 1 from public.teaching_assignments where teacher_id = auth.uid() and group_id = g and module_id = m)
$$;

create or replace function public.can_see_group(g uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select g = public.my_group() or public.teaches_group(g) or public.is_admin()
$$;

-- Petite erreur lisible côté appli : « CF:code|message »
create or replace function public.fail(p_code text, p_message text) returns void
language plpgsql as $$ begin raise exception 'CF:%|%', p_code, p_message using errcode = 'P0001'; end $$;

-- ---------------------------------------------------------------------
-- 2. Comptes : inscription par pré-inscription (roster) ou code de groupe
-- ---------------------------------------------------------------------
create or replace function public.check_join_code(p_code text) returns table (code text, label text)
language sql stable security definer set search_path = public as $$
  select g.code, g.label from public.groups g where g.join_code = upper(trim(p_code))
$$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  r public.roster;
  g uuid;
  v_name text := nullif(trim(new.raw_user_meta_data->>'full_name'), '');
begin
  select * into r from public.roster where email = lower(new.email);
  if found then
    insert into public.profiles (id, full_name, email, role, group_id)
    values (new.id, left(coalesce(v_name, r.full_name, split_part(new.email, '@', 1)), 80), lower(new.email), r.role, r.group_id);
    return new;
  end if;
  -- Sans pré-inscription : uniquement étudiant, avec le code d'accès de son groupe (jamais un rôle envoyé par le client)
  select id into g from public.groups where join_code = upper(trim(coalesce(new.raw_user_meta_data->>'join_code', '')));
  if g is null then
    perform public.fail('invalid_code', 'Code d''accès invalide');
  end if;
  insert into public.profiles (id, full_name, email, role, group_id)
  values (new.id, left(coalesce(v_name, split_part(new.email, '@', 1)), 80), lower(new.email), 'student', g);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Un utilisateur ne peut modifier que son nom et son téléphone ; le reste est réservé à l'admin.
create or replace function public.protect_profile() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() and (
       new.role is distinct from old.role or new.group_id is distinct from old.group_id or new.status is distinct from old.status
    or new.email is distinct from old.email or new.muted_until is distinct from old.muted_until or new.id <> old.id) then
    perform public.fail('forbidden', 'Modification réservée à l''administration');
  end if;
  if public.is_admin() and old.id = auth.uid() and (new.role <> 'admin' or new.status <> 'active') then
    perform public.fail('forbidden', 'Vous ne pouvez pas retirer vos propres droits d''administrateur');
  end if;
  new.updated_at := now();
  return new;
end $$;
create trigger profiles_protect before update on public.profiles for each row execute function public.protect_profile();

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;
create trigger t_slots_touch before update on public.timetable_slots for each row execute function public.touch_updated_at();
create trigger t_drafts_touch before update on public.timetable_drafts for each row execute function public.touch_updated_at();
create trigger t_assess_touch before update on public.assessments for each row execute function public.touch_updated_at();
create trigger t_ann_touch before update on public.announcements for each row execute function public.touch_updated_at();
create trigger t_posts_touch before update on public.posts for each row execute function public.touch_updated_at();
create trigger t_settings_touch before update on public.user_settings for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------
-- 3. Journal d'audit générique (actions sensibles)
-- ---------------------------------------------------------------------
create or replace function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_old jsonb := case when tg_op in ('UPDATE', 'DELETE') then to_jsonb(old) end;
  v_new jsonb := case when tg_op in ('INSERT', 'UPDATE') then to_jsonb(new) end;
  v_id text := coalesce(v_new->>'id', v_old->>'id', v_new->>'email', v_old->>'email',
                        concat_ws(':', coalesce(v_new->>'session_id', v_old->>'session_id'), coalesce(v_new->>'student_id', v_old->>'student_id')));
begin
  -- On ne garde que ce qui a changé (et jamais de contenu volumineux)
  if tg_op = 'UPDATE' then
    select jsonb_object_agg(k, jsonb_build_object('old', v_old->k, 'new', v_new->k)) into v_new
    from jsonb_object_keys(v_new) k where (v_old->k) is distinct from (v_new->k) and k not in ('updated_at', 'body', 'description', 'snapshot');
    if v_new is null then return new; end if;
    v_old := null;
  end if;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), lower(tg_op), tg_table_name, v_id,
          coalesce(case when tg_op = 'UPDATE' then v_new else (coalesce(v_new, v_old) - 'body' - 'description') end, '{}'::jsonb));
  return coalesce(new, old);
end $$;

create trigger audit_groups after insert or update or delete on public.groups for each row execute function public.audit_row();
create trigger audit_roster after insert or update or delete on public.roster for each row execute function public.audit_row();
create trigger audit_modules after insert or update or delete on public.modules for each row execute function public.audit_row();
create trigger audit_rooms after insert or update or delete on public.rooms for each row execute function public.audit_row();
create trigger audit_teaching after insert or update or delete on public.teaching_assignments for each row execute function public.audit_row();
create trigger audit_profiles after update or delete on public.profiles for each row execute function public.audit_row();
create trigger audit_attendance after insert or update or delete on public.attendance_records for each row execute function public.audit_row();
create trigger audit_assessments after insert or update or delete on public.assessments for each row execute function public.audit_row();
create trigger audit_announcements after insert or update or delete on public.announcements for each row execute function public.audit_row();
create trigger audit_resources after insert or delete on public.resources for each row execute function public.audit_row();

-- ---------------------------------------------------------------------
-- 4. Notifications (générées par la base, jamais par le navigateur des autres)
-- ---------------------------------------------------------------------
create or replace function public.notify(p_target text, p_group uuid, p_user uuid, p_kind text, p_title text, p_body text, p_link text default null, p_important boolean default false)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (target_kind, group_id, user_id, kind, title, body, link, important)
  values (p_target, p_group, p_user, p_kind, left(p_title, 160), left(coalesce(p_body, ''), 600), p_link, p_important)
$$;

create or replace function public.module_name(m uuid) returns text
language sql stable security definer set search_path = public as $$ select coalesce((select name from public.modules where id = m), '') $$;

-- ---------------------------------------------------------------------
-- 5. Limitation de débit (anti-spam) et utilisateurs suspendus
-- ---------------------------------------------------------------------
create or replace function public.enforce_rate(p_table text, p_author_col text, p_window interval, p_max int, p_label text)
returns void language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if public.is_admin() then return; end if;
  if exists (select 1 from public.profiles where id = auth.uid() and muted_until > now()) then
    perform public.fail('muted', 'Votre compte est temporairement limité dans la communauté');
  end if;
  execute format('select count(*) from public.%I where %I = $1 and created_at > now() - $2', p_table, p_author_col)
    into n using auth.uid(), p_window;
  if n >= p_max then
    perform public.fail('rate_limited', 'Trop de ' || p_label || ' en peu de temps. Réessayez plus tard.');
  end if;
end $$;

-- ---------------------------------------------------------------------
-- 6. Emploi du temps : conflits et publication atomique
-- ---------------------------------------------------------------------
create or replace function public.check_timetable_conflicts(p_group uuid)
returns table (kind text, draft_id uuid, weekday smallint, start_time time, end_time time, message text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  return query
  with d as (
    select t.*, (extract(hour from t.start_time) * 60 + extract(minute from t.start_time))::int s,
                (extract(hour from t.end_time) * 60 + extract(minute from t.end_time))::int e
    from public.timetable_drafts t where t.group_id = p_group and t.status = 'active'
  )
  -- a) Chevauchement à l'intérieur du groupe
  select 'group'::text, a.id, a.weekday, a.start_time, a.end_time,
         format('%s chevauche %s (%s–%s)', public.module_name(a.module_id), public.module_name(b.module_id), to_char(b.start_time, 'HH24:MI'), to_char(b.end_time, 'HH24:MI'))
  from d a join d b on a.id < b.id and a.weekday = b.weekday and a.s < b.e and b.s < a.e
  union all
  -- b) Formateur déjà occupé (dans ce brouillon ou dans un autre groupe publié)
  select 'teacher', a.id, a.weekday, a.start_time, a.end_time,
         format('%s est déjà en cours avec %s (%s–%s)', p.full_name, g.code, to_char(x.start_time, 'HH24:MI'), to_char(x.end_time, 'HH24:MI'))
  from d a
  join public.timetable_slots x on x.teacher_id = a.teacher_id and x.group_id <> p_group and x.status = 'active'
       and x.weekday = a.weekday and x.start_min < a.e and a.s < x.end_min
  join public.profiles p on p.id = a.teacher_id
  join public.groups g on g.id = x.group_id
  union all
  select 'teacher', a.id, a.weekday, a.start_time, a.end_time,
         format('%s a deux cours en même temps dans ce brouillon', p.full_name)
  from d a join d b on a.id < b.id and a.teacher_id = b.teacher_id and a.weekday = b.weekday and a.s < b.e and b.s < a.e
  join public.profiles p on p.id = a.teacher_id
  union all
  -- c) Salle déjà occupée
  select 'room', a.id, a.weekday, a.start_time, a.end_time,
         format('Salle %s déjà prise par %s (%s–%s)', r.name, g.code, to_char(x.start_time, 'HH24:MI'), to_char(x.end_time, 'HH24:MI'))
  from d a
  join public.timetable_slots x on x.room_id = a.room_id and x.group_id <> p_group and x.status = 'active'
       and x.weekday = a.weekday and x.start_min < a.e and a.s < x.end_min
  join public.rooms r on r.id = a.room_id
  join public.groups g on g.id = x.group_id
  union all
  select 'room', a.id, a.weekday, a.start_time, a.end_time, format('Salle %s utilisée deux fois en même temps dans ce brouillon', r.name)
  from d a join d b on a.id < b.id and a.room_id = b.room_id and a.weekday = b.weekday and a.s < b.e and b.s < a.e
  join public.rooms r on r.id = a.room_id;
end $$;

create or replace function public.slot_label(p_module uuid, p_weekday smallint, p_start time) returns text
language sql stable security definer set search_path = public as $$
  select public.module_name(p_module) || ' (' || (array['lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'])[p_weekday] || ' ' || to_char(p_start, 'HH24:MI') || ')'
$$;

create or replace function public.publish_timetable(p_group uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_changes jsonb := '[]'::jsonb;
  v_version int;
  v_conflicts int;
  rec record;
  v_txt text;
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  perform 1 from public.groups where id = p_group for update;            -- une seule publication à la fois par groupe
  if not found then perform public.fail('not_found', 'Groupe introuvable'); end if;

  -- Le brouillon contient l'emploi du temps complet (copié par start_timetable_draft). Brouillon absent = rien à publier,
  -- jamais « tout supprimer » (sinon une double publication effacerait l'emploi du temps).
  if not exists (select 1 from public.timetable_drafts where group_id = p_group) then
    perform public.fail('no_changes', 'Aucun changement à publier');
  end if;

  select count(*) into v_conflicts from public.check_timetable_conflicts(p_group);
  if v_conflicts > 0 then perform public.fail('conflicts', v_conflicts || ' conflit(s) à corriger avant de publier'); end if;

  -- Créneaux retirés
  for rec in select s.* from public.timetable_slots s where s.group_id = p_group
             and not exists (select 1 from public.timetable_drafts d where d.group_id = p_group and d.source_slot_id = s.id) loop
    v_changes := v_changes || jsonb_build_object('type', 'remove', 'text', 'Cours retiré : ' || public.slot_label(rec.module_id, rec.weekday, rec.start_time));
  end loop;
  -- Créneaux ajoutés
  for rec in select d.* from public.timetable_drafts d where d.group_id = p_group
             and (d.source_slot_id is null or not exists (select 1 from public.timetable_slots s where s.id = d.source_slot_id)) loop
    v_changes := v_changes || jsonb_build_object('type', 'add', 'text', 'Nouveau cours : ' || public.slot_label(rec.module_id, rec.weekday, rec.start_time));
  end loop;
  -- Créneaux modifiés
  for rec in select d.*, s.module_id o_module, s.teacher_id o_teacher, s.room_id o_room, s.weekday o_weekday, s.start_time o_start,
                    s.end_time o_end, s.status o_status, s.kind o_kind, s.note o_note
             from public.timetable_drafts d join public.timetable_slots s on s.id = d.source_slot_id where d.group_id = p_group loop
    v_txt := null;
    if rec.status = 'cancelled' and rec.o_status = 'active' then
      v_txt := 'Cours annulé : ' || public.slot_label(rec.module_id, rec.weekday, rec.start_time) || coalesce(' · ' || rec.note, '');
      v_changes := v_changes || jsonb_build_object('type', 'cancel', 'text', v_txt);
    elsif rec.status = 'active' and rec.o_status = 'cancelled' then
      v_changes := v_changes || jsonb_build_object('type', 'restore', 'text', 'Cours rétabli : ' || public.slot_label(rec.module_id, rec.weekday, rec.start_time));
    elsif rec.room_id is distinct from rec.o_room and rec.weekday = rec.o_weekday and rec.start_time = rec.o_start and rec.end_time = rec.o_end and rec.module_id = rec.o_module then
      v_changes := v_changes || jsonb_build_object('type', 'room', 'text', public.slot_label(rec.module_id, rec.weekday, rec.start_time) || ' : salle '
        || coalesce((select name from public.rooms where id = rec.o_room), '—') || ' → ' || coalesce((select name from public.rooms where id = rec.room_id), '—'));
    elsif (rec.module_id, rec.teacher_id, rec.room_id, rec.weekday, rec.start_time, rec.end_time, rec.kind, rec.note)
          is distinct from (rec.o_module, rec.o_teacher, rec.o_room, rec.o_weekday, rec.o_start, rec.o_end, rec.o_kind, rec.o_note) then
      v_changes := v_changes || jsonb_build_object('type', 'change', 'text', 'Cours modifié : ' || public.slot_label(rec.o_module, rec.o_weekday, rec.o_start)
        || ' → ' || public.slot_label(rec.module_id, rec.weekday, rec.start_time));
    end if;
  end loop;

  if jsonb_array_length(v_changes) = 0 then perform public.fail('no_changes', 'Aucun changement à publier'); end if;

  -- Application atomique (les contraintes d'exclusion sont vérifiées à la fin de la transaction)
  delete from public.timetable_slots s where s.group_id = p_group
    and not exists (select 1 from public.timetable_drafts d where d.group_id = p_group and d.source_slot_id = s.id);
  update public.timetable_slots s set module_id = d.module_id, teacher_id = d.teacher_id, room_id = d.room_id, weekday = d.weekday,
         start_time = d.start_time, end_time = d.end_time, kind = d.kind, status = d.status, note = d.note
    from public.timetable_drafts d where d.group_id = p_group and d.source_slot_id = s.id;
  insert into public.timetable_slots (group_id, module_id, teacher_id, room_id, weekday, start_time, end_time, kind, status, note)
    select d.group_id, d.module_id, d.teacher_id, d.room_id, d.weekday, d.start_time, d.end_time, d.kind, d.status, d.note
    from public.timetable_drafts d where d.group_id = p_group
      and (d.source_slot_id is null or not exists (select 1 from public.timetable_slots s where s.id = d.source_slot_id));
  begin
    set constraints all immediate;
  exception when exclusion_violation then
    perform public.fail('conflicts', 'Conflit d''horaire avec un autre groupe, formateur ou salle');
  end;

  select coalesce(max(version), 0) + 1 into v_version from public.timetable_versions where group_id = p_group;
  insert into public.timetable_versions (group_id, version, published_by, changes, snapshot)
  values (p_group, v_version, auth.uid(), v_changes,
    coalesce((select jsonb_agg(jsonb_build_object('module', m.name, 'teacher', p.full_name, 'room', r.name, 'weekday', s.weekday,
              'start', to_char(s.start_time, 'HH24:MI'), 'end', to_char(s.end_time, 'HH24:MI'), 'kind', s.kind, 'status', s.status) order by s.weekday, s.start_time)
     from public.timetable_slots s join public.modules m on m.id = s.module_id
     left join public.profiles p on p.id = s.teacher_id left join public.rooms r on r.id = s.room_id where s.group_id = p_group), '[]'::jsonb));

  delete from public.timetable_drafts where group_id = p_group;

  -- Notifications : un résumé + le détail des annulations et changements de salle
  perform public.notify('group', p_group, null, 'timetable', 'Emploi du temps mis à jour (v' || v_version || ')',
    jsonb_array_length(v_changes) || ' changement(s) publié(s) par l''administration.', 'schedule', false);
  for rec in select e from jsonb_array_elements(v_changes) e where e->>'type' in ('cancel', 'room') limit 5 loop
    perform public.notify('group', p_group, null, case when rec.e->>'type' = 'cancel' then 'cancel' else 'room' end,
      case when rec.e->>'type' = 'cancel' then 'Cours annulé' else 'Changement de salle' end, rec.e->>'text', 'schedule', true);
  end loop;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'publish', 'timetable', p_group::text, jsonb_build_object('version', v_version, 'changes', v_changes));
  return jsonb_build_object('version', v_version, 'changes', v_changes);
end $$;

-- ---------------------------------------------------------------------
-- 7. Séances et assiduité
-- ---------------------------------------------------------------------
-- Ouvre un brouillon : copie de l'emploi du temps publié (le brouillon représente toujours l'emploi du temps complet)
create or replace function public.start_timetable_draft(p_group uuid, p_reset boolean default false) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  perform 1 from public.groups where id = p_group for update;
  if not found then perform public.fail('not_found', 'Groupe introuvable'); end if;
  if exists (select 1 from public.timetable_drafts where group_id = p_group) then
    if not p_reset then select count(*) into n from public.timetable_drafts where group_id = p_group; return n; end if;
    delete from public.timetable_drafts where group_id = p_group;
  end if;
  insert into public.timetable_drafts (group_id, source_slot_id, module_id, teacher_id, room_id, weekday, start_time, end_time, kind, status, note)
    select group_id, id, module_id, teacher_id, room_id, weekday, start_time, end_time, kind, status, note
    from public.timetable_slots where group_id = p_group;
  get diagnostics n = row_count;
  return n;
end $$;

create or replace function public.open_session(p_slot uuid, p_date date) returns uuid
language plpgsql security definer set search_path = public as $$
declare s public.timetable_slots; v_id uuid;
begin
  select * into s from public.timetable_slots where id = p_slot;
  if not found then perform public.fail('not_found', 'Créneau introuvable'); end if;
  if not (public.is_admin() or (public.is_teacher() and s.teacher_id = auth.uid())) then
    perform public.fail('forbidden', 'Seul le formateur du cours ou l''administration peut faire l''appel');
  end if;
  if extract(isodow from p_date) <> s.weekday then perform public.fail('invalid_date', 'Cette date ne correspond pas au jour du cours'); end if;
  if p_date > public.local_today() then perform public.fail('invalid_date', 'Impossible de faire l''appel d''une séance future'); end if;
  if not public.is_admin() and p_date < public.local_today() - 30 then
    perform public.fail('invalid_date', 'Séance trop ancienne : contactez l''administration');
  end if;
  select id into v_id from public.class_sessions where slot_id = p_slot and session_date = p_date;
  if v_id is null then
    insert into public.class_sessions (slot_id, group_id, module_id, teacher_id, room_id, session_date, start_time, end_time, status, created_by)
    values (s.id, s.group_id, s.module_id, s.teacher_id, s.room_id, p_date, s.start_time, s.end_time,
            case when s.status = 'cancelled' then 'cancelled' else 'held' end, auth.uid())
    returning id into v_id;
  end if;
  return v_id;
end $$;

-- Enregistre tout l'appel d'une séance en une seule opération
-- p_records = [{"student_id": "...", "status": "present|absent|late|excused", "minutes_late": 10, "note": "..."}]
create or replace function public.save_attendance(p_session uuid, p_records jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare cs public.class_sessions; r jsonb; n int := 0; v_old text; v_status text;
begin
  select * into cs from public.class_sessions where id = p_session;
  if not found then perform public.fail('not_found', 'Séance introuvable'); end if;
  if not (public.is_admin() or (public.is_teacher() and cs.teacher_id = auth.uid())) then
    perform public.fail('forbidden', 'Seul le formateur du cours ou l''administration peut modifier l''appel');
  end if;
  if not public.is_admin() and cs.session_date < public.local_today() - 30 then
    perform public.fail('invalid_date', 'Séance trop ancienne : contactez l''administration');
  end if;
  if jsonb_typeof(p_records) <> 'array' or jsonb_array_length(p_records) > 200 then perform public.fail('invalid', 'Liste invalide'); end if;

  for r in select * from jsonb_array_elements(p_records) loop
    v_status := r->>'status';
    if v_status not in ('present', 'absent', 'late', 'excused') then perform public.fail('invalid', 'Statut invalide'); end if;
    if not exists (select 1 from public.profiles where id = (r->>'student_id')::uuid and role = 'student' and group_id = cs.group_id) then
      perform public.fail('invalid', 'Un stagiaire ne fait pas partie de ce groupe');
    end if;
    select status into v_old from public.attendance_records where session_id = p_session and student_id = (r->>'student_id')::uuid;
    insert into public.attendance_records (session_id, student_id, status, minutes_late, note, recorded_by, recorded_at)
    values (p_session, (r->>'student_id')::uuid, v_status,
            case when v_status = 'late' then greatest(1, least(240, coalesce((r->>'minutes_late')::int, 5))) end,
            nullif(left(r->>'note', 200), ''), auth.uid(), now())
    on conflict (session_id, student_id) do update
      set status = excluded.status, minutes_late = excluded.minutes_late, note = excluded.note, recorded_by = excluded.recorded_by, recorded_at = now()
      where (attendance_records.status, attendance_records.minutes_late, attendance_records.note) is distinct from (excluded.status, excluded.minutes_late, excluded.note);
    if v_status in ('absent', 'late') and v_old is distinct from v_status then
      perform public.notify('user', null, (r->>'student_id')::uuid, 'attendance',
        case when v_status = 'absent' then 'Absence enregistrée' else 'Retard enregistré' end,
        public.module_name(cs.module_id) || ' · ' || to_char(cs.session_date, 'DD/MM/YYYY') || ' ' || to_char(cs.start_time, 'HH24:MI')
        || case when v_status = 'absent' then '. Vous pouvez envoyer un justificatif depuis « Assiduité ».' else '' end, 'attendance', false);
    end if;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.review_justification(p_session uuid, p_student uuid, p_accept boolean) returns void
language plpgsql security definer set search_path = public as $$
declare cs public.class_sessions;
begin
  select * into cs from public.class_sessions where id = p_session;
  if not (public.is_admin() or (public.is_teacher() and cs.teacher_id = auth.uid())) then
    perform public.fail('forbidden', 'Action non autorisée');
  end if;
  update public.absence_justifications set status = case when p_accept then 'accepted' else 'rejected' end, reviewed_by = auth.uid(), reviewed_at = now()
    where session_id = p_session and student_id = p_student and status = 'pending';
  if not found then perform public.fail('not_found', 'Justificatif introuvable ou déjà traité'); end if;
  if p_accept then
    update public.attendance_records set status = 'excused', minutes_late = null, recorded_by = auth.uid(), recorded_at = now()
      where session_id = p_session and student_id = p_student;
  end if;
  perform public.notify('user', null, p_student, 'attendance', case when p_accept then 'Justificatif accepté' else 'Justificatif refusé' end,
    public.module_name(cs.module_id) || ' · ' || to_char(cs.session_date, 'DD/MM/YYYY'), 'attendance', false);
end $$;

create or replace function public.justification_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.student_id := auth.uid(); new.status := 'pending'; new.reviewed_by := null; new.reviewed_at := null;
    if not exists (select 1 from public.attendance_records where session_id = new.session_id and student_id = new.student_id and status in ('absent', 'late')) then
      perform public.fail('invalid', 'Seule une absence ou un retard peut être justifié');
    end if;
  end if;
  return new;
end $$;
create trigger justification_guard before insert on public.absence_justifications for each row execute function public.justification_guard();

-- ---------------------------------------------------------------------
-- 8. Devoirs, examens, annonces : auteur forcé + notifications
-- ---------------------------------------------------------------------
create or replace function public.assessment_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then new.created_by := auth.uid(); else new.created_by := old.created_by; end if;
  if new.kind = 'assignment' then new.duration_min := null; end if;
  return new;
end $$;
create trigger assessment_before before insert or update on public.assessments for each row execute function public.assessment_before();

create or replace function public.assessment_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_title text; v_body text;
begin
  if tg_op = 'UPDATE' and new.due_at = old.due_at and new.room_id is not distinct from old.room_id then return new; end if;
  v_title := case when new.kind = 'exam' then (case when tg_op = 'INSERT' then 'Nouvel examen' else 'Examen modifié' end)
                  else (case when tg_op = 'INSERT' then 'Nouveau devoir' else 'Échéance modifiée' end) end;
  v_body := new.title || coalesce(' · ' || nullif(public.module_name(new.module_id), ''), '') || ' · '
            || to_char(new.due_at at time zone public.app_tz(), 'DD/MM HH24:MI');
  perform public.notify(case when new.group_id is null then 'all' else 'group' end, new.group_id, null,
    case when new.kind = 'exam' then 'exam' else 'assignment' end, v_title, v_body, 'assignments', new.kind = 'exam');
  return new;
end $$;
create trigger assessment_after after insert or update on public.assessments for each row execute function public.assessment_after();

create or replace function public.announcement_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then new.author_id := auth.uid(); else new.author_id := old.author_id; end if;
  if new.scope = 'all' then new.group_id := null; new.module_id := null; end if;
  if new.scope = 'group' then new.module_id := null; end if;
  return new;
end $$;
create trigger announcement_before before insert or update on public.announcements for each row execute function public.announcement_before();

create or replace function public.announcement_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.notify(case when new.scope = 'all' then 'all' else 'group' end, new.group_id, null, 'announcement',
    new.title, left(new.body, 200), 'announcements', new.important);
  return new;
end $$;
create trigger announcement_after after insert on public.announcements for each row execute function public.announcement_after();

-- ---------------------------------------------------------------------
-- 9. Communauté : auteur forcé, anti-spam, notifications, signalements
-- ---------------------------------------------------------------------
create or replace function public.post_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    perform public.enforce_rate('posts', 'author_id', interval '10 minutes', 5, 'publications');
    perform public.enforce_rate('posts', 'author_id', interval '1 day', 30, 'publications');
    new.author_id := auth.uid(); new.status := 'visible'; new.resolved := false; new.best_reply_id := null;
    if not public.is_admin() and new.group_id is distinct from public.my_group() and not public.teaches_group(new.group_id) then
      perform public.fail('forbidden', 'Vous ne pouvez publier que dans votre groupe');
    end if;
  else
    -- Par l'auteur : seulement « résolu » et « meilleure réponse » (les colonnes autorisées sont aussi limitées par GRANT)
    if new.best_reply_id is not null and new.best_reply_id is distinct from old.best_reply_id then
      if not exists (select 1 from public.replies where id = new.best_reply_id and post_id = new.id) then
        perform public.fail('invalid', 'Réponse introuvable');
      end if;
      new.resolved := true;
      perform public.notify('user', null, (select author_id from public.replies where id = new.best_reply_id), 'community',
        'Meilleure réponse ⭐', 'Votre réponse à « ' || left(new.title, 60) || ' » a été choisie comme meilleure réponse.', 'post:' || new.id, false);
    end if;
  end if;
  return new;
end $$;
create trigger post_before before insert or update on public.posts for each row execute function public.post_before();

create or replace function public.reply_before() returns trigger
language plpgsql security definer set search_path = public as $$
declare p public.posts;
begin
  perform public.enforce_rate('replies', 'author_id', interval '10 minutes', 15, 'réponses');
  new.author_id := auth.uid(); new.status := 'visible';
  select * into p from public.posts where id = new.post_id;
  if p.status <> 'visible' then perform public.fail('forbidden', 'Cette discussion est fermée'); end if;
  return new;
end $$;
create trigger reply_before before insert on public.replies for each row execute function public.reply_before();

create or replace function public.reply_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare p public.posts; who text;
begin
  select * into p from public.posts where id = new.post_id;
  if p.author_id is not null and p.author_id <> new.author_id then
    select full_name into who from public.profiles where id = new.author_id;
    perform public.notify('user', null, p.author_id, 'community', 'Nouvelle réponse',
      who || ' a répondu à « ' || left(p.title, 60) || ' »', 'post:' || p.id, false);
  end if;
  return new;
end $$;
create trigger reply_after after insert on public.replies for each row execute function public.reply_after();

create or replace function public.report_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.enforce_rate('reports', 'reporter_id', interval '1 day', 20, 'signalements');
  new.reporter_id := auth.uid(); new.status := 'open'; new.handled_by := null; new.handled_at := null;
  return new;
end $$;
create trigger report_before before insert on public.reports for each row execute function public.report_before();

-- 3 signalements ouverts → contenu masqué automatiquement en attendant la modération
create or replace function public.report_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int; a uuid;
begin
  select count(*) into n from public.reports where target_kind = new.target_kind and target_id = new.target_id and status = 'open';
  if n >= 3 then
    if new.target_kind = 'post' then update public.posts set status = 'hidden' where id = new.target_id and status = 'visible';
    elsif new.target_kind = 'reply' then update public.replies set status = 'hidden' where id = new.target_id and status = 'visible';
    elsif new.target_kind = 'ride' then update public.rides set status = 'hidden' where id = new.target_id and status = 'visible';
    elsif new.target_kind = 'study_group' then update public.study_groups set status = 'hidden' where id = new.target_id and status = 'visible';
    end if;
  end if;
  if n = 1 or n = 3 then
    for a in select id from public.profiles where role = 'admin' and status = 'active' loop
      perform public.notify('user', null, a, 'community', 'Contenu signalé',
        case when n >= 3 then 'Masqué automatiquement après 3 signalements. À vérifier.' else 'Un nouveau signalement est à traiter.' end, 'moderation', n >= 3);
    end loop;
  end if;
  return new;
end $$;
create trigger report_after after insert on public.reports for each row execute function public.report_after();

create or replace function public.moderate(p_kind text, p_id uuid, p_action text, p_reason text default null) returns void
language plpgsql security definer set search_path = public as $$
declare v_status text; v_group uuid;
begin
  if p_action not in ('hide', 'restore', 'remove', 'dismiss') then perform public.fail('invalid', 'Action invalide'); end if;
  if p_kind = 'post' then select group_id into v_group from public.posts where id = p_id;
  elsif p_kind = 'reply' then select p.group_id into v_group from public.replies r join public.posts p on p.id = r.post_id where r.id = p_id;
  end if;
  if not (public.is_admin() or (p_kind in ('post', 'reply') and public.teaches_group(v_group))) then
    perform public.fail('forbidden', 'Modération réservée à l''administration et aux formateurs du groupe');
  end if;
  if p_action <> 'dismiss' then
    v_status := case p_action when 'hide' then 'hidden' when 'remove' then 'removed' else 'visible' end;
    if p_kind = 'post' then update public.posts set status = v_status where id = p_id;
    elsif p_kind = 'reply' then update public.replies set status = v_status where id = p_id;
    elsif p_kind = 'ride' then update public.rides set status = v_status where id = p_id;
    elsif p_kind = 'study_group' then update public.study_groups set status = v_status where id = p_id;
    else perform public.fail('invalid', 'Type invalide'); end if;
  end if;
  update public.reports set status = case when p_action in ('dismiss', 'restore') then 'dismissed' else 'actioned' end,
         handled_by = auth.uid(), handled_at = now()
   where target_kind = p_kind and target_id = p_id and status = 'open';
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'moderate:' || p_action, p_kind, p_id::text, jsonb_build_object('reason', left(p_reason, 200)));
end $$;

create or replace function public.mute_user(p_user uuid, p_days int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  if p_days < 0 or p_days > 365 then perform public.fail('invalid', 'Durée invalide'); end if;
  update public.profiles set muted_until = case when p_days = 0 then null else now() + make_interval(days => p_days) end where id = p_user;
  if p_days > 0 then
    perform public.notify('user', null, p_user, 'system', 'Accès communauté limité',
      'Suite à un signalement, vous ne pouvez plus publier pendant ' || p_days || ' jour(s).', 'help', true);
  end if;
end $$;

-- ---------------------------------------------------------------------
-- 10. Groupes de révision et covoiturage : capacité, anti-spam, notifications
-- ---------------------------------------------------------------------
create or replace function public.study_group_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.enforce_rate('study_groups', 'created_by', interval '1 day', 5, 'groupes créés');
  new.created_by := auth.uid(); new.status := 'visible';
  if new.meet_date < public.local_today() then perform public.fail('invalid_date', 'La date est déjà passée'); end if;
  return new;
end $$;
create trigger study_group_before before insert on public.study_groups for each row execute function public.study_group_before();

create or replace function public.study_member_before() returns trigger
language plpgsql security definer set search_path = public as $$
declare g public.study_groups; n int; who text;
begin
  new.user_id := auth.uid();
  select * into g from public.study_groups where id = new.study_group_id for update;
  if g.status <> 'visible' then perform public.fail('forbidden', 'Groupe indisponible'); end if;
  select count(*) into n from public.study_group_members where study_group_id = new.study_group_id;
  if n >= g.capacity then perform public.fail('full', 'Groupe complet'); end if;
  if g.created_by is distinct from new.user_id then
    select full_name into who from public.profiles where id = new.user_id;
    perform public.notify('user', null, g.created_by, 'community', 'Nouveau membre', who || ' a rejoint « ' || g.subject || ' »', 'help', false);
  end if;
  return new;
end $$;
create trigger study_member_before before insert on public.study_group_members for each row execute function public.study_member_before();

create or replace function public.ride_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.enforce_rate('rides', 'author_id', interval '1 day', 5, 'trajets publiés');
  new.author_id := auth.uid(); new.status := 'visible';
  return new;
end $$;
create trigger ride_before before insert on public.rides for each row execute function public.ride_before();

create or replace function public.ride_booking_before() returns trigger
language plpgsql security definer set search_path = public as $$
declare r public.rides; n int; who text;
begin
  new.user_id := auth.uid();
  select * into r from public.rides where id = new.ride_id for update;
  if r.status <> 'visible' then perform public.fail('forbidden', 'Trajet indisponible'); end if;
  if r.author_id = new.user_id then perform public.fail('invalid', 'Vous ne pouvez pas réserver votre propre trajet'); end if;
  if r.kind = 'offer' then
    select count(*) into n from public.ride_bookings where ride_id = new.ride_id;
    if n >= r.seats then perform public.fail('full', 'Trajet complet'); end if;
  end if;
  select full_name into who from public.profiles where id = new.user_id;
  perform public.notify('user', null, r.author_id, 'community',
    case when r.kind = 'offer' then 'Nouvelle réservation' else 'Proposition de trajet' end,
    who || case when r.kind = 'offer' then ' a réservé une place' else ' peut vous emmener' end || ' (' || r.from_place || ', ' || to_char(r.depart_at, 'HH24:MI') || ')', 'moves', false);
  return new;
end $$;
create trigger ride_booking_before before insert on public.ride_bookings for each row execute function public.ride_booking_before();

create or replace function public.resource_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.created_by := auth.uid();
  return new;
end $$;
create trigger resource_before before insert on public.resources for each row execute function public.resource_before();

-- ---------------------------------------------------------------------
-- 11. Administration : rôles, comptes, codes d'accès
-- ---------------------------------------------------------------------
create or replace function public.admin_set_role(p_user uuid, p_role public.app_role, p_group uuid default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  if p_user = auth.uid() then perform public.fail('forbidden', 'Vous ne pouvez pas modifier votre propre rôle'); end if;
  if p_role = 'student' and p_group is null then perform public.fail('invalid', 'Un stagiaire doit appartenir à un groupe'); end if;
  update public.profiles set role = p_role, group_id = case when p_role = 'student' then p_group else null end where id = p_user;
  if not found then perform public.fail('not_found', 'Compte introuvable'); end if;
  if p_role <> 'teacher' then delete from public.teaching_assignments where teacher_id = p_user; end if;
end $$;

-- Suspendre / réactiver un compte (les droits de colonnes empêchent toute modification directe du statut)
create or replace function public.admin_set_status(p_user uuid, p_status text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  if p_user = auth.uid() then perform public.fail('forbidden', 'Vous ne pouvez pas suspendre votre propre compte'); end if;
  if p_status not in ('active', 'suspended') then perform public.fail('invalid', 'Statut invalide'); end if;
  update public.profiles set status = p_status where id = p_user;
  if not found then perform public.fail('not_found', 'Compte introuvable'); end if;
end $$;

create or replace function public.admin_delete_user(p_user uuid) returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  if p_user = auth.uid() then perform public.fail('forbidden', 'Impossible de supprimer votre propre compte'); end if;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  select auth.uid(), 'delete', 'account', p_user::text, jsonb_build_object('email', email, 'role', role) from public.profiles where id = p_user;
  delete from auth.users where id = p_user;
end $$;

create or replace function public.admin_group_codes() returns table (id uuid, code text, label text, join_code text, students bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  return query select g.id, g.code, g.label, g.join_code,
    (select count(*) from public.profiles p where p.group_id = g.id and p.role = 'student') from public.groups g order by g.code;
end $$;

create or replace function public.regenerate_join_code(p_group uuid) returns text
language plpgsql security definer set search_path = public as $$
declare c text := upper(substr(md5(gen_random_uuid()::text), 1, 6));
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  update public.groups set join_code = c where id = p_group;
  return c;
end $$;

-- Import de la liste des stagiaires (CSV) : contrôle et rapport ligne par ligne, rien n'est écrit en cas d'erreur
-- p_rows = [{"email": "...", "full_name": "...", "group_code": "ID101", "role": "student"}]
create or replace function public.import_roster(p_rows jsonb, p_dry_run boolean default true) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r jsonb; i int := 0; v_errors jsonb := '[]'::jsonb; v_ok int := 0; v_dup int := 0; g uuid; v_email text; v_role text; seen text[] := '{}';
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) > 2000 then perform public.fail('invalid', 'Fichier trop grand (2000 lignes max.)'); end if;
  for r in select * from jsonb_array_elements(p_rows) loop
    i := i + 1;
    v_email := lower(trim(r->>'email'));
    v_role := coalesce(nullif(lower(trim(r->>'role')), ''), 'student');
    if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then v_errors := v_errors || jsonb_build_object('line', i, 'error', 'E-mail invalide'); continue; end if;
    if v_email = any(seen) then v_errors := v_errors || jsonb_build_object('line', i, 'error', 'E-mail en double dans le fichier'); continue; end if;
    seen := seen || v_email;
    if v_role not in ('student', 'teacher') then v_errors := v_errors || jsonb_build_object('line', i, 'error', 'Rôle invalide (student ou teacher)'); continue; end if;
    g := null;
    if v_role = 'student' then
      select id into g from public.groups where code = upper(trim(r->>'group_code'));
      if g is null then v_errors := v_errors || jsonb_build_object('line', i, 'error', 'Groupe inconnu : ' || coalesce(r->>'group_code', '')); continue; end if;
    end if;
    if exists (select 1 from public.roster where email = v_email) or exists (select 1 from public.profiles where email = v_email) then
      v_dup := v_dup + 1; continue;
    end if;
    if not p_dry_run then
      insert into public.roster (email, full_name, role, group_id, created_by)
      values (v_email, nullif(left(trim(r->>'full_name'), 80), ''), v_role::public.app_role, g, auth.uid());
    end if;
    v_ok := v_ok + 1;
  end loop;
  if not p_dry_run and jsonb_array_length(v_errors) > 0 then
    perform public.fail('invalid', 'Corrigez les erreurs avant d''importer');
  end if;
  return jsonb_build_object('valid', v_ok, 'duplicates', v_dup, 'errors', v_errors, 'imported', case when p_dry_run then 0 else v_ok end);
end $$;

-- ---------------------------------------------------------------------
-- 12. Statistiques d'assiduité (vue soumise aux règles RLS de l'utilisateur)
-- ---------------------------------------------------------------------
create or replace view public.attendance_summary with (security_invoker = true) as
  select a.student_id,
         count(*)::int as total,
         count(*) filter (where a.status = 'present')::int as present,
         count(*) filter (where a.status = 'absent')::int as absent,
         count(*) filter (where a.status = 'late')::int as late,
         count(*) filter (where a.status = 'excused')::int as excused,
         round(100.0 * count(*) filter (where a.status in ('present', 'late', 'excused')) / nullif(count(*), 0), 1) as rate
  from public.attendance_records a
  join public.class_sessions s on s.id = a.session_id and s.status = 'held'
  group by a.student_id;

-- Annuaire : noms et rôles uniquement (jamais l'e-mail ni le téléphone)
create or replace view public.people as
  select id, full_name, role, group_id from public.profiles where status = 'active';

-- Fil de la communauté : l'auteur d'une question anonyme est masqué (sauf pour lui-même et l'administration)
create or replace view public.posts_feed as
  select p.id, p.kind, p.group_id, p.module_id,
         case when p.anonymous and p.author_id is distinct from auth.uid() and not public.is_admin() then null else p.author_id end as author_id,
         p.anonymous, p.title, p.body, p.status, p.resolved, p.best_reply_id, p.created_at,
         (select count(*) from public.post_votes v where v.post_id = p.id)::int as votes,
         exists (select 1 from public.post_votes v where v.post_id = p.id and v.user_id = auth.uid()) as voted
  from public.posts p
  where (p.group_id = public.my_group() or p.author_id = auth.uid() or public.teaches_group(p.group_id) or public.is_admin())
    and (p.status = 'visible' or p.author_id = auth.uid() or public.is_admin() or public.teaches_group(p.group_id));
