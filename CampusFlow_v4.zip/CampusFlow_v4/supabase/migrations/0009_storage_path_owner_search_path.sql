-- Avertissement du linter Supabase : chemin de recherche figé pour storage_path_owner
alter function public.storage_path_owner(text) set search_path = '';
