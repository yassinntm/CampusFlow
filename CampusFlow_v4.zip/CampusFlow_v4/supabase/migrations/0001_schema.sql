-- =====================================================================
--  CampusFlow v3 · 0001 · Schéma
--  Ordre d'exécution : 0001_schema → 0002_functions → 0003_security → 0004_reference_data
-- =====================================================================
create extension if not exists btree_gist;   -- détection des conflits d'horaires (contraintes d'exclusion)

-- ---------------------------------------------------------------------
-- Rôles et structure de l'établissement
-- ---------------------------------------------------------------------
do $$ begin
  create type public.app_role as enum ('student', 'teacher', 'admin');
exception when duplicate_object then null; end $$;

create table public.groups (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique check (code ~ '^[A-Z0-9_-]{2,20}$'),
  label       text check (char_length(label) <= 80),
  filiere     text check (char_length(filiere) <= 80),
  year        smallint check (year between 1 and 6),
  join_code   text not null unique default upper(substr(md5(gen_random_uuid()::text), 1, 6)),
  created_at  timestamptz not null default now()
);

create table public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  full_name    text not null check (char_length(full_name) between 2 and 80),
  email        text not null,
  role         public.app_role not null default 'student',
  group_id     uuid references public.groups(id) on delete set null,
  phone        text check (phone is null or phone ~ '^\+?[0-9 ]{9,16}$'),
  status       text not null default 'active' check (status in ('active', 'suspended')),
  muted_until  timestamptz,                                  -- sanction communauté
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index profiles_group_idx on public.profiles(group_id) where role = 'student';
create index profiles_role_idx on public.profiles(role);

-- Pré-inscriptions : l'admin importe les e-mails (CSV). À l'inscription, le rôle et le groupe viennent d'ici,
-- jamais de ce que l'utilisateur envoie.
create table public.roster (
  email       text primary key check (email = lower(email) and email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  full_name   text check (char_length(full_name) <= 80),
  role        public.app_role not null default 'student',
  group_id    uuid references public.groups(id) on delete cascade,
  created_by  uuid references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now(),
  check (role <> 'student' or group_id is not null)
);

create table public.modules (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique check (code ~ '^[A-Z0-9_.-]{2,20}$'),
  name        text not null check (char_length(name) between 2 and 100),
  created_at  timestamptz not null default now()
);

create table public.rooms (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique check (char_length(name) between 1 and 40),
  kind        text not null default 'salle' check (kind in ('salle', 'labo', 'amphi', 'atelier', 'autre')),
  capacity    smallint check (capacity between 1 and 1000),
  created_at  timestamptz not null default now()
);

-- Qui enseigne quel module à quel groupe (base des droits des formateurs)
create table public.teaching_assignments (
  group_id    uuid not null references public.groups(id) on delete cascade,
  module_id   uuid not null references public.modules(id) on delete cascade,
  teacher_id  uuid not null references public.profiles(id) on delete cascade,
  primary key (group_id, module_id, teacher_id)
);
create index teaching_teacher_idx on public.teaching_assignments(teacher_id);

-- ---------------------------------------------------------------------
-- Emploi du temps : créneaux hebdomadaires publiés, brouillons, versions
-- ---------------------------------------------------------------------
create table public.timetable_slots (
  id          uuid primary key default gen_random_uuid(),
  group_id    uuid not null references public.groups(id) on delete cascade,
  module_id   uuid not null references public.modules(id) on delete restrict,
  teacher_id  uuid references public.profiles(id) on delete set null,
  room_id     uuid references public.rooms(id) on delete set null,
  weekday     smallint not null check (weekday between 1 and 6),        -- 1 = lundi … 6 = samedi
  start_time  time not null,
  end_time    time not null,
  start_min   smallint generated always as ((extract(hour from start_time) * 60 + extract(minute from start_time))::smallint) stored,
  end_min     smallint generated always as ((extract(hour from end_time) * 60 + extract(minute from end_time))::smallint) stored,
  kind        text not null default 'cours' check (kind in ('cours', 'tp', 'td', 'exam', 'autre')),
  status      text not null default 'active' check (status in ('active', 'cancelled')),
  note        text check (char_length(note) <= 200),
  updated_at  timestamptz not null default now(),
  check (end_time > start_time and start_time >= '07:00' and end_time <= '22:00'),
  -- La base refuse deux cours actifs en même temps pour un même groupe, formateur ou salle.
  constraint no_group_overlap   exclude using gist (group_id with =, weekday with =, int4range(start_min, end_min) with &&) where (status = 'active') deferrable initially deferred,
  constraint no_teacher_overlap exclude using gist (teacher_id with =, weekday with =, int4range(start_min, end_min) with &&) where (status = 'active' and teacher_id is not null) deferrable initially deferred,
  constraint no_room_overlap    exclude using gist (room_id with =, weekday with =, int4range(start_min, end_min) with &&) where (status = 'active' and room_id is not null) deferrable initially deferred
);
create index slots_group_idx on public.timetable_slots(group_id, weekday);
create index slots_teacher_idx on public.timetable_slots(teacher_id, weekday);

create table public.timetable_drafts (
  id              uuid primary key default gen_random_uuid(),
  group_id        uuid not null references public.groups(id) on delete cascade,
  source_slot_id  uuid,                         -- créneau publié d'origine (null = nouveau créneau)
  module_id       uuid not null references public.modules(id) on delete cascade,
  teacher_id      uuid references public.profiles(id) on delete set null,
  room_id         uuid references public.rooms(id) on delete set null,
  weekday         smallint not null check (weekday between 1 and 6),
  start_time      time not null,
  end_time        time not null,
  kind            text not null default 'cours' check (kind in ('cours', 'tp', 'td', 'exam', 'autre')),
  status          text not null default 'active' check (status in ('active', 'cancelled')),
  note            text check (char_length(note) <= 200),
  updated_at      timestamptz not null default now(),
  check (end_time > start_time and start_time >= '07:00' and end_time <= '22:00')
);
create index drafts_group_idx on public.timetable_drafts(group_id);

create table public.timetable_versions (
  id            uuid primary key default gen_random_uuid(),
  group_id      uuid not null references public.groups(id) on delete cascade,
  version       int not null,
  published_by  uuid references public.profiles(id) on delete set null,
  published_at  timestamptz not null default now(),
  changes       jsonb not null default '[]'::jsonb,   -- [{type, text}]
  snapshot      jsonb not null default '[]'::jsonb,   -- créneaux publiés à cette version
  unique (group_id, version)
);

-- ---------------------------------------------------------------------
-- Séances datées et assiduité
-- ---------------------------------------------------------------------
create table public.class_sessions (
  id            uuid primary key default gen_random_uuid(),
  slot_id       uuid references public.timetable_slots(id) on delete set null,
  group_id      uuid not null references public.groups(id) on delete cascade,
  module_id     uuid not null references public.modules(id) on delete restrict,
  teacher_id    uuid references public.profiles(id) on delete set null,
  room_id       uuid references public.rooms(id) on delete set null,
  session_date  date not null,
  start_time    time not null,
  end_time      time not null,
  status        text not null default 'held' check (status in ('held', 'cancelled')),
  created_by    uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  unique (slot_id, session_date)
);
create index sessions_group_date_idx on public.class_sessions(group_id, session_date);
create index sessions_teacher_date_idx on public.class_sessions(teacher_id, session_date);

create table public.attendance_records (
  session_id    uuid not null references public.class_sessions(id) on delete cascade,
  student_id    uuid not null references public.profiles(id) on delete cascade,
  status        text not null check (status in ('present', 'absent', 'late', 'excused')),
  minutes_late  smallint check (minutes_late between 1 and 240),
  note          text check (char_length(note) <= 200),
  recorded_by   uuid references public.profiles(id) on delete set null,
  recorded_at   timestamptz not null default now(),
  primary key (session_id, student_id),
  check (status = 'late' or minutes_late is null)
);
create index attendance_student_idx on public.attendance_records(student_id);

create table public.absence_justifications (
  session_id   uuid not null,
  student_id   uuid not null,
  reason       text not null check (char_length(reason) between 5 and 500),
  status       text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
  reviewed_by  uuid references public.profiles(id) on delete set null,
  reviewed_at  timestamptz,
  created_at   timestamptz not null default now(),
  primary key (session_id, student_id),
  foreign key (session_id, student_id) references public.attendance_records(session_id, student_id) on delete cascade
);

-- ---------------------------------------------------------------------
-- Devoirs, examens, tâches et révisions
-- ---------------------------------------------------------------------
create table public.assessments (
  id            uuid primary key default gen_random_uuid(),
  kind          text not null check (kind in ('assignment', 'exam')),
  group_id      uuid references public.groups(id) on delete cascade,      -- null = tous les groupes
  module_id     uuid references public.modules(id) on delete set null,
  title         text not null check (char_length(title) between 2 and 140),
  description   text check (char_length(description) <= 2000),
  due_at        timestamptz not null,                                     -- date limite ou début de l'examen
  duration_min  smallint check (duration_min between 10 and 600),
  room_id       uuid references public.rooms(id) on delete set null,
  priority      text not null default 'normal' check (priority in ('low', 'normal', 'high')),
  created_by    uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index assessments_group_due_idx on public.assessments(group_id, due_at);

create table public.assessment_progress (
  assessment_id  uuid not null references public.assessments(id) on delete cascade,
  student_id     uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  status         text not null default 'todo' check (status in ('todo', 'in_progress', 'done')),
  updated_at     timestamptz not null default now(),
  primary key (assessment_id, student_id)
);

create table public.tasks (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  title       text not null check (char_length(title) between 1 and 140),
  due_date    date,
  priority    text not null default 'normal' check (priority in ('low', 'normal', 'high')),
  module_id   uuid references public.modules(id) on delete set null,
  done        boolean not null default false,
  done_at     timestamptz,
  created_at  timestamptz not null default now()
);
create index tasks_owner_idx on public.tasks(owner_id, done);

create table public.study_sessions (
  id              uuid primary key default gen_random_uuid(),
  owner_id        uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  module_id       uuid references public.modules(id) on delete set null,
  subject         text check (char_length(subject) <= 100),
  planned_date    date not null,
  start_time      time,
  duration_min    smallint not null check (duration_min between 10 and 600),
  done            boolean not null default false,
  study_group_id  uuid,                       -- séance liée à un groupe de révision
  created_at      timestamptz not null default now()
);
create index study_owner_idx on public.study_sessions(owner_id, planned_date);

create table public.user_settings (
  user_id     uuid primary key references public.profiles(id) on delete cascade default auth.uid(),
  data        jsonb not null default '{}'::jsonb check (pg_column_size(data) < 8000),   -- langue, thème, trajet, objectifs…
  updated_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- Annonces et notifications
-- ---------------------------------------------------------------------
create table public.announcements (
  id          uuid primary key default gen_random_uuid(),
  scope       text not null check (scope in ('all', 'group', 'module')),
  group_id    uuid references public.groups(id) on delete cascade,
  module_id   uuid references public.modules(id) on delete cascade,
  title       text not null check (char_length(title) between 2 and 140),
  body        text not null check (char_length(body) between 2 and 3000),
  pinned      boolean not null default false,
  important   boolean not null default false,
  author_id   uuid references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  check ((scope = 'all' and group_id is null) or (scope = 'group' and group_id is not null) or (scope = 'module' and group_id is not null and module_id is not null))
);

create table public.notifications (
  id           uuid primary key default gen_random_uuid(),
  target_kind  text not null check (target_kind in ('all', 'group', 'user')),
  group_id     uuid references public.groups(id) on delete cascade,
  user_id      uuid references public.profiles(id) on delete cascade,
  kind         text not null check (kind in ('timetable', 'room', 'cancel', 'assignment', 'exam', 'announcement', 'attendance', 'community', 'reminder', 'system')),
  title        text not null check (char_length(title) between 1 and 160),
  body         text not null default '' check (char_length(body) <= 600),
  link         text check (link is null or link ~ '^[a-z-]+(:[A-Za-z0-9-]+)?$'),     -- route interne (ex. « schedule », « post:<id> »)
  important    boolean not null default false,
  created_at   timestamptz not null default now(),
  check ((target_kind = 'all') or (target_kind = 'group' and group_id is not null) or (target_kind = 'user' and user_id is not null))
);
create index notifications_group_idx on public.notifications(group_id, created_at desc);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

create table public.notification_reads (
  notification_id  uuid not null references public.notifications(id) on delete cascade,
  user_id          uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  read_at          timestamptz not null default now(),
  primary key (notification_id, user_id)
);

-- ---------------------------------------------------------------------
-- Communauté : questions/discussions, réponses, votes, signalements
-- ---------------------------------------------------------------------
create table public.posts (
  id             uuid primary key default gen_random_uuid(),
  kind           text not null default 'question' check (kind in ('question', 'discussion')),
  group_id       uuid not null references public.groups(id) on delete cascade,
  module_id      uuid references public.modules(id) on delete set null,
  author_id      uuid references public.profiles(id) on delete set null default auth.uid(),
  anonymous      boolean not null default false,
  title          text not null check (char_length(title) between 5 and 140),
  body           text not null check (char_length(body) between 10 and 3000),
  status         text not null default 'visible' check (status in ('visible', 'hidden', 'removed')),
  resolved       boolean not null default false,
  best_reply_id  uuid,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index posts_group_idx on public.posts(group_id, created_at desc);

create table public.replies (
  id          uuid primary key default gen_random_uuid(),
  post_id     uuid not null references public.posts(id) on delete cascade,
  author_id   uuid references public.profiles(id) on delete set null default auth.uid(),
  body        text not null check (char_length(body) between 2 and 2000),
  status      text not null default 'visible' check (status in ('visible', 'hidden', 'removed')),
  created_at  timestamptz not null default now()
);
create index replies_post_idx on public.replies(post_id, created_at);
alter table public.posts add constraint posts_best_reply_fk foreign key (best_reply_id) references public.replies(id) on delete set null;

create table public.post_votes (
  post_id     uuid not null references public.posts(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  created_at  timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table public.reports (
  id           uuid primary key default gen_random_uuid(),
  target_kind  text not null check (target_kind in ('post', 'reply', 'ride', 'study_group')),
  target_id    uuid not null,
  reporter_id  uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  reason       text not null check (reason in ('spam', 'harassment', 'inappropriate', 'off_topic', 'cheating', 'other')),
  details      text check (char_length(details) <= 500),
  status       text not null default 'open' check (status in ('open', 'dismissed', 'actioned')),
  handled_by   uuid references public.profiles(id) on delete set null,
  handled_at   timestamptz,
  created_at   timestamptz not null default now(),
  unique (target_kind, target_id, reporter_id)
);
create index reports_open_idx on public.reports(status, created_at);

-- ---------------------------------------------------------------------
-- Groupes de révision et covoiturage
-- ---------------------------------------------------------------------
create table public.study_groups (
  id          uuid primary key default gen_random_uuid(),
  module_id   uuid references public.modules(id) on delete set null,
  subject     text not null check (char_length(subject) between 2 and 100),
  meet_date   date not null,
  start_time  time not null,
  end_time    time not null,
  place       text not null check (char_length(place) between 1 and 60),
  capacity    smallint not null check (capacity between 2 and 30),
  created_by  uuid references public.profiles(id) on delete cascade default auth.uid(),
  status      text not null default 'visible' check (status in ('visible', 'hidden', 'removed')),
  created_at  timestamptz not null default now(),
  check (end_time > start_time)
);

create table public.study_group_members (
  study_group_id  uuid not null references public.study_groups(id) on delete cascade,
  user_id         uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  joined_at       timestamptz not null default now(),
  primary key (study_group_id, user_id)
);
alter table public.study_sessions add constraint study_sessions_group_fk foreign key (study_group_id) references public.study_groups(id) on delete cascade;

create table public.rides (
  id          uuid primary key default gen_random_uuid(),
  kind        text not null check (kind in ('offer', 'request')),
  author_id   uuid references public.profiles(id) on delete cascade default auth.uid(),
  from_place  text not null check (char_length(from_place) between 2 and 60),
  depart_at   time not null,
  days        smallint[] not null default '{1,2,3,4,5}' check (days <@ '{1,2,3,4,5,6}'::smallint[] and cardinality(days) between 1 and 6),
  seats       smallint not null default 1 check (seats between 1 and 8),
  note        text check (char_length(note) <= 200),
  status      text not null default 'visible' check (status in ('visible', 'hidden', 'removed')),
  created_at  timestamptz not null default now()
);

create table public.ride_bookings (
  ride_id     uuid not null references public.rides(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  created_at  timestamptz not null default now(),
  primary key (ride_id, user_id)
);

-- ---------------------------------------------------------------------
-- Ressources pédagogiques (liens ou fichiers du bucket Storage « resources »)
-- ---------------------------------------------------------------------
create table public.resources (
  id            uuid primary key default gen_random_uuid(),
  module_id     uuid not null references public.modules(id) on delete cascade,
  group_id      uuid references public.groups(id) on delete cascade,          -- null = tous les groupes du module
  title         text not null check (char_length(title) between 2 and 140),
  description   text check (char_length(description) <= 500),
  kind          text not null check (kind in ('link', 'file')),
  url           text check (url is null or url ~ '^https://'),
  storage_path  text,
  size_bytes    int check (size_bytes between 1 and 26214400),               -- 25 Mo
  mime          text,
  created_by    uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at    timestamptz not null default now(),
  check ((kind = 'link' and url is not null and storage_path is null) or (kind = 'file' and storage_path is not null))
);

-- ---------------------------------------------------------------------
-- Journal d'audit (écrit uniquement par des triggers et fonctions serveur)
-- ---------------------------------------------------------------------
create table public.audit_log (
  id         bigint generated always as identity primary key,
  at         timestamptz not null default now(),
  actor_id   uuid,
  action     text not null,
  entity     text not null,
  entity_id  text,
  details    jsonb not null default '{}'::jsonb
);
create index audit_at_idx on public.audit_log(at desc);

-- Quotas de l'assistant IA (écrit par l'Edge Function avec la clé serveur)
create table public.ai_usage (
  user_id   uuid not null references public.profiles(id) on delete cascade,
  day       date not null default current_date,
  requests  int not null default 0,
  primary key (user_id, day)
);
