-- =====================================================================
--  CampusFlow v3 — 0008 : plateforme double (application Stagiaire + application Administration)
--  Ajoute : surveillant général, annulations ponctuelles de séances, annonces brouillon/programmées/ciblées,
--  rendus de devoirs + retours du formateur + pièces jointes, calendrier académique, confidentialité et contacts
--  de covoiturage, restauration d'une version d'emploi du temps, notification des formateurs, statistiques.
--  Migration additive : aucune donnée existante n'est supprimée.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Rôles : « personnel » = administration + surveillance
-- ---------------------------------------------------------------------
create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() in ('admin', 'supervisor'), false)
$$;
create or replace function public.can_see_group(g uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select g = public.my_group() or public.teaches_group(g) or public.is_staff()
$$;
-- Profil de l'utilisateur connecté (utilisé par l'interface pour choisir l'application)
create or replace function public.my_access() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('role', role, 'status', status, 'staff', role in ('admin', 'supervisor'), 'admin', role = 'admin')
  from public.profiles where id = auth.uid()
$$;

-- ---------------------------------------------------------------------
-- 2. Annulations / déplacements ponctuels d'une séance (sans toucher à l'emploi du temps hebdomadaire)
-- ---------------------------------------------------------------------
create table public.session_exceptions (
  id           uuid primary key default gen_random_uuid(),
  slot_id      uuid not null references public.timetable_slots(id) on delete cascade,
  group_id     uuid not null references public.groups(id) on delete cascade,
  session_date date not null,
  kind         text not null check (kind in ('cancelled', 'moved')),
  room_id      uuid references public.rooms(id) on delete set null,
  start_time   time,
  end_time     time,
  note         text check (char_length(note) <= 200),
  created_by   uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at   timestamptz not null default now(),
  unique (slot_id, session_date),
  check (kind = 'cancelled' or room_id is not null or (start_time is not null and end_time is not null and end_time > start_time))
);
create index session_exceptions_group_idx on public.session_exceptions(group_id, session_date);

create or replace function public.set_session_exception(p_slot uuid, p_date date, p_kind text, p_room uuid default null,
  p_start time default null, p_end time default null, p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare s public.timetable_slots; v_id uuid; v_txt text; v_start time; v_end time;
begin
  if not public.is_staff() then perform public.fail('forbidden', 'Réservé à l''administration et à la surveillance'); end if;
  select * into s from public.timetable_slots where id = p_slot;
  if not found then perform public.fail('not_found', 'Créneau introuvable'); end if;
  if extract(isodow from p_date) <> s.weekday then perform public.fail('invalid_date', 'Cette date ne correspond pas au jour du cours'); end if;
  if p_date < public.local_today() then perform public.fail('invalid_date', 'Impossible de modifier une séance passée'); end if;
  if p_kind not in ('cancelled', 'moved') then perform public.fail('invalid', 'Type invalide'); end if;
  v_start := coalesce(p_start, s.start_time); v_end := coalesce(p_end, s.end_time);
  if p_kind = 'moved' then
    if v_end <= v_start then perform public.fail('invalid', 'L''heure de fin doit être après l''heure de début'); end if;
    -- salle déjà occupée ce jour-là (créneau hebdomadaire actif non annulé ce jour, ou autre séance déplacée)
    if p_room is not null and (exists (
        select 1 from public.timetable_slots o where o.room_id = p_room and o.weekday = s.weekday and o.id <> s.id and o.status = 'active'
          and o.start_time < v_end and v_start < o.end_time
          and not exists (select 1 from public.session_exceptions e where e.slot_id = o.id and e.session_date = p_date))
      or exists (select 1 from public.session_exceptions e where e.session_date = p_date and e.kind = 'moved' and e.room_id = p_room
          and e.slot_id <> s.id and e.start_time < v_end and v_start < e.end_time)) then
      perform public.fail('conflicts', 'Salle déjà occupée sur ce créneau');
    end if;
  end if;
  insert into public.session_exceptions (slot_id, group_id, session_date, kind, room_id, start_time, end_time, note)
  values (s.id, s.group_id, p_date, p_kind, case when p_kind = 'moved' then coalesce(p_room, s.room_id) end,
          case when p_kind = 'moved' then v_start end, case when p_kind = 'moved' then v_end end, nullif(left(p_note, 200), ''))
  on conflict (slot_id, session_date) do update set kind = excluded.kind, room_id = excluded.room_id, start_time = excluded.start_time,
     end_time = excluded.end_time, note = excluded.note, created_by = auth.uid(), created_at = now()
  returning id into v_id;
  v_txt := public.module_name(s.module_id) || ' · ' || to_char(p_date, 'DD/MM') || ' ' || to_char(s.start_time, 'HH24:MI')
           || case when p_kind = 'cancelled' then ' : séance annulée'
                   else ' : ' || coalesce((select name from public.rooms where id = coalesce(p_room, s.room_id)), '') || ' ' || to_char(v_start, 'HH24:MI') || '–' || to_char(v_end, 'HH24:MI') end
           || coalesce(' (' || nullif(p_note, '') || ')', '');
  perform public.notify('group', s.group_id, null, case when p_kind = 'cancelled' then 'cancel' else 'room' end,
    case when p_kind = 'cancelled' then 'Séance annulée' else 'Séance déplacée' end, v_txt, 'schedule', true);
  if s.teacher_id is not null then
    perform public.notify('user', null, s.teacher_id, case when p_kind = 'cancelled' then 'cancel' else 'room' end,
      case when p_kind = 'cancelled' then 'Séance annulée' else 'Séance déplacée' end, v_txt || ' · ' || public.group_code(s.group_id), 'schedule', true);
  end if;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'session_' || p_kind, 'timetable_slots', s.id::text, jsonb_build_object('date', p_date, 'note', p_note, 'room', p_room));
  return v_id;
end $$;

create or replace function public.clear_session_exception(p_slot uuid, p_date date) returns void
language plpgsql security definer set search_path = public as $$
declare s public.timetable_slots;
begin
  if not public.is_staff() then perform public.fail('forbidden', 'Réservé à l''administration et à la surveillance'); end if;
  delete from public.session_exceptions where slot_id = p_slot and session_date = p_date;
  if not found then perform public.fail('not_found', 'Aucune modification pour cette séance'); end if;
  select * into s from public.timetable_slots where id = p_slot;
  perform public.notify('group', s.group_id, null, 'timetable', 'Séance rétablie',
    public.module_name(s.module_id) || ' · ' || to_char(p_date, 'DD/MM') || ' ' || to_char(s.start_time, 'HH24:MI') || ' : horaire habituel.', 'schedule', false);
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'session_restore', 'timetable_slots', p_slot::text, jsonb_build_object('date', p_date));
end $$;

create or replace function public.group_code(g uuid) returns text
language sql stable security definer set search_path = public as $$ select coalesce((select code from public.groups where id = g), '') $$;

-- ---------------------------------------------------------------------
-- 3. Versions d'emploi du temps : instantané avec identifiants, notification des formateurs, restauration
-- ---------------------------------------------------------------------
create or replace function public.version_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.snapshot := coalesce((select jsonb_agg(jsonb_build_object(
      'module_id', s.module_id, 'teacher_id', s.teacher_id, 'room_id', s.room_id,
      'module', m.name, 'teacher', p.full_name, 'room', r.name, 'weekday', s.weekday,
      'start', to_char(s.start_time, 'HH24:MI'), 'end', to_char(s.end_time, 'HH24:MI'), 'kind', s.kind, 'status', s.status, 'note', s.note)
      order by s.weekday, s.start_time)
    from public.timetable_slots s join public.modules m on m.id = s.module_id
    left join public.profiles p on p.id = s.teacher_id left join public.rooms r on r.id = s.room_id
    where s.group_id = new.group_id), '[]'::jsonb);
  return new;
end $$;
create trigger version_before before insert on public.timetable_versions for each row execute function public.version_before();

create or replace function public.version_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare t uuid; prev jsonb;
begin
  select snapshot into prev from public.timetable_versions where group_id = new.group_id and version = new.version - 1;
  for t in
    select distinct x.tid from (
      select (e->>'teacher_id')::uuid tid from jsonb_array_elements(new.snapshot) e
      union select (e->>'teacher_id')::uuid from jsonb_array_elements(coalesce(prev, '[]'::jsonb)) e) x
    where x.tid is not null
  loop
    perform public.notify('user', null, t, 'timetable', 'Emploi du temps ' || public.group_code(new.group_id) || ' mis à jour (v' || new.version || ')',
      jsonb_array_length(new.changes) || ' changement(s) publié(s).', 'schedule', false);
  end loop;
  return new;
end $$;
create trigger version_after after insert on public.timetable_versions for each row execute function public.version_after();

-- Remet une ancienne version dans le brouillon (à vérifier puis publier)
create or replace function public.restore_version(p_version uuid) returns int
language plpgsql security definer set search_path = public as $$
declare v public.timetable_versions; n int;
begin
  if not public.is_admin() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  select * into v from public.timetable_versions where id = p_version;
  if not found then perform public.fail('not_found', 'Version introuvable'); end if;
  perform 1 from public.groups where id = v.group_id for update;
  delete from public.timetable_drafts where group_id = v.group_id;
  insert into public.timetable_drafts (group_id, source_slot_id, module_id, teacher_id, room_id, weekday, start_time, end_time, kind, status, note)
  select v.group_id,
         (select s.id from public.timetable_slots s where s.group_id = v.group_id and s.weekday = (e->>'weekday')::int
            and s.start_time = (e->>'start')::time and s.module_id = m.id limit 1),
         m.id,
         coalesce((e->>'teacher_id')::uuid, (select id from public.profiles where full_name = e->>'teacher' and role = 'teacher' limit 1)),
         coalesce((e->>'room_id')::uuid, (select id from public.rooms where name = e->>'room' limit 1)),
         (e->>'weekday')::int, (e->>'start')::time, (e->>'end')::time, coalesce(e->>'kind', 'cours'), coalesce(e->>'status', 'active'), e->>'note'
  from jsonb_array_elements(v.snapshot) e
  join public.modules m on m.id = coalesce((e->>'module_id')::uuid, (select id from public.modules where name = e->>'module' limit 1));
  get diagnostics n = row_count;
  -- les créneaux de la version publiée actuelle absents de l'ancienne version seront retirés à la publication
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'restore', 'timetable', v.group_id::text, jsonb_build_object('version', v.version));
  return n;
end $$;

-- ---------------------------------------------------------------------
-- 4. Annonces : brouillons, programmation, ciblage de stagiaires précis
-- ---------------------------------------------------------------------
alter table public.announcements drop constraint if exists announcements_check;
alter table public.announcements drop constraint if exists announcements_scope_check;
alter table public.announcements
  add column status text not null default 'published' check (status in ('draft', 'scheduled', 'published')),
  add column publish_at timestamptz,
  add column published_at timestamptz,
  add column target_users uuid[];
alter table public.announcements add constraint announcements_scope_check check (scope in ('all', 'group', 'module', 'users'));
alter table public.announcements add constraint announcements_target_check check (
  (scope = 'all' and group_id is null) or (scope = 'group' and group_id is not null)
  or (scope = 'module' and group_id is not null and module_id is not null)
  or (scope = 'users' and group_id is null and coalesce(array_length(target_users, 1), 0) between 1 and 500));
alter table public.announcements add constraint announcements_schedule_check check (status <> 'scheduled' or publish_at is not null);
update public.announcements set published_at = created_at where status = 'published' and published_at is null;
create index announcements_status_idx on public.announcements(status, publish_at);

create or replace function public.announcement_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then new.author_id := auth.uid(); else new.author_id := old.author_id; end if;
  if new.scope in ('all', 'users') then new.group_id := null; new.module_id := null; end if;
  if new.scope = 'group' then new.module_id := null; end if;
  if new.scope <> 'users' then new.target_users := null; end if;
  if new.scope = 'users' and (public.my_role() is null or not public.is_staff()) then
    perform public.fail('forbidden', 'Seule l''administration peut cibler des stagiaires précis');
  end if;
  if new.status = 'scheduled' and new.publish_at <= now() then new.status := 'published'; end if;
  if new.status = 'published' then new.published_at := coalesce(new.published_at, now()); new.publish_at := null;
  else new.published_at := null; end if;
  return new;
end $$;

-- Notification au moment de la publication (immédiate ou programmée), jamais pour un brouillon
create or replace function public.announcement_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare u uuid;
begin
  if new.status <> 'published' or (tg_op = 'UPDATE' and old.status = 'published') then return new; end if;
  if new.scope = 'users' then
    foreach u in array new.target_users loop
      perform public.notify('user', null, u, 'announcement', new.title, left(new.body, 200), 'announcements', new.important);
    end loop;
  else
    perform public.notify(case when new.scope = 'all' then 'all' else 'group' end, new.group_id, null, 'announcement',
      new.title, left(new.body, 200), 'announcements', new.important);
  end if;
  return new;
end $$;
drop trigger if exists announcement_after on public.announcements;
create trigger announcement_after after insert or update on public.announcements for each row execute function public.announcement_after();

-- Publie les annonces programmées arrivées à échéance (appelé par pg_cron chaque minute, et par l'application d'administration)
create or replace function public.publish_due_announcements() returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update public.announcements set status = 'published' where status = 'scheduled' and publish_at <= now();
  get diagnostics n = row_count;
  return n;
end $$;

-- ---------------------------------------------------------------------
-- 5. Notifications envoyées par le personnel : auteur + statistiques de lecture
-- ---------------------------------------------------------------------
alter table public.notifications add column created_by uuid references public.profiles(id) on delete set null default auth.uid();
create or replace function public.notification_stats(p_ids uuid[]) returns table (id uuid, reads int, audience int)
language sql stable security definer set search_path = public as $$
  select n.id,
    (select count(*)::int from public.notification_reads r join public.profiles p on p.id = r.user_id where r.notification_id = n.id and p.role = 'student'),
    (select count(*)::int from public.profiles p where p.status = 'active' and p.role = 'student'
       and (n.target_kind = 'all' or (n.target_kind = 'group' and p.group_id = n.group_id) or (n.target_kind = 'user' and p.id = n.user_id)))
  from public.notifications n
  where n.id = any(p_ids) and public.is_staff()
$$;

-- ---------------------------------------------------------------------
-- 6. Devoirs : pièces jointes (ressources liées), rendus des stagiaires, retours du formateur
-- ---------------------------------------------------------------------
alter table public.resources add column assessment_id uuid references public.assessments(id) on delete cascade;
create index resources_assessment_idx on public.resources(assessment_id);

create table public.submissions (
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  student_id    uuid not null references public.profiles(id) on delete cascade default auth.uid(),
  content       text check (char_length(content) <= 5000),
  link          text check (link is null or link ~ '^https://[^\s]+$'),
  storage_path  text,
  file_name     text check (char_length(file_name) <= 200),
  submitted_at  timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  feedback      text check (char_length(feedback) <= 3000),
  grade         text check (char_length(grade) <= 20),
  feedback_by   uuid references public.profiles(id) on delete set null,
  feedback_at   timestamptz,
  primary key (assessment_id, student_id),
  check (content is not null or link is not null or storage_path is not null)
);

create or replace function public.submission_before() returns trigger
language plpgsql security definer set search_path = public as $$
declare a public.assessments;
begin
  if tg_op = 'UPDATE' and auth.uid() is distinct from old.student_id then
    -- mise à jour par give_feedback (formateur / administration) : le contenu du rendu reste intact
    new.assessment_id := old.assessment_id; new.student_id := old.student_id; new.content := old.content; new.link := old.link;
    new.storage_path := old.storage_path; new.file_name := old.file_name; new.submitted_at := old.submitted_at; new.updated_at := now();
    return new;
  end if;
  if tg_op = 'INSERT' then new.student_id := auth.uid(); new.submitted_at := now(); end if;
  if tg_op = 'UPDATE' then
    if old.feedback_at is not null then perform public.fail('forbidden', 'Le formateur a déjà rendu son retour : rendu verrouillé'); end if;
    new.student_id := old.student_id; new.submitted_at := now();
    new.feedback := old.feedback; new.grade := old.grade; new.feedback_by := old.feedback_by; new.feedback_at := old.feedback_at;
  end if;
  new.updated_at := now();
  select * into a from public.assessments where id = new.assessment_id;
  if not found or a.kind <> 'assignment' then perform public.fail('invalid', 'Rendu possible uniquement pour un devoir'); end if;
  if public.my_role() <> 'student' or not (a.group_id is null or a.group_id = public.my_group()) then
    perform public.fail('forbidden', 'Ce devoir ne concerne pas votre groupe');
  end if;
  if new.storage_path is not null and (storage_path_owner(new.storage_path) is distinct from auth.uid()::text) then
    perform public.fail('forbidden', 'Fichier invalide');
  end if;
  return new;
end $$;
create or replace function public.storage_path_owner(p text) returns text
language sql immutable as $$ select split_part(p, '/', 1) $$;
create trigger submission_before before insert or update on public.submissions for each row execute function public.submission_before();

-- Retour du formateur (ou de l'administration) sur un rendu ; le stagiaire est notifié
create or replace function public.give_feedback(p_assessment uuid, p_student uuid, p_feedback text, p_grade text default null) returns void
language plpgsql security definer set search_path = public as $$
declare a public.assessments;
begin
  select * into a from public.assessments where id = p_assessment;
  if not found then perform public.fail('not_found', 'Devoir introuvable'); end if;
  if not (public.is_admin() or (a.group_id is not null and public.teaches(a.group_id, a.module_id))) then
    perform public.fail('forbidden', 'Seul le formateur du module peut répondre');
  end if;
  if coalesce(trim(p_feedback), '') = '' then perform public.fail('invalid', 'Retour vide'); end if;
  update public.submissions set feedback = left(p_feedback, 3000), grade = nullif(left(trim(coalesce(p_grade, '')), 20), ''),
    feedback_by = auth.uid(), feedback_at = now()
  where assessment_id = p_assessment and student_id = p_student;
  if not found then perform public.fail('not_found', 'Rendu introuvable'); end if;
  perform public.notify('user', null, p_student, 'assignment', 'Retour du formateur', a.title, 'assignments', false);
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'feedback', 'submissions', p_assessment::text, jsonb_build_object('student', p_student, 'grade', p_grade));
end $$;

-- ---------------------------------------------------------------------
-- 7. Calendrier académique (vacances, périodes d'examens, événements)
-- ---------------------------------------------------------------------
create table public.calendar_events (
  id          uuid primary key default gen_random_uuid(),
  title       text not null check (char_length(title) between 2 and 140),
  description text check (char_length(description) <= 1000),
  kind        text not null default 'event' check (kind in ('holiday', 'exam_period', 'event', 'deadline')),
  start_date  date not null,
  end_date    date not null,
  group_id    uuid references public.groups(id) on delete cascade,     -- null = tout l'établissement
  created_by  uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at  timestamptz not null default now(),
  check (end_date >= start_date and end_date - start_date <= 366)
);
create index calendar_events_dates_idx on public.calendar_events(start_date, end_date);

-- ---------------------------------------------------------------------
-- 8. Confidentialité : partage du téléphone avec les partenaires de covoiturage (opt-in)
-- ---------------------------------------------------------------------
alter table public.profiles add column share_phone boolean not null default false;
create or replace function public.ride_contacts(p_ride uuid) returns table (user_id uuid, full_name text, phone text, is_driver boolean)
language plpgsql stable security definer set search_path = public as $$
declare r public.rides;
begin
  select * into r from public.rides where id = p_ride;
  if not found then perform public.fail('not_found', 'Trajet introuvable'); end if;
  if not (r.author_id = auth.uid() or exists (select 1 from public.ride_bookings b where b.ride_id = p_ride and b.user_id = auth.uid())) then
    perform public.fail('forbidden', 'Contacts visibles uniquement par le conducteur et les passagers');
  end if;
  return query
    select p.id, p.full_name, case when p.share_phone and p.id <> auth.uid() then p.phone end, p.id = r.author_id
    from public.profiles p
    where p.id = r.author_id or p.id in (select b.user_id from public.ride_bookings b where b.ride_id = p_ride);
end $$;

-- ---------------------------------------------------------------------
-- 9. Rapports pour l'administration (données réelles uniquement)
-- ---------------------------------------------------------------------
create or replace function public.admin_reports() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare res jsonb;
begin
  if not public.is_staff() then perform public.fail('forbidden', 'Réservé au personnel'); end if;
  select jsonb_build_object(
    'groups', coalesce((select jsonb_agg(x order by x->>'code') from (
      select jsonb_build_object('id', g.id, 'code', g.code, 'label', g.label,
        'students', (select count(*) from public.profiles p where p.group_id = g.id and p.role = 'student' and p.status = 'active'),
        'slots', (select count(*) from public.timetable_slots s where s.group_id = g.id and s.status = 'active'),
        'version', (select max(version) from public.timetable_versions v where v.group_id = g.id),
        'published_at', (select max(published_at) from public.timetable_versions v where v.group_id = g.id),
        'drafts', (select count(*) from public.timetable_drafts d where d.group_id = g.id),
        'sessions', (select count(*) from public.class_sessions c where c.group_id = g.id and c.status = 'held'),
        'records', (select count(*) from public.attendance_records a join public.class_sessions c on c.id = a.session_id where c.group_id = g.id),
        'present', (select count(*) from public.attendance_records a join public.class_sessions c on c.id = a.session_id where c.group_id = g.id and a.status in ('present', 'late', 'excused')),
        'absent', (select count(*) from public.attendance_records a join public.class_sessions c on c.id = a.session_id where c.group_id = g.id and a.status = 'absent'),
        'late', (select count(*) from public.attendance_records a join public.class_sessions c on c.id = a.session_id where c.group_id = g.id and a.status = 'late'),
        'assignments', (select count(*) from public.assessments a where a.group_id = g.id and a.kind = 'assignment'),
        'exams', (select count(*) from public.assessments a where a.group_id = g.id and a.kind = 'exam'),
        'posts', (select count(*) from public.posts p where p.group_id = g.id)) x
      from public.groups g) t), '[]'::jsonb),
    'modules', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'name', m.name,
        'sessions', (select count(*) from public.class_sessions c where c.module_id = m.id and c.status = 'held'),
        'records', (select count(*) from public.attendance_records a join public.class_sessions c on c.id = a.session_id where c.module_id = m.id),
        'absent', (select count(*) from public.attendance_records a join public.class_sessions c on c.id = a.session_id where c.module_id = m.id and a.status = 'absent'))
        order by m.code) from public.modules m), '[]'::jsonb),
    'people', (select jsonb_object_agg(role, n) from (select role::text, count(*) n from public.profiles where status = 'active' group by role) r),
    'suspended', (select count(*) from public.profiles where status = 'suspended'),
    'assessments', jsonb_build_object(
        'upcoming_assignments', (select count(*) from public.assessments where kind = 'assignment' and due_at > now()),
        'upcoming_exams', (select count(*) from public.assessments where kind = 'exam' and due_at > now()),
        'submissions', (select count(*) from public.submissions),
        'feedback_pending', (select count(*) from public.submissions where feedback_at is null)),
    'moderation', jsonb_build_object(
        'open', (select count(*) from public.reports where status = 'open'),
        'actioned', (select count(*) from public.reports where status = 'actioned'),
        'dismissed', (select count(*) from public.reports where status = 'dismissed'),
        'hidden_posts', (select count(*) from public.posts where status = 'hidden'),
        'removed_posts', (select count(*) from public.posts where status = 'removed'),
        'muted_users', (select count(*) from public.profiles where muted_until > now())),
    'justifications', jsonb_build_object(
        'pending', (select count(*) from public.absence_justifications where status = 'pending'),
        'accepted', (select count(*) from public.absence_justifications where status = 'accepted'),
        'rejected', (select count(*) from public.absence_justifications where status = 'rejected')),
    'notifications_30d', (select count(*) from public.notifications where created_at > now() - interval '30 days'),
    'announcements', jsonb_build_object(
        'published', (select count(*) from public.announcements where status = 'published'),
        'scheduled', (select count(*) from public.announcements where status = 'scheduled'),
        'drafts', (select count(*) from public.announcements where status = 'draft'))
  ) into res;
  return res;
end $$;

-- ---------------------------------------------------------------------
-- 10. Accès du personnel (surveillance) aux fonctions d'assiduité et de modération
-- ---------------------------------------------------------------------

-- Fonctions d'assiduité, de justificatifs et de modération ouvertes à la surveillance (copie des versions 0002 avec is_staff())
create or replace function public.open_session(p_slot uuid, p_date date) returns uuid
language plpgsql security definer set search_path = public as $$
declare s public.timetable_slots; v_id uuid;
begin
  select * into s from public.timetable_slots where id = p_slot;
  if not found then perform public.fail('not_found', 'Créneau introuvable'); end if;
  if not (public.is_staff() or (public.is_teacher() and s.teacher_id = auth.uid())) then
    perform public.fail('forbidden', 'Seul le formateur du cours, la surveillance ou l''administration peut faire l''appel');
  end if;
  if extract(isodow from p_date) <> s.weekday then perform public.fail('invalid_date', 'Cette date ne correspond pas au jour du cours'); end if;
  if p_date > public.local_today() then perform public.fail('invalid_date', 'Impossible de faire l''appel d''une séance future'); end if;
  if not public.is_staff() and p_date < public.local_today() - 30 then
    perform public.fail('invalid_date', 'Séance trop ancienne : contactez l''administration');
  end if;
  if exists (select 1 from public.session_exceptions e where e.slot_id = p_slot and e.session_date = p_date and e.kind = 'cancelled') then
    perform public.fail('invalid', 'Cette séance a été annulée');
  end if;
  select id into v_id from public.class_sessions where slot_id = p_slot and session_date = p_date;
  if v_id is null then
    insert into public.class_sessions (slot_id, group_id, module_id, teacher_id, room_id, session_date, start_time, end_time, status, created_by)
    values (s.id, s.group_id, s.module_id, s.teacher_id, s.room_id, p_date, s.start_time, s.end_time,
            case when s.status = 'cancelled' then 'cancelled' else 'held' end, auth.uid())
    returning id into v_id;
  end if;
  return v_id;
end $$;

create or replace function public.save_attendance(p_session uuid, p_records jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare cs public.class_sessions; r jsonb; n int := 0; v_old text; v_status text;
begin
  select * into cs from public.class_sessions where id = p_session;
  if not found then perform public.fail('not_found', 'Séance introuvable'); end if;
  if not (public.is_staff() or (public.is_teacher() and cs.teacher_id = auth.uid())) then
    perform public.fail('forbidden', 'Seul le formateur du cours ou l''administration peut modifier l''appel');
  end if;
  if not public.is_staff() and cs.session_date < public.local_today() - 30 then
    perform public.fail('invalid_date', 'Séance trop ancienne : contactez l''administration');
  end if;
  if jsonb_typeof(p_records) <> 'array' or jsonb_array_length(p_records) > 200 then perform public.fail('invalid', 'Liste invalide'); end if;

  for r in select * from jsonb_array_elements(p_records) loop
    v_status := r->>'status';
    if v_status not in ('present', 'absent', 'late', 'excused') then perform public.fail('invalid', 'Statut invalide'); end if;
    if not exists (select 1 from public.profiles where id = (r->>'student_id')::uuid and role = 'student' and group_id = cs.group_id) then
      perform public.fail('invalid', 'Un stagiaire ne fait pas partie de ce groupe');
    end if;
    select status into v_old from public.attendance_records where session_id = p_session and student_id = (r->>'student_id')::uuid;
    insert into public.attendance_records (session_id, student_id, status, minutes_late, note, recorded_by, recorded_at)
    values (p_session, (r->>'student_id')::uuid, v_status,
            case when v_status = 'late' then greatest(1, least(240, coalesce((r->>'minutes_late')::int, 5))) end,
            nullif(left(r->>'note', 200), ''), auth.uid(), now())
    on conflict (session_id, student_id) do update
      set status = excluded.status, minutes_late = excluded.minutes_late, note = excluded.note, recorded_by = excluded.recorded_by, recorded_at = now()
      where (attendance_records.status, attendance_records.minutes_late, attendance_records.note) is distinct from (excluded.status, excluded.minutes_late, excluded.note);
    if v_status in ('absent', 'late') and v_old is distinct from v_status then
      perform public.notify('user', null, (r->>'student_id')::uuid, 'attendance',
        case when v_status = 'absent' then 'Absence enregistrée' else 'Retard enregistré' end,
        public.module_name(cs.module_id) || ' · ' || to_char(cs.session_date, 'DD/MM/YYYY') || ' ' || to_char(cs.start_time, 'HH24:MI')
        || case when v_status = 'absent' then '. Vous pouvez envoyer un justificatif depuis « Assiduité ».' else '' end, 'attendance', false);
    end if;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.review_justification(p_session uuid, p_student uuid, p_accept boolean) returns void
language plpgsql security definer set search_path = public as $$
declare cs public.class_sessions;
begin
  select * into cs from public.class_sessions where id = p_session;
  if not (public.is_staff() or (public.is_teacher() and cs.teacher_id = auth.uid())) then
    perform public.fail('forbidden', 'Action non autorisée');
  end if;
  update public.absence_justifications set status = case when p_accept then 'accepted' else 'rejected' end, reviewed_by = auth.uid(), reviewed_at = now()
    where session_id = p_session and student_id = p_student and status = 'pending';
  if not found then perform public.fail('not_found', 'Justificatif introuvable ou déjà traité'); end if;
  if p_accept then
    update public.attendance_records set status = 'excused', minutes_late = null, recorded_by = auth.uid(), recorded_at = now()
      where session_id = p_session and student_id = p_student;
  end if;
  perform public.notify('user', null, p_student, 'attendance', case when p_accept then 'Justificatif accepté' else 'Justificatif refusé' end,
    public.module_name(cs.module_id) || ' · ' || to_char(cs.session_date, 'DD/MM/YYYY'), 'attendance', false);
end $$;

create or replace function public.moderate(p_kind text, p_id uuid, p_action text, p_reason text default null) returns void
language plpgsql security definer set search_path = public as $$
declare v_status text; v_group uuid;
begin
  if p_action not in ('hide', 'restore', 'remove', 'dismiss') then perform public.fail('invalid', 'Action invalide'); end if;
  if p_kind = 'post' then select group_id into v_group from public.posts where id = p_id;
  elsif p_kind = 'reply' then select p.group_id into v_group from public.replies r join public.posts p on p.id = r.post_id where r.id = p_id;
  end if;
  if not (public.is_staff() or (p_kind in ('post', 'reply') and public.teaches_group(v_group))) then
    perform public.fail('forbidden', 'Modération réservée à l''administration et aux formateurs du groupe');
  end if;
  if p_action <> 'dismiss' then
    v_status := case p_action when 'hide' then 'hidden' when 'remove' then 'removed' else 'visible' end;
    if p_kind = 'post' then update public.posts set status = v_status where id = p_id;
    elsif p_kind = 'reply' then update public.replies set status = v_status where id = p_id;
    elsif p_kind = 'ride' then update public.rides set status = v_status where id = p_id;
    elsif p_kind = 'study_group' then update public.study_groups set status = v_status where id = p_id;
    else perform public.fail('invalid', 'Type invalide'); end if;
  end if;
  update public.reports set status = case when p_action in ('dismiss', 'restore') then 'dismissed' else 'actioned' end,
         handled_by = auth.uid(), handled_at = now()
   where target_kind = p_kind and target_id = p_id and status = 'open';
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'moderate:' || p_action, p_kind, p_id::text, jsonb_build_object('reason', left(p_reason, 200)));
end $$;

create or replace function public.mute_user(p_user uuid, p_days int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff() then perform public.fail('forbidden', 'Réservé à l''administration'); end if;
  if p_days < 0 or p_days > 365 then perform public.fail('invalid', 'Durée invalide'); end if;
  update public.profiles set muted_until = case when p_days = 0 then null else now() + make_interval(days => p_days) end where id = p_user;
  if p_days > 0 then
    perform public.notify('user', null, p_user, 'system', 'Accès communauté limité',
      'Suite à un signalement, vous ne pouvez plus publier pendant ' || p_days || ' jour(s).', 'help', true);
  end if;
end $$;

create or replace function public.enforce_rate(p_table text, p_author_col text, p_window interval, p_max int, p_label text)
returns void language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if public.is_staff() then return; end if;
  if exists (select 1 from public.profiles where id = auth.uid() and muted_until > now()) then
    perform public.fail('muted', 'Votre compte est temporairement limité dans la communauté');
  end if;
  execute format('select count(*) from public.%I where %I = $1 and created_at > now() - $2', p_table, p_author_col)
    into n using auth.uid(), p_window;
  if n >= p_max then
    perform public.fail('rate_limited', 'Trop de ' || p_label || ' en peu de temps. Réessayez plus tard.');
  end if;
end $$;

-- Lecture des questions : la surveillance voit l'auteur réel des questions anonymes (modération), comme l'administration
create or replace view public.posts_feed as
  select p.id, p.kind, p.group_id, p.module_id,
         case when p.anonymous and p.author_id is distinct from auth.uid() and not public.is_staff() then null else p.author_id end as author_id,
         p.anonymous, p.title, p.body, p.status, p.resolved, p.best_reply_id, p.created_at,
         (select count(*) from public.post_votes v where v.post_id = p.id)::int as votes,
         exists (select 1 from public.post_votes v where v.post_id = p.id and v.user_id = auth.uid()) as voted
  from public.posts p
  where (p.group_id = public.my_group() or p.author_id = auth.uid() or public.teaches_group(p.group_id) or public.is_staff())
    and (p.status = 'visible' or p.author_id = auth.uid() or public.is_staff() or public.teaches_group(p.group_id));

-- ---------------------------------------------------------------------
-- 11. Règles d'accès (RLS)
-- ---------------------------------------------------------------------
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_staff() or (role = 'student' and public.teaches_group(group_id)));

drop policy if exists sessions_read on public.class_sessions;
create policy sessions_read on public.class_sessions for select to authenticated
  using (group_id = public.my_group() or teacher_id = auth.uid() or public.is_staff());

drop policy if exists attendance_read on public.attendance_records;
create policy attendance_read on public.attendance_records for select to authenticated
  using (student_id = auth.uid() or public.is_staff()
         or exists (select 1 from public.class_sessions s where s.id = session_id and s.teacher_id = auth.uid()));

drop policy if exists justif_read on public.absence_justifications;
create policy justif_read on public.absence_justifications for select to authenticated
  using (student_id = auth.uid() or public.is_staff()
         or exists (select 1 from public.class_sessions s where s.id = session_id and s.teacher_id = auth.uid()));

drop policy if exists notif_insert on public.notifications;
create policy notif_insert on public.notifications for insert to authenticated
  with check (public.is_staff()
    or (target_kind = 'user' and user_id = auth.uid() and kind = 'reminder')
    or (target_kind = 'group' and kind in ('announcement', 'system') and public.teaches_group(group_id)));

-- Le personnel retrouve aussi les notifications personnelles qu'il a lui-même envoyées (historique « Envoyées »)
drop policy if exists notif_read on public.notifications;
create policy notif_read on public.notifications for select to authenticated
  using (target_kind = 'all' or (target_kind = 'group' and public.can_see_group(group_id)) or user_id = auth.uid()
         or (created_by = auth.uid() and public.is_staff()));

drop policy if exists reads_own on public.notification_reads;
create policy reads_own on public.notification_reads for select to authenticated using (user_id = auth.uid() or public.is_staff());

drop policy if exists posts_read on public.posts;
create policy posts_read on public.posts for select to authenticated
  using (group_id = public.my_group() or author_id = auth.uid() or public.teaches_group(group_id) or public.is_staff());

drop policy if exists posts_delete on public.posts;
create policy posts_delete on public.posts for delete to authenticated using (author_id = auth.uid() or public.is_staff());

drop policy if exists replies_read on public.replies;
create policy replies_read on public.replies for select to authenticated
  using (exists (select 1 from public.posts p where p.id = post_id
                 and (p.group_id = public.my_group() or p.author_id = auth.uid() or public.teaches_group(p.group_id) or public.is_staff()))
         and (status = 'visible' or author_id = auth.uid() or public.is_staff()));

drop policy if exists replies_insert on public.replies;
create policy replies_insert on public.replies for insert to authenticated
  with check (author_id = auth.uid() and exists (select 1 from public.posts p where p.id = post_id
              and (p.group_id = public.my_group() or p.author_id = auth.uid() or public.teaches_group(p.group_id) or public.is_staff())));

drop policy if exists replies_delete on public.replies;
create policy replies_delete on public.replies for delete to authenticated using (author_id = auth.uid() or public.is_staff());

drop policy if exists reports_read on public.reports;
create policy reports_read on public.reports for select to authenticated using (reporter_id = auth.uid() or public.is_staff());

drop policy if exists sg_read on public.study_groups;
create policy sg_read on public.study_groups for select to authenticated using (status = 'visible' or created_by = auth.uid() or public.is_staff());

drop policy if exists sg_delete on public.study_groups;
create policy sg_delete on public.study_groups for delete to authenticated using (created_by = auth.uid() or public.is_staff());

drop policy if exists sgm_delete on public.study_group_members;
create policy sgm_delete on public.study_group_members for delete to authenticated using (user_id = auth.uid() or public.is_staff());

drop policy if exists rides_read on public.rides;
create policy rides_read on public.rides for select to authenticated using (status = 'visible' or author_id = auth.uid() or public.is_staff());

drop policy if exists rides_delete on public.rides;
create policy rides_delete on public.rides for delete to authenticated using (author_id = auth.uid() or public.is_staff());

drop policy if exists rb_delete on public.ride_bookings;
create policy rb_delete on public.ride_bookings for delete to authenticated using (user_id = auth.uid() or public.is_staff());

drop policy if exists res_read on public.resources;
create policy res_read on public.resources for select to authenticated
  using (public.is_staff() or (group_id is null and (public.my_role() is not null)) or public.can_see_group(group_id));


-- Annonces : brouillons et annonces programmées invisibles pour les stagiaires ; ciblage individuel
drop policy if exists ann_read on public.announcements;
create policy ann_read on public.announcements for select to authenticated
  using (public.is_staff() or author_id = auth.uid()
         or (status = 'published' and (scope = 'all' or (scope = 'users' and auth.uid() = any(target_users))
             or (scope in ('group', 'module') and public.can_see_group(group_id)))));
drop policy if exists ann_write on public.announcements;
create policy ann_write on public.announcements for all to authenticated
  using (public.is_staff() or (author_id = auth.uid() and public.teaches_group(group_id)))
  with check (public.is_staff() or (scope in ('group', 'module') and public.teaches_group(group_id)
              and (scope = 'group' or public.teaches(group_id, module_id))));
-- La surveillance peut supprimer une notification envoyée par erreur
drop policy if exists notif_admin_delete on public.notifications;
create policy notif_admin_delete on public.notifications for delete to authenticated using (public.is_staff());

alter table public.session_exceptions enable row level security;
create policy exceptions_read on public.session_exceptions for select to authenticated
  using (public.can_see_group(group_id) or exists (select 1 from public.timetable_slots s where s.id = slot_id and s.teacher_id = auth.uid()));

alter table public.submissions enable row level security;
create policy submissions_read on public.submissions for select to authenticated
  using (student_id = auth.uid() or public.is_staff()
         or exists (select 1 from public.assessments a where a.id = assessment_id and a.group_id is not null and public.teaches(a.group_id, a.module_id)));
create policy submissions_insert on public.submissions for insert to authenticated with check (student_id = auth.uid());
create policy submissions_update on public.submissions for update to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());
create policy submissions_delete on public.submissions for delete to authenticated using (student_id = auth.uid() and feedback_at is null);

alter table public.calendar_events enable row level security;
create policy calendar_read on public.calendar_events for select to authenticated
  using (group_id is null or public.can_see_group(group_id));
create policy calendar_write on public.calendar_events for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- ---------------------------------------------------------------------
-- 12. Droits par colonne, fonctions exposées
-- ---------------------------------------------------------------------
revoke all on public.session_exceptions, public.submissions, public.calendar_events from anon;
revoke insert, update, delete on public.session_exceptions from authenticated;
grant select on public.session_exceptions to authenticated;
revoke update on public.submissions from authenticated;
grant select, insert, delete on public.submissions to authenticated;
grant update (content, link, storage_path, file_name) on public.submissions to authenticated;
grant select, insert, update, delete on public.calendar_events to authenticated;
grant update (share_phone) on public.profiles to authenticated;

revoke all on function public.is_staff(), public.my_access(), public.set_session_exception(uuid, date, text, uuid, time, time, text),
  public.clear_session_exception(uuid, date), public.group_code(uuid), public.restore_version(uuid), public.publish_due_announcements(),
  public.notification_stats(uuid[]), public.give_feedback(uuid, uuid, text, text), public.ride_contacts(uuid), public.admin_reports(),
  public.storage_path_owner(text), public.version_before(), public.version_after(), public.submission_before() from public, anon;
grant execute on function public.is_staff(), public.my_access(), public.set_session_exception(uuid, date, text, uuid, time, time, text),
  public.clear_session_exception(uuid, date), public.group_code(uuid), public.restore_version(uuid), public.publish_due_announcements(),
  public.notification_stats(uuid[]), public.give_feedback(uuid, uuid, text, text), public.ride_contacts(uuid), public.admin_reports(),
  public.storage_path_owner(text) to authenticated;

-- Audit des nouvelles tables sensibles
create trigger audit_calendar after insert or update or delete on public.calendar_events for each row execute function public.audit_row();

-- ---------------------------------------------------------------------
-- 13. Stockage : bucket privé « submissions » (rendus des stagiaires, 10 Mo)
-- ---------------------------------------------------------------------
do $$ begin
  if exists (select 1 from pg_namespace where nspname = 'storage') then
    insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
    values ('submissions', 'submissions', false, 10485760, array['application/pdf', 'application/zip', 'application/x-zip-compressed', 'image/png', 'image/jpeg',
      'text/plain', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
    on conflict (id) do nothing;
    execute $p$ create policy submissions_files_read on storage.objects for select to authenticated
      using (bucket_id = 'submissions' and ((storage.foldername(name))[1] = auth.uid()::text
             or exists (select 1 from public.submissions s where s.storage_path = name))) $p$;
    execute $p$ create policy submissions_files_insert on storage.objects for insert to authenticated
      with check (bucket_id = 'submissions' and public.my_role() = 'student' and (storage.foldername(name))[1] = auth.uid()::text) $p$;
    execute $p$ create policy submissions_files_delete on storage.objects for delete to authenticated
      using (bucket_id = 'submissions' and (storage.foldername(name))[1] = auth.uid()::text) $p$;
  end if;
end $$;

-- ---------------------------------------------------------------------
-- 14. Temps réel et tâches planifiées
-- ---------------------------------------------------------------------
do $$ declare t text; begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['session_exceptions', 'calendar_events', 'submissions', 'timetable_versions'] loop
      if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;

-- Publication des annonces programmées chaque minute (pg_cron, disponible sur Supabase)
do $$ begin
  if exists (select 1 from pg_available_extensions where name = 'pg_cron') then
    create extension if not exists pg_cron;
    perform cron.unschedule(jobid) from cron.job where jobname = 'campusflow-publish-announcements';
    perform cron.schedule('campusflow-publish-announcements', '* * * * *', 'select public.publish_due_announcements()');
  end if;
exception when others then
  raise notice 'pg_cron indisponible : les annonces programmées seront publiées à l''ouverture de l''application d''administration (%).', sqlerrm;
end $$;
