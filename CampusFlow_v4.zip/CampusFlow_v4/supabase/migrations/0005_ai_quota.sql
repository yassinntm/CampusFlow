-- =====================================================================
--  CampusFlow v3 — 0005 : quota de l'assistant IA (appelé uniquement par la fonction serveur)
-- =====================================================================
-- Incrémente atomiquement le compteur du jour (fuseau Africa/Casablanca) et refuse au-delà de la limite.
-- Retourne le nombre de requêtes restantes. Exécutable seulement avec la clé service_role (fonction Edge), jamais depuis le navigateur.
create or replace function public.ai_consume(p_user uuid, p_limit int) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if p_limit < 1 or p_limit > 1000 then perform public.fail('invalid', 'Limite invalide'); end if;
  if not exists (select 1 from public.profiles where id = p_user and status = 'active') then perform public.fail('forbidden', 'Compte inactif'); end if;
  insert into public.ai_usage (user_id, day, requests) values (p_user, public.local_today(), 1)
  on conflict (user_id, day) do update set requests = public.ai_usage.requests + 1
  returning requests into n;
  if n > p_limit then perform public.fail('quota', 'Quota quotidien atteint'); end if;
  return p_limit - n;
end $$;

revoke all on function public.ai_consume(uuid, int) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function public.ai_consume(uuid, int) to service_role';
  end if;
end $$;
