import test from 'node:test';
import assert from 'node:assert/strict';
import { addDays, isoWeekday, mondayOf, monthGrid, instantFrom, timeOfInstant, isoOfInstant, diffDays, toMin, fromMin } from '../../src/core/dates.js';

test('arithmétique des dates civiles', () => {
  assert.equal(addDays('2026-02-28', 1), '2026-03-01');
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
  assert.equal(isoWeekday('2026-11-20'), 5);            // vendredi
  assert.equal(mondayOf('2026-11-22'), '2026-11-16');   // dimanche → lundi précédent
  assert.equal(diffDays('2026-11-20', '2026-12-01'), 11);
  const g = monthGrid('2026-11-20');
  assert.equal(g.length, 42); assert.equal(isoWeekday(g[0]), 1); assert.ok(g.includes('2026-11-01') && g.includes('2026-11-30'));
});
test('heures', () => { assert.equal(toMin('08:30:00'), 510); assert.equal(fromMin(645), '10:45'); });
test('fuseau Africa/Casablanca, Ramadan compris', () => {
  // Le Maroc est revenu à GMT (UTC+0) le 20/09/2026 ; avant, UTC+1 sauf pendant le Ramadan. Le décalage vient des données tz, jamais codé en dur.
  assert.equal(instantFrom('2026-06-10', '08:30'), '2026-06-10T07:30:00.000Z');   // GMT+1 (avant la réforme)
  const normal = instantFrom('2026-11-20', '08:30');                                // GMT (après la réforme)
  assert.equal(normal, '2026-11-20T08:30:00.000Z');
  assert.equal(timeOfInstant(normal), '08:30'); assert.equal(isoOfInstant(normal), '2026-11-20');
  const ram = instantFrom('2026-02-25', '08:30');                    // Ramadan 2026 : GMT
  assert.equal(timeOfInstant(ram), '08:30');
  assert.equal(isoOfInstant(instantFrom('2026-11-20', '23:30')), '2026-11-20');
});
