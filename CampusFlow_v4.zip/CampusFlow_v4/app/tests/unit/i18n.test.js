// Audit des traductions : mêmes clés FR/AR, mêmes variables {x}, aucune clé utilisée dans le code qui manquerait.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import fr from '../../src/i18n/fr.js';
import ar from '../../src/i18n/ar.js';

const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : e.name.endsWith('.js') ? [path.join(d, e.name)] : []));
const src = walk(new URL('../../src', import.meta.url).pathname).filter((f) => !f.includes('/i18n/')).map((f) => fs.readFileSync(f, 'utf8')).join('\n');
const vars = (s) => [...s.matchAll(/\{(\w+)\}/g)].map((m) => m[1]).sort().join(',');

test('mêmes clés en français et en arabe', () => {
  assert.deepEqual(Object.keys(fr).filter((k) => !(k in ar)), [], 'manquantes en arabe');
  assert.deepEqual(Object.keys(ar).filter((k) => !(k in fr)), [], 'en trop en arabe');
});
test('mêmes variables dans chaque traduction', () => {
  const bad = Object.keys(fr).filter((k) => vars(fr[k]) !== vars(ar[k] || ''));
  assert.deepEqual(bad, []);
});
test('aucune traduction vide ni identique à la clé', () => {
  assert.deepEqual(Object.entries({ ...fr }).filter(([k, v]) => !v || v === k).map(([k]) => k), []);
  assert.deepEqual(Object.entries({ ...ar }).filter(([k, v]) => !v || v === k).map(([k]) => k), []);
});
test('toutes les clés statiques utilisées dans le code existent', () => {
  const used = [...new Set([...src.matchAll(/\bt\('([a-z_]+\.[a-zA-Z0-9_]+)'/g)].map((m) => m[1]))].filter((k) => !k.endsWith('_'));
  assert.deepEqual(used.filter((k) => !(k in fr)), []);
});
test('clés dynamiques (préfixe + valeur) couvertes', () => {
  const dyn = {
    'kind.': ['cours', 'tp', 'td', 'exam', 'autre'], 'role.': ['student', 'teacher', 'supervisor', 'admin'], 'prio.': ['low', 'normal', 'high'],
    'progress.': ['todo', 'in_progress', 'done'], 'progress.to_': ['todo', 'in_progress', 'done'], 'att.': ['present', 'absent', 'late', 'excused'],
    'att.short_': ['present', 'absent', 'late', 'excused'], 'justif.': ['pending', 'accepted', 'rejected'], 'justif.f_': ['pending', 'reviewed'],
    'notif.f_': ['all', 'unread', 'important', 'changes', 'reminders'], 'comm.': ['question', 'discussion', 'study', 'rides'], 'report.': ['spam', 'harassment', 'inappropriate', 'off_topic', 'cheating', 'other'],
    'mod.status_': ['visible', 'hidden', 'removed'], 'mod.': ['hide', 'restore', 'remove', 'dismiss'], 'mod.k_': ['post', 'reply', 'ride', 'study_group'],
    'auth.tab_': ['login', 'signup', 'forgot'], 'assess.': ['assignment', 'exam'], 'assess.f_': ['upcoming', 'past'], 'sched.': ['day', 'week', 'month'],
    'plan.': ['assess', 'tasks', 'study'], 'plan.f_': ['todo', 'done', 'past'], 'users.': ['accounts', 'roster'], 'cat.': ['modules', 'rooms', 'teaching'],
    'room.': ['salle', 'labo', 'amphi', 'atelier', 'autre'], 'tt.st_': ['active', 'cancelled'], 'tt.c_': ['group', 'teacher', 'room'],
    'audit.a_': ['insert', 'update', 'delete', 'publish', 'moderate'], 'exp.': ['timetable', 'assessments', 'attendance', 'announcements', 'calendar', 'reference'],
    'search.': ['modules', 'classes', 'assessments', 'announcements', 'resources', 'posts', 'people'], 'rules.': ['rule1', 'rule2', 'rule3', 'rule4'],
    'tile.': ['announcements', 'attendance', 'resources', 'freetime', 'community', 'ai', 'search', 'notifications'],
    'err.': ['conflicts', 'forbidden', 'full', 'invalid', 'invalid_code', 'invalid_date', 'muted', 'no_changes', 'not_found', 'quota', 'rate_limited'],
    // Plateforme double (v4)
    'ann.status_': ['published', 'scheduled', 'draft'], 'ann.mode_': ['published', 'scheduled', 'draft'], 'ann.none_': ['published', 'scheduled', 'draft'], 'ann.saved_': ['published', 'scheduled', 'draft'],
    'assign.tab_': ['week', 'up', 'past'], 'assign.none_': ['week', 'up', 'past'], 'att.session_': ['held', 'cancelled'], 'att.tab_': ['students', 'sessions'],
    'cal.kind_': ['holiday', 'exam_period', 'event', 'deadline'], 'exc.k_': ['cancelled', 'moved'], 'mod.done_': ['hide', 'restore', 'remove', 'dismiss'],
    'mod.r_': ['open', 'actioned', 'dismissed'], 'mod.tab_': ['reports', 'hidden', 'history'], 'profile.font_': ['normal', 'large', 'xlarge'],
    'rep.mod_': ['open', 'actioned', 'dismissed', 'hidden_posts', 'removed_posts', 'muted_users'],
    'rep.': ['justif_pending', 'justif_accepted', 'justif_rejected', 'ann_published', 'ann_scheduled', 'ann_drafts', 'notifs_30d'],
    'campus.': ['exams', 'attendance', 'community', 'studygroups', 'rides', 'freetime', 'resources', 'ai'], 'ride.': ['offer', 'request'],
  };
  // menus des deux applications : ['route', 'icône', 'nav.xxx', …]
  const nav = [...src.matchAll(/\['[a-z]+', '[a-z0-9]+', '(nav\.[a-z_]+)'/g)].map((m) => m[1]);
  // tuiles « Vie du campus » : t('nav.' + to)
  const links = ['exams', 'attendance', 'community', 'studygroups', 'rides', 'freetime', 'resources', 'ai'].map((k) => 'nav.' + k);
  assert.ok(nav.length >= 25, 'menus détectés');
  const need = [...Object.entries(dyn).flatMap(([p, vs]) => vs.map((v) => p + v)), ...Object.values(dyn['exp.']).map((v) => 'exp.' + v + '_d'), ...nav];
  assert.deepEqual(need.filter((k) => !(k in fr)), []);
  assert.deepEqual(links.filter((k) => !(k in fr)), []);
});
