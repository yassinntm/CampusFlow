import test from 'node:test';
import assert from 'node:assert/strict';
import { html, raw, esc, safeUrl } from '../../src/core/html.js';

test('échappement XSS par défaut', () => {
  const evil = '<img src=x onerror=alert(1)>"\'`';
  const out = String(html`<p title="${evil}">${evil}</p>`);
  assert.ok(!out.includes('<img'));
  assert.equal(out, '<p title="&lt;img src=x onerror=alert(1)&gt;&quot;&#39;&#96;">&lt;img src=x onerror=alert(1)&gt;&quot;&#39;&#96;</p>');
  assert.equal(String(html`${[evil, raw('<b>ok</b>')]}`), esc(evil) + '<b>ok</b>');
  assert.equal(String(html`${null}${false}${undefined}${0}`), '0');
});
test('liens : https uniquement', () => {
  assert.equal(safeUrl('javascript:alert(1)'), '#');
  assert.equal(safeUrl('data:text/html,x'), '#');
  assert.equal(safeUrl('http://x.org'), '#');
  assert.equal(safeUrl('https://x.org/a.pdf'), 'https://x.org/a.pdf');
  assert.equal(safeUrl('https://x.org/" onmouseover="x'), '#');
});
