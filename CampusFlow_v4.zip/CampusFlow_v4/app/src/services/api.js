// Accès Supabase. Seules l'URL du projet et la clé publique (anon/publishable) sont utilisées ici :
// elles sont faites pour être publiques, la sécurité est assurée par les règles RLS et les fonctions de la base.
import { createClient } from '@supabase/supabase-js';
import { t, getLang } from '../core/i18n.js';

const URL_ = import.meta.env.VITE_SUPABASE_URL;
const KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const configured = Boolean(URL_ && KEY && !/VOTRE-PROJET|your-project/i.test(URL_));
// Garde-fou : une clé « service_role » / secrète ne doit jamais arriver dans le navigateur
const looksSecret = (k) => {
  if (!k) return false;
  if (/^sb_secret_/.test(k)) return true;
  try { return JSON.parse(atob(k.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).role === 'service_role'; } catch { return false; }
};
export const secretKeyDetected = looksSecret(KEY);

export const sb = configured && !secretKeyDetected
  ? createClient(URL_, KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } })
  : null;

export class ApiError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
// Erreurs de la base : « CF:code|message » (fonctions), codes Postgres, ou réseau
export const toError = (e) => {
  if (e instanceof ApiError) return e;
  const msg = String(e?.message || e || '');
  const m = /CF:([a-z_]+)\|([^\n]+)/.exec(msg);
  if (m) {
    // Les messages détaillés de la base sont en français ; en arabe on affiche la traduction du code d'erreur
    const key = 'err.' + m[1];
    const tr = t(key);
    return new ApiError(m[1], getLang() === 'fr' || tr === key ? m[2] : tr);
  }
  const code = e?.code;
  if (code === '42501' || /row-level security|permission denied/i.test(msg)) return new ApiError('forbidden', t('err.forbidden'));
  if (code === '23505') return new ApiError('duplicate', t('err.duplicate'));
  if (code === '23514' || code === '22P02' || code === '23502') return new ApiError('invalid', t('err.invalid'));
  if (code === '23P01') return new ApiError('conflicts', t('err.conflicts'));
  if (code === '23503') return new ApiError('in_use', t('err.in_use'));
  if (/Failed to fetch|NetworkError|network/i.test(msg)) return new ApiError('network', t('err.network'));
  return new ApiError('unknown', msg || t('err.unknown'));
};
export const q = async (builder) => {
  let res;
  try { res = await builder; } catch (e) { throw toError(e); }
  if (res.error) throw toError(res.error);
  return res.data;
};
export const rpc = (fn, args = {}) => q(sb.rpc(fn, args));
