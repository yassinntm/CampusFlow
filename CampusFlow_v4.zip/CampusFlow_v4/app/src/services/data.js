// Chargement des données (filtrées côté serveur par RLS) avec un petit cache invalidé par le temps réel et les mutations
import { sb, q } from './api.js';
import { store, myId } from '../core/store.js';
import { todayISO as today, addDays } from '../core/dates.js';
const todayISO = (n = 0) => addDays(today(), n);

const cache = new Map();
const STAFF = ['admin', 'supervisor'];
const LOADERS = {
  groups: () => q(sb.from('groups').select('id,code,label,filiere,year').order('code')),
  modules: () => q(sb.from('modules').select('id,code,name').order('code')),
  rooms: () => q(sb.from('rooms').select('id,name,kind,capacity').order('name')),
  people: () => q(sb.from('people').select('id,full_name,role,group_id').order('full_name')),
  slots: () => q(sb.from('timetable_slots').select('*').order('weekday').order('start_time')),
  versions: () => q(sb.from('timetable_versions').select('id,group_id,version,published_at,changes').order('published_at', { ascending: false }).limit(30)),
  assessments: () => q(sb.from('assessments').select('*').order('due_at')),
  progress: () => q(sb.from('assessment_progress').select('assessment_id,status').eq('student_id', myId())),
  tasks: () => q(sb.from('tasks').select('*').eq('owner_id', myId()).order('due_date', { ascending: true, nullsFirst: false })),
  study: () => q(sb.from('study_sessions').select('*').eq('owner_id', myId()).order('planned_date')),
  announcements: () => q(sb.from('announcements').select('*').order('pinned', { ascending: false }).order('created_at', { ascending: false }).limit(100)),
  // Boîte de réception : le personnel voit (RLS) toutes les notifications de groupe ; on ne lui montre que les siennes et les générales
  notifications: () => { const b = sb.from('notifications').select('*');
    return q((STAFF.includes(store.get().profile?.role) ? b.or(`user_id.eq.${myId()},target_kind.eq.all`) : b).order('created_at', { ascending: false }).limit(100)); },
  // Notifications envoyées (personnel) : collectives + personnelles envoyées par soi
  sent: () => q(sb.from('notifications').select('*').neq('target_kind', 'user').order('created_at', { ascending: false }).limit(200)),
  reads: () => q(sb.from('notification_reads').select('notification_id').eq('user_id', myId())),
  attendance: () => q(sb.from('attendance_records').select('*').order('recorded_at', { ascending: false })),
  sessions: () => q(sb.from('class_sessions').select('*').order('session_date', { ascending: false }).limit(500)),
  summary: () => q(sb.from('attendance_summary').select('*')),
  justifications: () => q(sb.from('absence_justifications').select('*').order('created_at', { ascending: false })),
  resources: () => q(sb.from('resources').select('*').is('assessment_id', null).order('created_at', { ascending: false })),
  posts: () => q(sb.from('posts_feed').select('*').order('created_at', { ascending: false }).limit(200)),
  studyGroups: () => q(sb.from('study_groups').select('*').order('meet_date').order('start_time')),
  sgMembers: () => q(sb.from('study_group_members').select('study_group_id,user_id')),
  rides: () => q(sb.from('rides').select('*').order('depart_at')),
  bookings: () => q(sb.from('ride_bookings').select('ride_id,user_id')),
  teaching: () => q(sb.from('teaching_assignments').select('group_id,module_id,teacher_id')),
  exceptions: () => q(sb.from('session_exceptions').select('*').gte('session_date', todayISO(-14)).order('session_date')),
  calendar: () => q(sb.from('calendar_events').select('*').order('start_date')),
  submissions: () => q(sb.from('submissions').select('*')),
  attachments: () => q(sb.from('resources').select('*').not('assessment_id', 'is', null)),
};
export const data = {
  get(key) {
    if (!cache.has(key)) cache.set(key, LOADERS[key]().catch((e) => { cache.delete(key); throw e; }));
    return cache.get(key);
  },
  all: (...keys) => Promise.all(keys.map((k) => data.get(k))),
  invalidate: (...keys) => keys.forEach((k) => cache.delete(k)),
  clear: () => cache.clear(),
};
export async function loadRef() {
  const [groups, modules, rooms, people] = await data.all('groups', 'modules', 'rooms', 'people');
  store.set({ ref: { groups, modules, rooms, people } });
}
// Table → clés de cache touchées (temps réel)
export const TABLE_KEYS = {
  notifications: ['notifications', 'sent'], announcements: ['announcements'], assessments: ['assessments'],
  timetable_slots: ['slots', 'versions'], timetable_versions: ['versions'], session_exceptions: ['exceptions'], calendar_events: ['calendar'], submissions: ['submissions'], attendance_records: ['attendance', 'summary', 'sessions'], replies: [],
  study_groups: ['studyGroups'], study_group_members: ['sgMembers'], rides: ['rides'], ride_bookings: ['bookings'], resources: ['resources', 'attachments'],
};
export async function refreshUnread() {
  const [n, r] = await data.all('notifications', 'reads');
  const read = new Set(r.map((x) => x.notification_id));
  store.set({ unread: n.filter((x) => !read.has(x.id)).length });
}
