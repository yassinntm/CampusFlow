// Dates : tout est calculé dans le fuseau de l'établissement (Africa/Casablanca), quel que soit le fuseau du téléphone.
export const TZ = 'Africa/Casablanca';
const pad = (n) => String(n).padStart(2, '0');

// Date du jour 'YYYY-MM-DD' à Agadir
export const todayISO = (d = new Date()) => new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
// Minutes écoulées depuis minuit à Agadir
export const nowMinutes = (d = new Date()) => {
  const [h, m] = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d).split(':').map(Number);
  return h * 60 + m;
};
// Opérations sur des dates civiles ISO (sans heure, donc sans piège de fuseau)
const toUTC = (iso) => { const [y, m, d] = iso.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)); };
const fromUTC = (dt) => `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
export const addDays = (iso, n) => { const d = toUTC(iso); d.setUTCDate(d.getUTCDate() + n); return fromUTC(d); };
export const isoWeekday = (iso) => ((toUTC(iso).getUTCDay() + 6) % 7) + 1;           // 1 = lundi … 7 = dimanche
export const mondayOf = (iso) => addDays(iso, 1 - isoWeekday(iso));
export const diffDays = (a, b) => Math.round((toUTC(b) - toUTC(a)) / 864e5);
export const monthGrid = (iso) => {                                                       // 6 semaines × 7 jours à partir du lundi
  const first = iso.slice(0, 8) + '01';
  const start = mondayOf(first);
  return Array.from({ length: 42 }, (_, i) => addDays(start, i));
};
// Heures 'HH:MM[:SS]' ↔ minutes
export const hm = (t) => (t ? String(t).slice(0, 5) : '');
export const toMin = (t) => { const [h, m] = String(t).split(':').map(Number); return h * 60 + m; };
export const fromMin = (m) => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
// Instant (timestamptz) → date civile et heure à Agadir
export const isoOfInstant = (ts) => todayISO(new Date(ts));
export const timeOfInstant = (ts) => new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(ts));
// Saisie locale (date + heure à Agadir) → instant ISO. Le Maroc est en UTC+1 toute l'année sauf pendant le Ramadan (UTC+0) :
// on calcule le décalage réel du fuseau pour cette date au lieu de le supposer.
export const instantFrom = (dateIso, time) => {
  const guess = new Date(`${dateIso}T${time}:00Z`);
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
    .formatToParts(guess).map((p) => [p.type, p.value]));
  const local = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute);
  return new Date(guess.getTime() - (local - guess.getTime())).toISOString();
};
