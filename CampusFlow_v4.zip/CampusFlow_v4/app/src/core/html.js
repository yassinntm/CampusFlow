// Gabarits HTML sûrs : toute valeur interpolée est échappée par défaut (protection XSS).
// Seul raw() permet d'injecter du HTML, et il n'est utilisé que pour du contenu statique de l'application (icônes, gabarits).
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' };
export const esc = (v) => String(v ?? '').replace(/[&<>"'`]/g, (c) => ESC[c]);

class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
export const raw = (s) => new Raw(String(s));
export const isRaw = (v) => v instanceof Raw;

const conv = (v) => (v == null || v === false ? '' : v instanceof Raw ? v.s : Array.isArray(v) ? v.map(conv).join('') : esc(v));
export const html = (strings, ...vals) => new Raw(strings.reduce((acc, s, i) => acc + s + (i < vals.length ? conv(vals[i]) : ''), ''));

export const mount = (el, tpl) => { el.innerHTML = conv(tpl); };

// Liens externes : seulement https (pas de javascript:, data:, etc.)
export const safeUrl = (u) => (typeof u === 'string' && /^https:\/\/[^\s"'<>]+$/i.test(u) ? u : '#');
