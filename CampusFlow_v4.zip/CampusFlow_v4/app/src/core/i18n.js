// Traductions FR/AR, sens d'écriture (RTL) et formats de dates selon la langue
import fr from '../i18n/fr.js';
import ar from '../i18n/ar.js';
import { TZ } from './dates.js';

const DICTS = { fr, ar };
let lang = 'fr';

export const getLang = () => lang;
export const isRTL = () => lang === 'ar';
export const setLang = (l) => {
  lang = DICTS[l] ? l : 'fr';
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
};
export const t = (key, vars) => {
  let s = DICTS[lang][key] ?? DICTS.fr[key];
  if (s == null) { if (import.meta.env?.DEV) console.warn('i18n manquant:', key); s = key; }
  return vars ? s.replace(/\{(\w+)\}/g, (m, k) => (vars[k] ?? m)) : s;
};
// Chiffres latins dans les deux langues (usage marocain)
const locale = () => (lang === 'ar' ? 'ar-MA-u-nu-latn' : 'fr-MA');
export const fmtDate = (iso, opts = { weekday: 'long', day: 'numeric', month: 'long' }) => {
  const [y, m, d] = iso.split('-').map(Number);
  return new Intl.DateTimeFormat(locale(), { ...opts, timeZone: 'UTC' }).format(new Date(Date.UTC(y, m - 1, d)));
};
export const fmtInstant = (ts, opts = { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) =>
  new Intl.DateTimeFormat(locale(), { ...opts, timeZone: TZ, hourCycle: 'h23' }).format(new Date(ts));
export const dayName = (wd, style = 'long') => fmtDate(['2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19', '2026-11-20', '2026-11-21', '2026-11-22'][wd - 1], { weekday: style });
export const fmtNum = (n, opts) => new Intl.NumberFormat(locale(), opts).format(n);
export const ago = (ts) => {
  const s = Math.round((Date.now() - new Date(ts)) / 1000);
  const rtf = new Intl.RelativeTimeFormat(locale(), { numeric: 'auto' });
  if (s < 60) return rtf.format(0, 'second');
  if (s < 3600) return rtf.format(-Math.floor(s / 60), 'minute');
  if (s < 86400) return rtf.format(-Math.floor(s / 3600), 'hour');
  if (s < 86400 * 7) return rtf.format(-Math.floor(s / 86400), 'day');
  return fmtInstant(ts, { day: 'numeric', month: 'short' });
};
export const dictionaries = DICTS;
