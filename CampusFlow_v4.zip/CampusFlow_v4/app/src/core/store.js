// État global minimal + abonnement (aucune donnée sensible n'est persistée localement, sauf langue/thème)
const state = {
  session: null, profile: null, settings: {},
  ref: { groups: [], modules: [], rooms: [], people: [] },
  unread: 0, online: navigator.onLine,
};
const subs = new Set();
export const store = {
  get: () => state,
  set(patch) { Object.assign(state, patch); subs.forEach((f) => f(state)); },
  on(f) { subs.add(f); return () => subs.delete(f); },
};
export const me = () => state.profile;
export const myId = () => state.session?.user?.id || null;
export const role = () => state.profile?.role;
export const pref = {
  get: (k, d) => { try { return localStorage.getItem('cf.' + k) ?? d; } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem('cf.' + k, v); } catch { /* stockage indisponible */ } },
};
// Accès rapide aux données de référence (jointures côté client, pas d'« embed » PostgREST)
export const ref = {
  module: (id) => state.ref.modules.find((m) => m.id === id),
  room: (id) => state.ref.rooms.find((r) => r.id === id),
  group: (id) => state.ref.groups.find((g) => g.id === id),
  person: (id) => state.ref.people.find((p) => p.id === id),
  moduleName: (id) => state.ref.modules.find((m) => m.id === id)?.name || '—',
  roomName: (id) => state.ref.rooms.find((r) => r.id === id)?.name || '',
  personName: (id) => state.ref.people.find((p) => p.id === id)?.full_name || '',
  groupCode: (id) => state.ref.groups.find((g) => g.id === id)?.code || '',
};
