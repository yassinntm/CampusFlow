// Composants d'interface : toasts, fenêtres modales, confirmation, formulaires, états vides
import { html, mount } from './html.js';
import { icon } from './icons.js';
import { t } from './i18n.js';

export const toast = (title, body = '', kind = 'info') => {
  const box = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  mount(el, html`<div class="ti">${icon(kind === 'error' ? 'alert' : kind === 'ok' ? 'check' : 'bell', 18)}</div><div><b>${title}</b>${body ? html`<div>${body}</div>` : ''}</div>`);
  box.appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 6000 : 3500);
};
export const toastError = (e) => toast(t('common.error'), e?.message || String(e), 'error');

// Fenêtre modale accessible (Échap, clic à l'extérieur, focus sur le premier champ)
let current = null;
export const closeModal = () => {
  if (!current) return;
  current.el.remove(); document.removeEventListener('keydown', current.onKey);
  const back = current.prevFocus; current = null; back?.focus?.();
};
// Changer de page ferme la fenêtre ouverte (sinon elle masquerait la nouvelle page)
window.addEventListener('hashchange', () => closeModal());
export const openModal = (title, body, { onMount, wide } = {}) => {
  closeModal();
  const root = document.getElementById('modal-root');
  const el = document.createElement('div');
  el.className = 'overlay';
  mount(el, html`<div class="sheet ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${title}">
    <div class="sheet-h"><h2>${title}</h2><button class="icon-btn" data-close aria-label="${t('common.close')}">${icon('x')}</button></div>
    <div class="sheet-b">${body}</div></div>`);
  el.addEventListener('click', (e) => { if (e.target === el || e.target.closest('[data-close]')) closeModal(); });
  const onKey = (e) => { if (e.key === 'Escape') closeModal(); };
  document.addEventListener('keydown', onKey);
  current = { el, onKey, prevFocus: document.activeElement };
  root.appendChild(el);
  el.querySelector('input,select,textarea,button:not([data-close])')?.focus();
  onMount?.(el.querySelector('.sheet'));
  return el.querySelector('.sheet');
};
export const confirmBox = (message, { danger = true, ok = t('common.confirm') } = {}) => new Promise((resolve) => {
  const sheet = openModal(t('common.confirm_title'), html`<p class="muted">${message}</p>
    <div class="row gap mt"><button class="btn ghost block" data-no>${t('common.cancel')}</button><button class="btn ${danger ? 'danger' : 'primary'} block" data-yes>${ok}</button></div>`);
  sheet.querySelector('[data-yes]').onclick = () => { closeModal(); resolve(true); };
  sheet.querySelector('[data-no]').onclick = () => { closeModal(); resolve(false); };
});

// Lecture d'un formulaire en objet (champs vides → null)
export const formData = (form) => {
  const o = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') o[el.name] = el.checked;
    else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
    else o[el.name] = el.value.trim() === '' ? null : el.value.trim();
  }
  return o;
};
// Exécute une action en désactivant le bouton (évite les doubles envois)
export const busy = async (btn, fn) => {
  if (btn?.disabled) return;
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toastError(e); } finally { if (btn) btn.disabled = false; }
};
export const empty = (msg, ic = 'list') => html`<div class="empty">${icon(ic, 36)}<div>${msg}</div></div>`;
export const loading = () => html`<div class="empty"><div class="spinner" aria-label="${t('common.loading')}"></div></div>`;
export const options = (list, sel, label = (x) => x.label, value = (x) => x.id) =>
  list.map((x) => html`<option value="${value(x)}" ${String(value(x)) === String(sel ?? '') ? 'selected' : ''}>${label(x)}</option>`);
export const chip = (text, cls = '') => html`<span class="chip ${cls}">${text}</span>`;
