// Routeur par ancre (#/page/param). Chaque vue reçoit un conteneur neuf : pas d'écouteurs qui s'accumulent.
const routes = new Map();
let layout = null;
let token = 0;
let hard = 0;              // affichages demandés par l'utilisateur en cours
let lastKey = null;
export const route = (name, view) => routes.set(name, view);
export const setLayout = (fn) => { layout = fn; };
export const current = () => {
  const [name = '', ...rest] = location.hash.replace(/^#\/?/, '').split('/');
  return { name: name || 'home', param: rest.length ? decodeURIComponent(rest.join('/')) : null };
};
export const go = (name, param) => { const h = '#/' + name + (param ? '/' + encodeURIComponent(param) : ''); if (location.hash === h) render(); else location.hash = h; };
export const hasRoute = (name) => routes.has(name);
export async function render(opts = {}) {
  // une mise à jour automatique ne doit jamais annuler un affichage demandé par l'utilisateur (navigation, enregistrement)
  if (opts.soft && hard > 0) return;
  const my = ++token;
  if (!opts.soft) hard++;
  try { await draw(opts, my); } finally { if (!opts.soft) hard--; }
}
async function draw(opts, my) {
  const { name, param } = current();
  const view = routes.get(name) || routes.get('home');
  if (!layout || !view) return;
  const key = name + '/' + (param || '');
  const keepScroll = key === lastKey;               // même page (changement d'onglet, temps réel) : on garde la position
  const y = window.scrollY;
  lastKey = key;
  // La vue est construite hors de la page puis insérée d'un coup : l'ancienne page reste affichée pendant le chargement
  // (pas d'écran blanc lors des mises à jour en temps réel)
  const el = document.createElement('div');
  el.className = 'view';
  try { await view.render(el, param, () => my === token); }
  catch (e) { console.error(e); el.textContent = e.message; }
  if (my !== token) return;
  // Mise à jour automatique (temps réel) : on ne remplace pas une page dont un formulaire est en cours de saisie
  if (opts.soft && document.querySelector('.view[data-dirty]')) return;
  const host = layout(name, view);              // la mise en page renvoie le conteneur de contenu
  if (!host) return;
  host.replaceChildren(el);
  window.scrollTo?.(0, keepScroll ? y : 0);
}
window.addEventListener('hashchange', render);
// Délégation d'événements : on(root, 'click', '[data-act=save]', (e, el) => …)
export const on = (root, type, sel, fn) => root.addEventListener(type, (e) => { const el = e.target.closest(sel); if (el && root.contains(el)) fn(e, el); });
