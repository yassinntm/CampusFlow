// Devoirs (structure de la démo : « Cette semaine / À venir », regroupés par jour) + fiche détaillée avec pièces jointes,
// suivi, rendu (texte, lien, fichier) et retour du formateur. Examens : dates, salles, préparation.
import { html, mount, safeUrl } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, fmtInstant, ago } from '../../core/i18n.js';
import { ref, myId } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, mondayOf, addDays, isoOfInstant, diffDays } from '../../core/dates.js';
import { openModal, closeModal, busy, toast, confirmBox } from '../../core/ui.js';
import { assignItem } from '../../shared/components.js';
import { topbar, wireTopbar } from '../ui.js';
import { teacherOf } from './home.js';
import { suggestStudy } from './planner.js';

const NEXT = { todo: 'in_progress', in_progress: 'done', done: 'todo' };
const MAX = 10 * 1024 * 1024;
const st = { tab: 'week' };

export const openAttachment = async (r) => {
  if (r.kind === 'link') { window.open(safeUrl(r.url), '_blank', 'noopener'); return; }
  const { data: d, error } = await sb.storage.from('resources').createSignedUrl(r.storage_path, 300);
  if (error) throw error;
  window.open(d.signedUrl, '_blank', 'noopener');
};

// Fiche d'un devoir / examen
export async function openAssessment(id) {
  const [assessments, progress, attachments, slots, subs] = await data.all('assessments', 'progress', 'attachments', 'slots', 'submissions');
  const a = assessments.find((x) => x.id === id);
  if (!a) return;
  const status = progress.find((p) => p.assessment_id === id)?.status || 'todo';
  const files = attachments.filter((r) => r.assessment_id === id);
  const sub = subs.find((s) => s.assessment_id === id && s.student_id === myId());
  const late = sub && new Date(sub.submitted_at) > new Date(a.due_at);
  const sheet = openModal(a.title, html`<div class="stack">
    <div class="row wrap"><span class="chip ${a.kind === 'exam' ? 'red' : 'amber'}">${t('assess.' + a.kind)}</span><span class="chip">${ref.moduleName(a.module_id)}</span>
      ${teacherOf(a, slots) ? html`<span class="chip">${icon('user', 12)} ${teacherOf(a, slots)}</span>` : ''}</div>
    <div class="kv"><span>${t(a.kind === 'exam' ? 'assess.exam_date' : 'assess.due_date')}</span><b>${fmtInstant(a.due_at, { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}</b></div>
    ${a.room_id ? html`<div class="kv"><span>${t('common.room')}</span><b>${ref.roomName(a.room_id)}</b></div>` : ''}
    ${a.duration_min ? html`<div class="kv"><span>${t('assess.duration_label')}</span><b>${t('assess.duration', { n: a.duration_min })}</b></div>` : ''}
    ${a.description ? html`<div><div class="xs muted b">${t('assess.description')}</div><p class="pre mt-s">${a.description}</p></div>` : ''}
    ${files.length ? html`<div><div class="xs muted b">${t('assess.attachments')}</div><div class="stack mt-s">${files.map((r) => html`<button class="item text-start" data-att="${r.id}">
      <div class="ii bg-violet">${icon(r.kind === 'file' ? 'file' : 'link', 18)}</div><div class="grow"><div class="item-t">${r.title}</div>${r.description ? html`<div class="item-b">${r.description}</div>` : ''}</div>${icon('down', 16)}</button>`)}</div></div>` : ''}
    <div><div class="xs muted b">${t('assess.my_progress')}</div><div class="seg full mt-s">${['todo', 'in_progress', 'done'].map((k) => html`<button class="${status === k ? 'on' : ''}" data-set="${k}">${t('progress.' + k)}</button>`)}</div></div>
    ${a.kind === 'assignment' ? html`<div class="card sub-card"><div class="between"><b>${t('sub.title')}</b>${sub ? html`<span class="chip ${late ? 'amber' : 'green'}">${t(late ? 'sub.late' : 'sub.sent')} · ${ago(sub.submitted_at)}</span>` : html`<span class="chip">${t('sub.none')}</span>`}</div>
      ${sub?.feedback_at ? html`<div class="okbox mt-s feedback"><div><b>${t('sub.feedback')}</b>${sub.grade ? html` · <span class="chip green">${sub.grade}</span>` : ''}<p class="pre mt-s">${sub.feedback}</p><div class="xs muted">${ref.personName(sub.feedback_by)} · ${ago(sub.feedback_at)}</div></div></div>` : ''}
      ${sub && (sub.content || sub.link || sub.file_name) ? html`<div class="mt-s small">${sub.content ? html`<p class="pre">${sub.content}</p>` : ''}${sub.link ? html`<a class="link" href="${safeUrl(sub.link)}" target="_blank" rel="noopener noreferrer">${icon('link', 14)} ${sub.link}</a>` : ''}
        ${sub.file_name ? html`<button class="link" data-myfile>${icon('file', 14)} ${sub.file_name}</button>` : ''}</div>` : ''}
      ${sub?.feedback_at ? '' : html`<form class="stack mt" data-sub novalidate>
        <textarea class="input" name="content" rows="3" maxlength="5000" placeholder="${t('sub.content_ph')}">${sub?.content || ''}</textarea>
        <input class="input" name="link" type="url" placeholder="https://… (${t('sub.link_ph')})" value="${sub?.link || ''}">
        <div class="field"><label class="xs muted">${t('sub.file')}</label><input class="input" type="file" name="file" accept=".pdf,.zip,.png,.jpg,.jpeg,.txt,.docx,.pptx,.xlsx"><small class="muted">${t('sub.file_rules')}</small></div>
        <button class="btn primary block">${icon('send', 16)} ${t(sub ? 'sub.update' : 'sub.send')}</button></form>`}</div>` : html`<div class="card">${t('assess.exam_prep_help')}</div>`}
  </div>`, { wide: true });
  sheet.querySelectorAll('[data-att]').forEach((b) => (b.onclick = () => busy(b, () => openAttachment(files.find((r) => r.id === b.dataset.att)))));
  sheet.querySelectorAll('[data-set]').forEach((b) => (b.onclick = () => busy(b, async () => {
    await q(sb.from('assessment_progress').upsert({ assessment_id: id, student_id: myId(), status: b.dataset.set }, { onConflict: 'assessment_id,student_id' }));
    data.invalidate('progress'); closeModal(); render(); openAssessment(id);
  })));
  sheet.querySelector('[data-myfile]')?.addEventListener('click', (e) => busy(e.currentTarget, async () => {
    const { data: d, error } = await sb.storage.from('submissions').createSignedUrl(sub.storage_path, 300); if (error) throw error; window.open(d.signedUrl, '_blank', 'noopener');
  }));
  const f = sheet.querySelector('[data-sub]');
  f?.addEventListener('submit', (e) => { e.preventDefault(); busy(f.querySelector('button'), async () => {
    const content = f.content.value.trim() || null; const link = f.link.value.trim() || null; const file = f.file.files[0];
    if (link && safeUrl(link) === '#') throw new Error(t('res.https_only'));
    if (!content && !link && !file && !sub) throw new Error(t('sub.empty'));
    const row = { assessment_id: id, content, link };
    if (file) {
      if (file.size > MAX) throw new Error(t('sub.too_big'));
      const path = `${myId()}/${id}/${crypto.randomUUID()}-${file.name.normalize('NFD').replace(/[^\w.-]+/g, '_').slice(-80)}`;
      const { error } = await sb.storage.from('submissions').upload(path, file, { contentType: file.type, upsert: false });
      if (error) throw new Error(/mime|type/i.test(error.message) ? t('res.bad_type') : error.message);
      Object.assign(row, { storage_path: path, file_name: file.name.slice(0, 200) });
    }
    if (sub) await q(sb.from('submissions').update({ content: row.content, link: row.link, ...(file ? { storage_path: row.storage_path, file_name: row.file_name } : {}) }).eq('assessment_id', id).eq('student_id', myId()));
    else await q(sb.from('submissions').insert(row));
    if (status !== 'done') await q(sb.from('assessment_progress').upsert({ assessment_id: id, student_id: myId(), status: 'done' }, { onConflict: 'assessment_id,student_id' }));
    data.invalidate('submissions', 'progress'); closeModal(); render(); toast(t('sub.sent'), t('sub.sent_toast'), 'ok');
  }); });
}

export const assignmentsView = {
  title: 'nav.assignments',
  async render(el) {
    const [assessments, progress, slots, subs] = await data.all('assessments', 'progress', 'slots', 'submissions');
    const status = (a) => progress.find((p) => p.assessment_id === a.id)?.status || 'todo';
    const all = assessments.filter((a) => a.kind === 'assignment');
    const today = todayISO(); const mon = mondayOf(today); const sat = addDays(mon, 6);
    const list = st.tab === 'week' ? all.filter((a) => { const d = isoOfInstant(a.due_at); return d >= mon && d <= sat; })
      : st.tab === 'up' ? all.filter((a) => isoOfInstant(a.due_at) > sat) : all.filter((a) => isoOfInstant(a.due_at) < today).reverse();
    const byDay = {}; list.forEach((a) => (byDay[isoOfInstant(a.due_at)] ||= []).push(a));
    const subChip = (a) => { const s = subs.find((x) => x.assessment_id === a.id); return s ? html`<span class="chip ${s.feedback_at ? 'green' : 'blue'}">${t(s.feedback_at ? 'sub.feedback_short' : 'sub.sent')}</span>` : ''; };
    mount(el, html`${topbar(t('nav.assignments'))}
      <div class="seg">${['week', 'up', 'past'].map((k) => html`<button class="${st.tab === k ? 'on' : ''}" data-tab="${k}">${t('assign.tab_' + k)}</button>`)}</div>
      ${Object.keys(byDay).length ? Object.entries(byDay).map(([d, arr]) => html`<div class="day-h">${fmtDate(d)}${d < today ? ' · ✓' : ''}</div>
        <div class="stack">${arr.map((a) => assignItem(a, { status: status(a), teacher: teacherOf(a, slots), extra: subChip(a), onClick: true }))}</div>`)
        : html`<div class="card empty mt">${icon('book', 28)}${t('assign.none_' + st.tab)}</div>`}`);
    wireTopbar(el);
    on(el, 'click', '[data-tab]', (_e, b) => { st.tab = b.dataset.tab; render(); });
    on(el, 'click', '[data-open]', (_e, b) => openAssessment(b.dataset.open));
    on(el, 'keydown', '[data-open]', (e, b) => { if (e.key === 'Enter') openAssessment(b.dataset.open); });
  },
};

export const examsView = {
  title: 'nav.exams',
  async render(el) {
    const [assessments, progress, slots, study] = await data.all('assessments', 'progress', 'slots', 'study');
    const exams = assessments.filter((a) => a.kind === 'exam');
    const up = exams.filter((a) => new Date(a.due_at) > new Date()); const past = exams.filter((a) => new Date(a.due_at) <= new Date()).reverse();
    const status = (a) => progress.find((p) => p.assessment_id === a.id)?.status || 'todo';
    const prep = (a) => study.filter((s) => s.subject === t('plan.revise', { title: a.title }));
    mount(el, html`${topbar(t('nav.exams'))}
      <div class="stack">${up.length ? up.map((a) => { const d = diffDays(todayISO(), isoOfInstant(a.due_at)); const ps = prep(a); const doneMin = ps.filter((s) => s.done).reduce((x, s) => x + s.duration_min, 0);
        return html`<div class="card exam-card"><div class="between top-start"><div><div class="item-t">${a.title}</div><div class="item-b">${ref.moduleName(a.module_id)}${teacherOf(a, slots) ? ' · ' + teacherOf(a, slots) : ''}</div></div>
            <div class="exam-days"><b>${d === 0 ? t('due.today') : d}</b>${d === 0 ? '' : html`<span>${t('exam.days')}</span>`}</div></div>
          <div class="row wrap chips"><span class="chip">${icon('cal', 12)} ${fmtInstant(a.due_at, { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}</span>
            ${a.room_id ? html`<span class="chip">${icon('pin', 12)} ${ref.roomName(a.room_id)}</span>` : ''}${a.duration_min ? html`<span class="chip">${icon('clock', 12)} ${t('assess.duration', { n: a.duration_min })}</span>` : ''}</div>
          <div class="divider"></div>
          <div class="between wrap"><div class="small"><b>${t('exam.prep')}</b> · ${t('progress.' + status(a))} · ${t('exam.prep_sessions', { n: ps.length, min: doneMin })}</div>
            <div class="row"><button class="btn sm ghost" data-open="${a.id}">${icon('eye', 14)} ${t('common.details')}</button><button class="btn sm primary" data-plan="${a.id}">${icon('spark', 14)} ${t('exam.plan')}</button></div></div></div>`; })
        : html`<div class="card empty">${icon('target', 28)}${t('exam.none')}</div>`}</div>
      ${past.length ? html`<details class="sec"><summary class="muted">${t('exam.past', { n: past.length })}</summary><div class="stack mt-s">${past.map((a) => assignItem(a, { onClick: true }))}</div></details>` : ''}`);
    wireTopbar(el);
    on(el, 'click', '[data-open]', (_e, b) => openAssessment(b.dataset.open));
    on(el, 'click', '[data-plan]', (_e, b) => busy(b, async () => {
      const a = exams.find((x) => x.id === b.dataset.plan);
      const props = suggestStudy([a], slots, study);
      if (!props.length) return toast(t('plan.suggest_none'));
      if (!(await confirmBox(t('exam.plan_confirm', { n: props.length, dates: props.map((p) => fmtDate(p.planned_date, { weekday: 'short', day: 'numeric' }) + ' ' + p.start_time).join(', ') }), { danger: false, ok: t('plan.add_selected') }))) return;
      await q(sb.from('study_sessions').insert(props)); data.invalidate('study'); render(); toast(t('plan.added', { n: props.length }), '', 'ok');
    }));
  },
};
