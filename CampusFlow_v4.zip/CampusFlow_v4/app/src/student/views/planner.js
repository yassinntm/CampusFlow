// Planner — les 4 onglets de la démo d'origine : Départ, Calendrier, Tâches, Étude (données enregistrées sur le compte)
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, dayName } from '../../core/i18n.js';
import { store, ref, me, myId } from '../../core/store.js';
import { on, render, go } from '../../core/router.js';
import { sb, q } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, mondayOf, monthGrid, isoWeekday, hm, toMin, fromMin, nowMinutes, isoOfInstant, diffDays, instantFrom } from '../../core/dates.js';
import { busy, toast, formData, options } from '../../core/ui.js';
import { effectiveSlots } from '../../shared/components.js';
import { topbar, wireTopbar } from '../ui.js';
import { fmtCountdown } from './home.js';

export const DEP_DEFAULTS = { usual: '07:40', journey: 25, margin: 10, interval: 15, depRem: true, classRem: true };
export const depPrefs = () => ({ ...DEP_DEFAULTS, ...(store.get().settings.departure || {}) });
export const saveSettings = async (patch) => {
  const settings = { ...store.get().settings, ...patch };
  await q(sb.from('user_settings').upsert({ user_id: myId(), data: settings }, { onConflict: 'user_id' }));
  store.set({ settings });
};

// Prochain départ : premier cours actif du prochain jour de classe (annulations ponctuelles comprises)
export function departureInfo(slots, exceptions, p = depPrefs()) {
  const today = todayISO(); const nm = nowMinutes();
  for (let i = 0; i < 8; i++) {
    const iso = addDays(today, i);
    if (isoWeekday(iso) === 7) continue;
    const list = effectiveSlots(slots, exceptions, iso).filter((s) => s.status === 'active');
    if (!list.length) continue;
    const first = list[0]; const fs = toMin(first.start_time);
    if (i === 0 && fs <= nm) continue;
    const leaveMin = fs - Number(p.journey) - Number(p.margin);
    return { iso, first, leaveMin, arriveMin: leaveMin + Number(p.journey), isToday: i === 0, leaveAt: new Date(instantFrom(iso, fromMin(Math.max(0, leaveMin)))).getTime() };
  }
  return null;
}

// Propose des révisions avant les examens des 14 prochains jours, dans les heures libres (pas pendant les cours)
export function suggestStudy(assessments, slots, existing, exceptions = []) {
  const today = todayISO(); const out = [];
  for (const a of assessments) {
    const day = isoOfInstant(a.due_at); const dd = diffDays(today, day);
    if (a.kind !== 'exam' || dd < 1 || dd > 14) continue;
    const subject = t('plan.revise', { title: a.title });
    if (existing.some((s) => s.subject === subject)) continue;
    for (const back of [3, 1]) {
      const d = addDays(day, -back);
      if (d < today || isoWeekday(d) === 7) continue;
      const busyUntil = Math.max(0, ...effectiveSlots(slots, exceptions, d).filter((s) => s.status === 'active').map((s) => toMin(s.end_time)));
      const start = Math.max(busyUntil + 60, 17 * 60);
      if (start > 21 * 60) continue;
      out.push({ subject, planned_date: d, start_time: fromMin(start), duration_min: 60, module_id: a.module_id });
    }
  }
  return out;
}

const st = { cal: 'month', date: null };
const PR = { high: 'high', normal: 'med', low: 'low' };

export const plannerView = {
  title: 'nav.planner',
  async render(el, param, alive) {
    const tab = ['day', 'cal', 'todo', 'study'].includes(param) ? param : 'day';
    const tabs = [['day', 'plan.departure'], ['cal', 'tile.calendar'], ['todo', 'tile.tasks'], ['study', 'plan.study']];
    const [slots, exceptions] = await data.all('slots', 'exceptions');
    const mine = slots.filter((s) => s.group_id === me().group_id);
    let body;
    if (tab === 'day') body = renderDeparture(mine, exceptions);
    else if (tab === 'cal') body = await renderCalendar(mine, exceptions);
    else if (tab === 'todo') body = await renderTodo();
    else body = await renderStudy(mine, exceptions);
    mount(el, html`${topbar(t('nav.planner'))}
      <div class="tabs mb">${tabs.map(([k, l]) => html`<a class="tab ${tab === k ? 'on' : ''}" href="#/planner/${k}">${t(l)}</a>`)}</div>${body}`);
    wireTopbar(el);
    bind(el, tab, mine, exceptions, alive);
  },
};

function renderDeparture(mine, exceptions) {
  const p = depPrefs(); const d = departureInfo(mine, exceptions, p); const nm = nowMinutes();
  let main = html`<div class="card empty">${t('home.no_class')}</div>`;
  if (d) {
    const usualDiff = toMin(p.usual) - d.leaveMin;
    const fs = toMin(d.first.start_time);
    const tl = [[d.leaveMin - Number(p.interval), t('plan.reminder_at', { n: p.interval })], [d.leaveMin, t('plan.departure')], [d.arriveMin, t('plan.arrive')],
      [fs - Number(p.interval), t('plan.reminder_class', { m: ref.moduleName(d.first.module_id) })], [fs, t('plan.class_start', { room: ref.roomName(d.first.room_id) || '—' })]].sort((a, b) => a[0] - b[0]);
    main = html`<div class="card">
      <div class="dep"><div class="ii bg-blue dep-ic">${icon('walk', 28)}</div>
        <div><div class="xs muted b">${t('plan.leave_at')} · ${d.isToday ? t('due.today') : fmtDate(d.iso, { weekday: 'long', day: 'numeric' })}</div>
        <div class="dep-time">${fromMin(Math.max(0, d.leaveMin))}</div>
        <div class="small muted">${t('plan.for_class', { m: ref.moduleName(d.first.module_id), time: hm(d.first.start_time) })}</div></div></div>
      <div class="divider"></div>
      <div class="between small"><span class="muted">${t('plan.leave_in')}</span><b class="countdown dep-cd" data-cd="${d.leaveAt}">${fmtCountdown(d.leaveAt - Date.now())}</b></div>
      ${p.usual ? (usualDiff > 0 ? html`<div class="warn mt">${icon('alert', 16)}<span>${t('plan.late_risk', { n: usualDiff, usual: p.usual })}</span></div>`
        : html`<div class="ok-line mt">${icon('check', 16)} ${t('plan.on_time', { n: -usualDiff + Number(p.margin) })}</div>`) : ''}
    </div>
    <div class="card sec"><h3 class="mb-s">${fmtDate(d.iso, { weekday: 'long' })}</h3>
      <div class="timeline">${tl.map(([m, l]) => html`<div class="tl ${d.isToday && m < nm ? 'past' : ''}"><b>${fromMin(Math.max(0, m))}</b> — ${l}</div>`)}</div></div>`;
  }
  return html`${main}
    <form class="card sec stack" data-dep><h3>${t('plan.my_settings')}</h3>
      <div class="grid2"><div class="field"><label>${t('plan.usual')}</label><input class="input" type="time" name="usual" value="${p.usual}"></div>
        <div class="field"><label>${t('plan.journey')}</label><input class="input" type="number" min="1" max="240" name="journey" value="${p.journey}"></div>
        <div class="field"><label>${t('plan.margin')}</label><input class="input" type="number" min="0" max="60" name="margin" value="${p.margin}"></div>
        <div class="field"><label>${t('plan.interval')}</label><select class="input" name="interval">${[30, 15, 10, 5].map((v) => html`<option value="${v}" ${Number(p.interval) === v ? 'selected' : ''}>${t('time.min', { n: v })}</option>`)}</select></div></div>
      <label class="between"><span class="small">${t('plan.dep_rem')}</span><span class="switch"><input type="checkbox" name="depRem" ${p.depRem ? 'checked' : ''}><span></span></span></label>
      <label class="between"><span class="small">${t('plan.class_rem')}</span><span class="switch"><input type="checkbox" name="classRem" ${p.classRem ? 'checked' : ''}><span></span></span></label>
      <p class="xs muted">${t('plan.reminders_honest')}</p></form>`;
}

async function itemsLoader() {
  const [assessments, tasks, study, events] = await data.all('assessments', 'tasks', 'study', 'calendar');
  return { assessments, tasks, study, events };
}
function itemsOn(iso, mine, exceptions, x) {
  const out = [];
  if (isoWeekday(iso) < 7) effectiveSlots(mine, exceptions, iso).forEach((s) => out.push({ k: 'c', time: hm(s.start_time), title: ref.moduleName(s.module_id),
    sub: `${ref.roomName(s.room_id)}${s.status === 'cancelled' ? ' · ' + t('slot.cancelled') : s.note ? ' · ' + s.note : ''}`, cls: s.status === 'cancelled' ? 'bg-red' : s.note ? 'bg-amber' : 'bg-blue', ic: 'cal', to: 'schedule' }));
  x.assessments.filter((a) => isoOfInstant(a.due_at) === iso).forEach((a) => out.push({ k: 'a', time: '', title: a.title, sub: `${t('assess.' + a.kind)} · ${ref.moduleName(a.module_id)}`, cls: a.kind === 'exam' ? 'bg-red' : 'bg-amber', ic: a.kind === 'exam' ? 'target' : 'book', to: a.kind === 'exam' ? 'exams' : 'assignments' }));
  x.tasks.filter((k) => k.due_date === iso && !k.done).forEach((k) => out.push({ k: 't', time: '', title: k.title, sub: t('tile.tasks'), cls: 'bg-green', ic: 'check', to: 'planner/todo' }));
  x.study.filter((s) => s.planned_date === iso).forEach((s) => out.push({ k: 's', time: hm(s.start_time), title: s.subject || ref.moduleName(s.module_id), sub: `${t('plan.study')} · ${t('time.min', { n: s.duration_min })}`, cls: 'bg-violet', ic: 'target', to: 'planner/study' }));
  x.events.filter((e) => e.start_date <= iso && e.end_date >= iso).forEach((e) => out.push({ k: 'e', time: '', title: e.title, sub: t('cal.kind_' + e.kind), cls: e.kind === 'holiday' ? 'bg-green' : 'bg-red', ic: 'flag', to: null }));
  return out.sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
}
async function renderCalendar(mine, exceptions) {
  const x = await itemsLoader(); const today = todayISO();
  if (!st.date) st.date = today;
  const sel = st.date;
  const dayList = (iso) => { const it = itemsOn(iso, mine, exceptions, x);
    return it.length ? html`<div class="stack">${it.map((i) => html`<${i.to ? 'a' : 'div'} class="item compact" ${i.to ? html`href="#/${i.to}"` : ''}><div class="ii ${i.cls}">${icon(i.ic, 16)}</div>
      <div class="grow"><div class="item-t">${i.title}</div><div class="item-b xs">${i.time ? i.time + ' · ' : ''}${i.sub}</div></div></${i.to ? 'a' : 'div'}>`)}</div>`
      : html`<div class="card empty small">${t('sched.nothing')}</div>`; };
  const head = html`<div class="between wrap mb"><div class="row"><button class="icon-btn plain" data-move="-1" aria-label="${t('common.previous')}">${icon('chevl', 20, 'class="flip"')}</button>
      <b class="cap">${fmtDate(sel, st.cal === 'month' ? { month: 'long', year: 'numeric' } : st.cal === 'week' ? { day: 'numeric', month: 'long' } : { weekday: 'long', day: 'numeric', month: 'long' })}</b>
      <button class="icon-btn plain" data-move="1" aria-label="${t('common.next')}">${icon('chev', 20, 'class="flip"')}</button></div>
    <div class="seg">${['month', 'week', 'day'].map((v) => html`<button class="${st.cal === v ? 'on' : ''}" data-calview="${v}">${t('sched.' + v)}</button>`)}</div></div>`;
  if (st.cal === 'month') {
    const month = sel.slice(0, 7);
    return html`${head}<div class="card cal-card"><div class="cal">${[1, 2, 3, 4, 5, 6, 7].map((d) => html`<div class="dow">${dayName(d, 'short')}</div>`)}
      ${monthGrid(sel).map((d) => { const ks = [...new Set(itemsOn(d, mine, exceptions, x).map((i) => i.k))];
        return html`<button class="cd ${d.slice(0, 7) !== month ? 'out' : ''} ${d === today ? 'today' : ''} ${d === sel ? 'sel' : ''}" data-pick="${d}">${Number(d.slice(8))}<span class="dots">${ks.map((k) => html`<i class="${k}"></i>`)}</span></button>`; })}</div>
      <div class="row xs muted legend center">${[['c', 'nav.schedule_short'], ['a', 'nav.assignments'], ['t', 'tile.tasks'], ['s', 'plan.study'], ['e', 'cal.events']].map(([k, l]) => html`<span class="row"><span class="dots"><i class="${k}"></i></span>${t(l)}</span>`)}</div></div>
      <div class="day-h">${fmtDate(sel)}</div>${dayList(sel)}`;
  }
  if (st.cal === 'week') {
    const mon = mondayOf(sel);
    return html`${head}${[0, 1, 2, 3, 4, 5, 6].map((i) => { const d = addDays(mon, i); return html`<div class="day-h ${d === today ? 'is-today' : ''}">${fmtDate(d)}</div>${dayList(d)}`; })}`;
  }
  return html`${head}${dayList(sel)}`;
}
async function renderTodo() {
  const tasks = await data.get('tasks');
  const order = { high: 0, normal: 1, low: 2 };
  const list = [...tasks].sort((a, b) => (a.done - b.done) || (order[a.priority] - order[b.priority]) || (a.due_date || '9').localeCompare(b.due_date || '9'));
  const today = todayISO();
  return html`<form data-todo class="card stack mb" novalidate><input class="input" name="title" placeholder="${t('plan.new_task')}" maxlength="140" required aria-label="${t('plan.new_task')}">
      <div class="grid2"><div class="field"><label>${t('plan.due')}</label><input class="input" type="date" name="due_date"></div>
      <div class="field"><label>${t('plan.priority')}</label><select class="input" name="priority"><option value="high">${t('prio.high')}</option><option value="normal" selected>${t('prio.normal')}</option><option value="low">${t('prio.low')}</option></select></div></div>
      <button class="btn primary">${icon('plus', 18)} ${t('common.add')}</button></form>
    <div class="stack">${list.length ? list.map((x) => html`<div class="todo ${x.done ? 'done' : ''}">
      <button class="cbox ${x.done ? 'on' : ''}" data-toggle="${x.id}" aria-label="${t('plan.toggle')}" aria-pressed="${x.done}">${x.done ? icon('check', 14) : ''}</button>
      <div class="grow"><div class="todo-t b">${x.title}</div><div class="row xs muted gap-s"><i class="pr ${PR[x.priority]}"></i>${t('prio.' + x.priority)}${x.due_date ? ' · ' + fmtDate(x.due_date, { day: 'numeric', month: 'short' }) : ''}
        ${x.due_date && x.due_date < today && !x.done ? html` <span class="chip red">${t('due.late')}</span>` : ''}</div></div>
      <button class="icon-btn plain" data-del="${x.id}" aria-label="${t('common.delete')}">${icon('trash', 18)}</button></div>`) : html`<div class="card empty">${t('plan.no_task')}</div>`}</div>`;
}
async function renderStudy(mine) {
  const study = await data.get('study');
  const goal = Number(store.get().settings.study_goal || 300);
  const mon = mondayOf(todayISO()); const sun = addDays(mon, 6);
  const doneMin = study.filter((s) => s.done && s.planned_date >= mon && s.planned_date <= sun).reduce((a, s) => a + s.duration_min, 0);
  const pct = Math.min(100, Math.round((doneMin / Math.max(1, goal)) * 100));
  const mods = store.get().ref.modules.filter((m) => mine.some((s) => s.module_id === m.id));
  return html`<div class="card mb"><div class="between"><div><div class="xs muted b">${t('plan.study_goal')}</div><div class="big-num">${doneMin} <span class="small muted">/ ${goal} ${t('time.min_short')}</span></div></div><div class="pct">${pct}%</div></div>
      <div class="progress mt-s"><i style="width:${pct}%"></i></div>
      <div class="row mt"><input class="input goal-input" type="number" min="30" max="3000" step="30" data-goal value="${goal}" aria-label="${t('plan.study_goal')}"><span class="xs muted">${t('time.min_short')} / ${t('sched.week').toLowerCase()}</span></div></div>
    <form data-study class="card stack mb" novalidate><h3>${t('plan.new_study')}</h3>
      <div class="field"><label>${t('plan.subject')}</label><select class="input" name="module_id" required>${options(mods.length ? mods : store.get().ref.modules, null, (m) => m.name)}</select></div>
      <div class="grid3"><div class="field"><label>${t('common.date')}</label><input class="input" type="date" name="planned_date" required value="${todayISO()}"></div>
        <div class="field"><label>${t('common.start')}</label><input class="input" type="time" name="start_time" value="18:00"></div>
        <div class="field"><label>${t('plan.duration')}</label><input class="input" type="number" name="duration_min" min="10" max="480" value="60" required></div></div>
      <button class="btn primary">${icon('plus', 18)} ${t('common.add')}</button></form>
    <button class="btn ghost block mb" data-suggest>${icon('spark', 16)} ${t('plan.suggest')}</button>
    <div class="stack">${[...study].sort((a, b) => b.planned_date.localeCompare(a.planned_date)).map((s) => html`<div class="todo ${s.done ? 'done' : ''}">
      <button class="cbox ${s.done ? 'on' : ''}" data-tstudy="${s.id}" aria-label="${t('plan.toggle')}" aria-pressed="${s.done}">${s.done ? icon('check', 14) : ''}</button>
      <div class="grow"><div class="todo-t b">${s.subject || ref.moduleName(s.module_id)}</div><div class="xs muted">${fmtDate(s.planned_date, { weekday: 'short', day: 'numeric', month: 'short' })}${s.start_time ? ' · ' + hm(s.start_time) : ''} · ${t('time.min', { n: s.duration_min })}</div></div>
      <button class="icon-btn plain" data-dstudy="${s.id}" aria-label="${t('common.delete')}">${icon('trash', 18)}</button></div>`)}</div>`;
}

function bind(el, tab, mine, exceptions, alive) {
  if (tab === 'day') {
    const cd = el.querySelector('[data-cd]');
    if (cd) { const tm = setInterval(() => { if (!alive() || !document.body.contains(cd)) return clearInterval(tm); cd.textContent = fmtCountdown(Number(cd.dataset.cd) - Date.now()); }, 1000); }
    let tmo;
    on(el, 'change', '[data-dep]', (_e, f) => { clearTimeout(tmo); tmo = setTimeout(() => {
      const v = formData(f);
      const dep = { usual: v.usual || DEP_DEFAULTS.usual, journey: Math.min(240, Math.max(1, Number(v.journey) || 25)), margin: Math.min(60, Math.max(0, Number(v.margin) || 0)),
        interval: Number(v.interval) || 15, depRem: !!v.depRem, classRem: !!v.classRem };
      saveSettings({ departure: dep }).then(() => render()).catch((e) => toast(e.message, '', 'error'));
    }, 300); });
  }
  if (tab === 'cal') {
    on(el, 'click', '[data-calview]', (_e, b) => { st.cal = b.dataset.calview; render(); });
    on(el, 'click', '[data-pick]', (_e, b) => { st.date = b.dataset.pick; render(); });
    on(el, 'click', '[data-move]', (_e, b) => {
      const n = Number(b.dataset.move);
      if (st.cal === 'month') { const [y, m] = st.date.split('-').map(Number); st.date = new Date(Date.UTC(y, m - 1 + n, 1)).toISOString().slice(0, 10); }
      else st.date = addDays(st.date, st.cal === 'week' ? 7 * n : n);
      render();
    });
  }
  if (tab === 'todo') {
    on(el, 'submit', '[data-todo]', (e, f) => { e.preventDefault(); if (!f.title.value.trim()) return f.reportValidity();
      busy(f.querySelector('button'), async () => { const v = formData(f); await q(sb.from('tasks').insert({ title: v.title, due_date: v.due_date, priority: v.priority })); data.invalidate('tasks'); render(); }); });
    on(el, 'click', '[data-toggle]', (_e, b) => busy(b, async () => { const x = (await data.get('tasks')).find((k) => k.id === b.dataset.toggle);
      await q(sb.from('tasks').update({ done: !x.done, done_at: !x.done ? new Date().toISOString() : null }).eq('id', x.id)); data.invalidate('tasks'); render(); }));
    on(el, 'click', '[data-del]', (_e, b) => busy(b, async () => { await q(sb.from('tasks').delete().eq('id', b.dataset.del)); data.invalidate('tasks'); render(); }));
  }
  if (tab === 'study') {
    on(el, 'change', '[data-goal]', (_e, i) => saveSettings({ study_goal: Math.min(3000, Math.max(30, Number(i.value) || 300)) }).then(() => render()).catch((e) => toast(e.message, '', 'error')));
    on(el, 'submit', '[data-study]', (e, f) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => { const v = formData(f);
        await q(sb.from('study_sessions').insert({ module_id: v.module_id, subject: ref.moduleName(v.module_id), planned_date: v.planned_date, start_time: v.start_time, duration_min: Number(v.duration_min) }));
        data.invalidate('study'); render(); }); });
    on(el, 'click', '[data-tstudy]', (_e, b) => busy(b, async () => { const s = (await data.get('study')).find((k) => k.id === b.dataset.tstudy);
      await q(sb.from('study_sessions').update({ done: !s.done }).eq('id', s.id)); data.invalidate('study'); render(); }));
    on(el, 'click', '[data-dstudy]', (_e, b) => busy(b, async () => { await q(sb.from('study_sessions').delete().eq('id', b.dataset.dstudy)); data.invalidate('study'); render(); }));
    on(el, 'click', '[data-suggest]', (_e, b) => busy(b, async () => {
      const [assessments, study] = await data.all('assessments', 'study');
      const props = suggestStudy(assessments, mine, study, exceptions);
      if (!props.length) return toast(t('plan.suggest_none'));
      await q(sb.from('study_sessions').insert(props)); data.invalidate('study'); render(); toast(t('plan.added', { n: props.length }), '', 'ok');
    }));
  }
}
export { go };
