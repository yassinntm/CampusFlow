// Emploi du temps — structure de la démo : carte de version (lecture seule), bandeau des changements, Jour / Semaine,
// puces des jours ; en plus : navigation de semaine en semaine (annulations datées) et historique des versions
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, fmtInstant, dayName, ago } from '../../core/i18n.js';
import { ref, me } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, mondayOf, isoWeekday, hm, toMin } from '../../core/dates.js';
import { effectiveSlots, slotCard } from '../../shared/components.js';
import { topbar, wireTopbar } from '../ui.js';

const st = { mode: 'day', date: null };
export const scheduleView = {
  title: 'nav.schedule',
  async render(el) {
    const [slots, versions, exceptions] = await data.all('slots', 'versions', 'exceptions');
    const g = me().group_id;
    const mine = slots.filter((s) => s.group_id === g);
    const vers = versions.filter((v) => v.group_id === g);
    const last = vers[0];
    const today = todayISO();
    if (!st.date) st.date = isoWeekday(today) === 7 ? addDays(today, 1) : today;
    const mon = mondayOf(st.date);
    const days = Array.from({ length: 6 }, (_, i) => addDays(mon, i));
    const changedOn = (d) => effectiveSlots(mine, exceptions, d).some((s) => s.note || s.status === 'cancelled');
    const changes = last?.changes || [];
    let body;
    if (!mine.length) body = html`<div class="card empty">${icon('cal', 28)}${t('sched.none')}</div>`;
    else if (st.mode === 'day') {
      const list = effectiveSlots(mine, exceptions, st.date);
      const nm = toMin;
      body = html`<div class="between week-nav"><button class="icon-btn plain" data-week="-7" aria-label="${t('sched.prev_week')}">${icon('chevl', 20, 'class="flip"')}</button>
          <span class="small muted">${t('sched.week_of', { date: fmtDate(mon, { day: 'numeric', month: 'long' }) })}</span>
          <button class="icon-btn plain" data-week="7" aria-label="${t('sched.next_week')}">${icon('chev', 20, 'class="flip"')}</button></div>
        <div class="daychips">${days.map((d) => html`<button class="dc ${d === st.date ? 'on' : ''} ${d === today ? 'today' : ''}" data-date="${d}">
          ${fmtDate(d, { weekday: 'short' })}<b>${Number(d.slice(8))}</b>${changedOn(d) ? html`<i class="mdot"></i>` : ''}</button>`)}</div>
        <div class="day-h">${fmtDate(st.date)}</div>
        <div class="stack">${list.length ? list.map((s) => slotCard(s, { date: st.date })) : html`<div class="card empty">${icon('cal', 28)}${t('home.no_class_today')}</div>`}</div>`;
      void nm;
    } else {
      const ranges = [...new Set(mine.map((s) => hm(s.start_time) + '–' + hm(s.end_time)))].sort((a, b) => toMin(a.slice(0, 5)) - toMin(b.slice(0, 5)));
      body = html`<div class="scroll-x card wtable-card"><table class="wtable"><thead><tr><th></th>${[1, 2, 3, 4, 5, 6].map((d) => html`<th>${dayName(d)}</th>`)}</tr></thead><tbody>
        ${ranges.map((r) => html`<tr><th class="xs nowrap">${r}</th>${[1, 2, 3, 4, 5, 6].map((d) => {
          const s = mine.find((x) => x.weekday === d && hm(x.start_time) + '–' + hm(x.end_time) === r);
          return html`<td>${s ? html`<div class="wcell ${s.status === 'cancelled' ? 'cancelled' : s.note ? 'modified' : ''}" title="${s.note || ''}"><b>${ref.moduleName(s.module_id)}</b>${ref.roomName(s.room_id)}<br><span class="muted">${ref.personName(s.teacher_id)}</span></div>` : html`<div class="wcell empty"></div>`}</td>`;
        })}</tr>`)}</tbody></table></div>
        <div class="row xs muted legend"><span class="row"><i class="lg amber"></i>${t('slot.modified')}</span><span class="row"><i class="lg red"></i>${t('slot.cancelled')}</span></div>`;
    }
    mount(el, html`${topbar(t('nav.schedule'))}
      <div class="card version-card"><div class="between wrap"><div><div class="b">${t('common.group')} ${ref.groupCode(g)} · ${t('sched.version', { n: last?.version || 0 })}</div>
          <div class="xs muted">${last ? t('sched.published_on', { date: fmtInstant(last.published_at, { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) }) : t('sched.none')}</div></div>
          <span class="chip green">${icon('shield', 12)} ${t('sched.official')}</span></div>
        <div class="xs muted row mt-s">${icon('shield', 14)} ${t('sched.read_only')}</div></div>
      ${changes.length ? html`<details class="warn changes-banner"><summary>${icon('alert', 18)}<span><b>${changes.length}</b> ${t('sched.changes_in_version')}</span></summary>
        <ul class="changes">${changes.map((c) => html`<li class="ch-${c.type}">${c.text}</li>`)}</ul></details>` : ''}
      <div class="between mode-row"><button class="btn sm ghost" data-today>${t('sched.today')}</button>
        <div class="seg"><button class="${st.mode === 'day' ? 'on' : ''}" data-mode="day">${t('sched.day')}</button><button class="${st.mode === 'week' ? 'on' : ''}" data-mode="week">${t('sched.week')}</button></div></div>
      ${body}
      ${vers.length > 1 ? html`<section class="sec"><h2>${t('sched.history')}</h2><div class="stack mt-s">${vers.slice(0, 6).map((v) => html`<details class="card"><summary class="between">
        <b>${t('sched.version', { n: v.version })}</b><span class="muted small">${ago(v.published_at)}</span></summary><ul class="changes">${(v.changes || []).map((c) => html`<li class="ch-${c.type}">${c.text}</li>`)}</ul></details>`)}</div></section>` : ''}`);
    wireTopbar(el);
    on(el, 'click', '[data-mode]', (_e, b) => { st.mode = b.dataset.mode; render(); });
    on(el, 'click', '[data-date]', (_e, b) => { st.date = b.dataset.date; render(); });
    on(el, 'click', '[data-week]', (_e, b) => { st.date = addDays(st.date, Number(b.dataset.week)); render(); });
    on(el, 'click', '[data-today]', () => { st.date = isoWeekday(today) === 7 ? addDays(today, 1) : today; st.mode = 'day'; render(); });
  },
};
