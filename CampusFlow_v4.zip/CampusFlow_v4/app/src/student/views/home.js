// Accueil — structure de la démo d'origine : héro (date, bonjour, groupe, cloche) + prochain cours avec compte à rebours,
// raccourcis, cours du jour, devoirs à venir, annonces
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate } from '../../core/i18n.js';
import { store, ref, me } from '../../core/store.js';
import { on } from '../../core/router.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, toMin, nowMinutes, hm, instantFrom, isoWeekday } from '../../core/dates.js';
import { effectiveSlots, slotCard, assignItem, annItem } from '../../shared/components.js';
import { sectionHead } from '../ui.js';
import { openSearch } from '../search.js';

// Prochain cours (aujourd'hui ou les jours suivants), annulations ponctuelles comprises
export function nextClass(slots, exceptions) {
  const today = todayISO(); const now = nowMinutes();
  for (let i = 0; i < 8; i++) {
    const iso = addDays(today, i);
    const list = effectiveSlots(slots, exceptions, iso).filter((s) => s.status === 'active' && (i > 0 || toMin(s.end_time) > now));
    if (list.length) {
      const s = list[0];
      const ongoing = i === 0 && toMin(s.start_time) <= now;
      return { s, iso, ongoing, target: new Date(instantFrom(iso, hm(ongoing ? s.end_time : s.start_time))).getTime() };
    }
  }
  return null;
}
export const fmtCountdown = (ms) => {
  if (ms <= 0) return '00:00:00';
  const s = Math.floor(ms / 1000); const d = Math.floor(s / 86400);
  const hh = String(Math.floor((s % 86400) / 3600)).padStart(2, '0'), mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0'), ss = String(s % 60).padStart(2, '0');
  return (d ? d + t('time.d') + ' ' : '') + `${hh}:${mm}:${ss}`;
};

export const homeView = {
  title: 'nav.home',
  async render(el, _p, alive) {
    const [slots, exceptions, assessments, progress, anns] = await data.all('slots', 'exceptions', 'assessments', 'progress', 'announcements');
    const p = me(); const today = todayISO();
    const nc = nextClass(slots, exceptions);
    const done = new Set(progress.filter((x) => x.status === 'done').map((x) => x.assessment_id));
    const upcoming = assessments.filter((a) => new Date(a.due_at) > new Date() && !done.has(a.id)).slice(0, 3);
    const highlighted = anns.filter((a) => a.pinned || a.important);
    const shownAnns = (highlighted.length ? highlighted : anns).slice(0, 2);
    const todays = effectiveSlots(slots, exceptions, today);
    const u = store.get().unread;
    const quick = [['schedule', 'cal', 'nav.schedule_short', 'bg-blue'], ['assignments', 'book', 'nav.assignments', 'bg-amber'], ['planner', 'clock', 'nav.planner_short', 'bg-green'],
      ['announcements', 'mega', 'nav.announcements', 'bg-violet'], ['planner/cal', 'cal', 'tile.calendar', 'bg-blue'], ['planner/todo', 'check', 'tile.tasks', 'bg-green'],
      ['attendance', 'users', 'tile.attendance', 'bg-red'], ['search', 'search', 'tile.search', 'bg-violet']];
    const campus = [['exams', 'target', 'nav.exams', 'bg-red'], ['community', 'chat', 'nav.community', 'bg-blue'], ['studygroups', 'users', 'nav.studygroups', 'bg-green'],
      ['rides', 'car', 'nav.rides', 'bg-amber'], ['freetime', 'coffee', 'nav.freetime', 'bg-violet'], ['resources', 'file', 'nav.resources', 'bg-blue'],
      ['ai', 'bot', 'nav.ai', 'bg-violet'], ['profile', 'user', 'nav.settings', 'bg-green']];
    const tile = ([to, ic, label, bg]) => to === 'search'
      ? html`<button class="q" data-open-search><span class="qi ${bg}">${icon(ic)}</span>${t(label)}</button>`
      : html`<a class="q" href="#/${to}"><span class="qi ${bg}">${icon(ic)}</span>${t(label)}</a>`;
    mount(el, html`
      <section class="hero">
        <div class="between hero-top"><div><div class="hero-date">${fmtDate(today)}</div><h1>${t('home.hello', { name: (p.full_name || '').split(' ')[0] })}</h1></div>
          <div class="row"><span class="chip light">${t('common.group')} ${ref.groupCode(p.group_id)}</span>
          <a class="icon-btn hero-bell" href="#/notifs" aria-label="${t('nav.notifications')}">${icon('bell')}${u ? html`<span class="dot">${u}</span>` : ''}</a></div></div>
        <div class="next">${nc ? html`<div class="between next-row">
            <div><div class="next-label">${nc.ongoing ? t('home.now') : t('home.next')}${!nc.ongoing && nc.iso !== today ? ' · ' + fmtDate(nc.iso, { weekday: 'long' }) : ''}</div>
              <div class="next-title">${ref.moduleName(nc.s.module_id)}</div>
              <div class="next-meta">${hm(nc.s.start_time)}–${hm(nc.s.end_time)} · ${ref.roomName(nc.s.room_id) || '—'} · ${ref.personName(nc.s.teacher_id) || t('slot.teacher_unknown')}</div></div>
            <div class="next-cd"><div class="xs">${nc.ongoing ? t('home.ends_in') : t('home.starts_in_label')}</div><div class="countdown" data-cd="${nc.target}">${fmtCountdown(nc.target - Date.now())}</div></div>
          </div>${nc.s.note ? html`<div class="xs next-note">${icon('alert', 14)} ${nc.s.note}</div>` : ''}`
          : html`<div class="next-title">${isoWeekday(today) === 7 ? t('home.sunday') : t('home.no_class')}</div>`}</div>
      </section>
      <div class="sec"><div class="quick">${quick.map(tile)}</div></div>
      <div class="sec">${sectionHead(t('home.today_classes'), 'schedule')}
        <div class="stack">${todays.length ? todays.map((s) => slotCard(s, { date: today })) : html`<div class="card empty">${icon('cal', 28)}${t('home.no_class_today')}</div>`}</div></div>
      <div class="sec">${sectionHead(t('home.deadlines'), 'assignments')}
        <div class="stack">${upcoming.length ? upcoming.map((a) => assignItem(a, { teacher: teacherOf(a, slots) })) : html`<div class="card empty">${t('home.no_deadline')}</div>`}</div></div>
      ${shownAnns.length ? html`<div class="sec">${sectionHead(t('nav.announcements'), 'announcements')}<div class="stack">${shownAnns.map((a) => annItem(a))}</div></div>` : ''}
      <div class="sec">${sectionHead(t('home.campus'))}<div class="quick">${campus.map(tile)}</div></div>`);
    on(el, 'click', '[data-open-search]', () => openSearch());
    const cd = el.querySelector('[data-cd]');
    if (cd) {
      const timer = setInterval(() => {
        if (!alive() || !document.body.contains(cd)) return clearInterval(timer);
        cd.textContent = fmtCountdown(Number(cd.dataset.cd) - Date.now());
      }, 1000);
    }
  },
};
// Formateur d'un devoir : celui qui enseigne ce module à ce groupe dans l'emploi du temps
export const teacherOf = (a, slots) => {
  const s = slots.find((x) => x.module_id === a.module_id && (!a.group_id || x.group_id === a.group_id) && x.teacher_id);
  return s ? ref.personName(s.teacher_id) : '';
};
