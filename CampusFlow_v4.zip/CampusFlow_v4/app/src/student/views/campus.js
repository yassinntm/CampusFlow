// Vie du campus : pauses entre les cours, ressources des modules, assistant d'étude, page de raccourcis
import { html, mount, safeUrl } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, ago, getLang } from '../../core/i18n.js';
import { store, ref, me } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, isoWeekday, toMin, fromMin, nowMinutes, hm } from '../../core/dates.js';
import { busy, options } from '../../core/ui.js';
import { effectiveSlots } from '../../shared/components.js';
import { topbar, wireTopbar } from '../ui.js';
import { openAttachment } from './assignments.js';

export const campusView = {
  title: 'nav.campus',
  async render(el) {
    const items = [['exams', 'target', 'bg-red'], ['attendance', 'users', 'bg-red'], ['community', 'chat', 'bg-blue'], ['studygroups', 'users', 'bg-green'], ['rides', 'car', 'bg-amber'],
      ['freetime', 'coffee', 'bg-violet'], ['resources', 'file', 'bg-blue'], ['ai', 'bot', 'bg-violet']];
    mount(el, html`${topbar(t('nav.campus'))}<div class="stack">${items.map(([to, ic, bg]) => html`<a class="item" href="#/${to}"><div class="ii ${bg}">${icon(ic)}</div>
      <div class="grow"><div class="item-t">${t('nav.' + to)}</div><div class="item-b">${t('campus.' + to)}</div></div>${icon('chev', 16, 'class="flip"')}</a>`)}</div>`);
    wireTopbar(el);
  },
};

export const freeTimeView = {
  title: 'nav.freetime',
  async render(el) {
    const [slots, exceptions] = await data.all('slots', 'exceptions');
    const mine = slots.filter((s) => s.group_id === me().group_id);
    const today = todayISO();
    const iso = isoWeekday(today) === 7 ? addDays(today, 1) : today;
    const list = effectiveSlots(mine, exceptions, iso).filter((s) => s.status === 'active');
    const gaps = [];
    for (let i = 0; i < list.length - 1; i++) {
      const a = toMin(list[i].end_time), b = toMin(list[i + 1].start_time);
      if (b - a >= 15) gaps.push({ from: a, to: b, after: list[i], before: list[i + 1] });
    }
    const now = iso === today ? nowMinutes() : -1;
    const dur = (m) => (m < 60 ? t('time.min', { n: m }) : t('time.hmin', { h: Math.floor(m / 60), m: String(m % 60).padStart(2, '0') }));
    mount(el, html`${topbar(t('nav.freetime'))}<p class="muted">${t('free.intro', { day: fmtDate(iso) })}</p>
      <div class="stack mt">${gaps.length ? gaps.map((g) => html`<div class="gapcard ${now >= g.from && now < g.to ? 'now' : now >= g.to ? 'past' : ''}">
        <div class="between"><b>${fromMin(g.from)} – ${fromMin(g.to)}</b><span class="chip green">${dur(g.to - g.from)}</span></div>
        <div class="muted small mt-s">${t('free.between', { a: ref.moduleName(g.after.module_id), b: ref.moduleName(g.before.module_id) })}</div>
        ${g.before.room_id ? html`<div class="muted small">${icon('pin', 13)} ${t('free.next_room', { room: ref.roomName(g.before.room_id) })}</div>` : ''}
        <div class="row wrap mt-s"><a class="btn sm ghost" href="#/planner/study">${icon('book', 14)} ${t('free.plan_study')}</a><a class="btn sm ghost" href="#/studygroups">${icon('users', 14)} ${t('nav.studygroups')}</a></div></div>`)
        : html`<div class="card empty">${icon('coffee', 28)}${list.length ? t('free.none') : t('home.no_class_today')}</div>`}</div>
      ${list.length ? html`<div class="card mt"><div class="between"><span>${t('free.day_ends')}</span><b>${hm(list[list.length - 1].end_time)}</b></div></div>` : ''}`);
    wireTopbar(el);
  },
};

const rs = { module: '' };
export const resourcesView = {
  title: 'nav.resources',
  async render(el) {
    const list = await data.get('resources');
    const used = store.get().ref.modules.filter((m) => list.some((r) => r.module_id === m.id));
    const shown = list.filter((r) => !rs.module || r.module_id === rs.module);
    mount(el, html`${topbar(t('nav.resources'))}
      <select class="input w-auto mb" data-filter aria-label="${t('common.module')}"><option value="">${t('res.all_modules')}</option>${options(used, rs.module, (m) => m.name)}</select>
      <div class="stack">${shown.length ? shown.map((r) => html`<div class="item"><div class="ii bg-violet">${icon(r.kind === 'file' ? 'file' : 'link', 18)}</div>
        <div class="grow"><div class="item-t">${r.title}</div><div class="item-b">${ref.moduleName(r.module_id)} · ${ref.personName(r.created_by) || ''} · ${ago(r.created_at)}</div>
        ${r.description ? html`<div class="item-b pre">${r.description}</div>` : ''}</div>
        ${r.kind === 'file' ? html`<button class="btn sm" data-open="${r.id}">${icon('down', 16)} ${t('res.open')}</button>`
          : html`<a class="btn sm" href="${safeUrl(r.url)}" target="_blank" rel="noopener noreferrer">${icon('link', 16)} ${t('res.open')}</a>`}</div>`)
        : html`<div class="card empty">${icon('file', 28)}${t('res.none')}</div>`}</div>`);
    wireTopbar(el);
    on(el, 'change', '[data-filter]', (_e, s) => { rs.module = s.value; render(); });
    on(el, 'click', '[data-open]', (_e, b) => busy(b, () => openAttachment(list.find((x) => x.id === b.dataset.open))));
  },
};

// Assistant d'étude : passe uniquement par la fonction serveur « ai-assistant » (clé IA côté serveur, quota par compte)
const chat = { messages: [], status: 'unknown', remaining: null };
export const aiView = {
  title: 'nav.ai',
  async render(el) {
    const draw = (busyNow = false) => mount(el, html`${topbar(t('nav.ai'))}<div class="card small muted">${icon('shield', 14)} ${t('ai.disclaimer')}</div>
      ${chat.status === 'unavailable' ? html`<div class="warn mt">${icon('alert', 16)} <span>${t('ai.unavailable')}</span></div>` : ''}
      <div class="chat mt">${chat.messages.length ? chat.messages.map((m) => html`<div class="bubble ${m.role}"><div class="pre">${m.content}</div></div>`)
        : html`<div class="empty">${icon('bot', 36)}<div>${t('ai.empty')}</div></div><div class="row wrap center">${['ai.s1', 'ai.s2', 'ai.s3'].map((k) => html`<button class="btn sm ghost" data-s="${t(k)}">${t(k)}</button>`)}</div>`}
        ${busyNow ? html`<div class="bubble assistant"><div class="spinner"></div></div>` : ''}</div>
      <form class="chat-input mt" data-chat><textarea class="input" name="msg" rows="2" maxlength="2000" required placeholder="${t('ai.ph')}" ${busyNow || chat.status === 'unavailable' ? 'disabled' : ''}></textarea>
        <button class="btn primary" ${busyNow || chat.status === 'unavailable' ? 'disabled' : ''} aria-label="${t('common.send')}">${icon('send', 18)}</button></form>
      ${chat.remaining != null ? html`<p class="muted small mt-s">${t('ai.remaining', { n: chat.remaining })}</p>` : ''}
      ${chat.messages.length ? html`<button class="btn sm ghost mt" data-clear>${t('ai.clear')}</button>` : ''}`);
    const send = async (text) => {
      chat.messages.push({ role: 'user', content: text }); draw(true); wireTopbar(el);
      try {
        const { data: d, error } = await sb.functions.invoke('ai-assistant', { body: { messages: chat.messages.slice(-10), lang: getLang() } });
        if (error) {
          let body = null; try { body = await error.context?.json?.(); } catch { /* corps illisible */ }
          const status = error.context?.status;
          if (status === 404 || status === 503 || body?.error === 'not_configured' || /Failed to send|FunctionsFetchError|FunctionsRelayError/i.test(error.name + error.message)) { chat.status = 'unavailable'; chat.messages.pop(); }
          else chat.messages.push({ role: 'assistant', content: body?.error === 'quota' ? t('ai.quota') : t('ai.error') });
        } else { chat.status = 'ok'; chat.remaining = d.remaining ?? null; chat.messages.push({ role: 'assistant', content: d.reply }); }
      } catch { chat.status = 'unavailable'; chat.messages.pop(); }
      draw(false); wireTopbar(el);
    };
    draw(); wireTopbar(el);
    on(el, 'submit', '[data-chat]', (e, f) => { e.preventDefault(); const v = f.msg.value.trim(); if (v) send(v); });
    on(el, 'keydown', '[data-chat] textarea', (e, ta) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ta.form.requestSubmit(); } });
    on(el, 'click', '[data-s]', (_e, b) => send(b.dataset.s));
    on(el, 'click', '[data-clear]', () => { chat.messages = []; draw(); wireTopbar(el); });
  },
};
