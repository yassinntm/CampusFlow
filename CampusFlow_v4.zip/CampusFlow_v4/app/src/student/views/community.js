// Communauté : questions / discussions (anonymat possible), groupes de révision, covoiturage — avec signalement et modération
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, ago, fmtDate, dayName } from '../../core/i18n.js';
import { hm as hmF } from '../../core/dates.js';
import { store, ref, me, myId, role } from '../../core/store.js';
import { on, go, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { openModal, closeModal, formData, busy, toast, empty, options, confirmBox, chip } from '../../core/ui.js';
import { todayISO, hm } from '../../core/dates.js';
import { normalize } from '../../shared/components.js';
import { topbar, wireTopbar } from '../ui.js';

const REASONS = ['spam', 'harassment', 'inappropriate', 'off_topic', 'cheating', 'other'];
export const reportDialog = (kind, id) => openModal(t('report.title'), html`<form class="stack"><p class="muted small">${t('report.help')}</p>
  <div class="stack">${REASONS.map((r, i) => html`<label class="check"><input type="radio" name="reason" value="${r}" ${i === 0 ? 'checked' : ''}> ${t('report.' + r)}</label>`)}</div>
  <textarea class="input" name="details" rows="3" maxlength="500" placeholder="${t('report.details')}"></textarea>
  <button class="btn danger block">${icon('flag', 16)} ${t('report.send')}</button></form>`, {
  onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); busy(e.target.querySelector('button'), async () => {
    const v = formData(e.target);
    try { await q(sb.from('reports').insert({ target_kind: kind, target_id: id, reason: v.reason, details: v.details })); }
    catch (err) { if (err.code !== 'duplicate') throw err; }
    closeModal(); toast(t('report.sent'), t('report.sent_help'), 'ok');
  }); }),
});
const author = (p) => (p.author_id ? ref.personName(p.author_id) || t('common.someone') : t('post.anonymous'));
const RULES = ['rule1', 'rule2', 'rule3', 'rule4'];
const rulesBox = () => html`<details class="card small"><summary><b>${icon('shield', 14)} ${t('rules.title')}</b></summary><ul class="mt-s">${RULES.map((r) => html`<li>${t('rules.' + r)}</li>`)}</ul></details>`;

// ========================= Liste =========================
const cm = { tab: 'question', module: '', text: '' };
const subnav = (cur) => html`<div class="tabs mb">${[['community', 'comm.qa'], ['studygroups', 'nav.studygroups'], ['rides', 'nav.rides']].map(([to, l]) => html`<a class="tab ${cur === to ? 'on' : ''}" href="#/${to}">${t(l)}</a>`)}</div>`;
export const communityView = {
  title: 'nav.community',
  async render(el) {
    const body = await postsList();
    mount(el, html`${topbar(t('nav.community'))}${subnav('community')}
      <div class="seg">${['question', 'discussion'].map((k) => html`<button class="${cm.tab === k ? 'on' : ''}" data-tab="${k}">${t('comm.' + k)}</button>`)}</div>
      <div class="mt">${rulesBox()}</div>${body}`);
    wireTopbar(el);
    on(el, 'click', '[data-tab]', (_e, b) => { cm.tab = b.dataset.tab; render(); });
    on(el, 'change', '[data-mfilter]', (_e, s) => { cm.module = s.value; render(); });
    on(el, 'input', '[data-text]', (_e, i) => { cm.text = i.value; clearTimeout(cm.tm); cm.tm = setTimeout(() => { render().then(() => { const x = document.querySelector('[data-text]'); x?.focus(); x?.setSelectionRange(x.value.length, x.value.length); }); }, 350); });
    on(el, 'click', '[data-new-post]', () => newPostDialog(cm.tab));
    on(el, 'click', '[data-vote]', (_e, b) => vote(b));
    on(el, 'click', '[data-report]', (_e, b) => reportDialog(b.dataset.kind, b.dataset.report));
  },
};
async function vote(b) {
  return busy(b, async () => {
    if (b.dataset.voted === 'true') await q(sb.from('post_votes').delete().eq('post_id', b.dataset.vote).eq('user_id', myId()));
    else await q(sb.from('post_votes').insert({ post_id: b.dataset.vote }));
    data.invalidate('posts'); render();
  });
}
async function postsList() {
  const posts = await data.get('posts');
  const kind = cm.tab;
  const nq = normalize(cm.text);
  const list = posts.filter((p) => p.kind === kind && (!cm.module || p.module_id === cm.module) && (!nq || normalize(p.title + ' ' + p.body).includes(nq)));
  const mods = store.get().ref.modules;
  return html`<div class="row wrap mt"><input class="input grow" data-text value="${cm.text}" placeholder="${t('comm.search')}" aria-label="${t('comm.search')}">
      <select class="input w-auto" data-mfilter aria-label="${t('common.module')}"><option value="">${t('res.all_modules')}</option>${options(mods, cm.module, (m) => m.name)}</select></div>
    ${html`<button class="btn primary block mt" data-new-post>${icon('plus', 16)} ${t(kind === 'question' ? 'post.ask' : 'post.new_discussion')}</button>`}
    <div class="stack mt">${list.length ? list.map((p) => html`<div class="qcard ${p.status !== 'visible' ? 'hidden-post' : ''}">
      <div class="vote"><button class="icon-btn plain ${p.voted ? 'on' : ''}" data-vote="${p.id}" data-voted="${p.voted}" aria-label="${t('post.vote')}" aria-pressed="${p.voted}">${icon('up', 18)}</button><b>${p.votes}</b></div>
      <a class="grow" href="#/post/${p.id}"><div class="item-t">${p.title}</div><div class="item-b clamp2">${p.body}</div>
        <div class="row wrap mt-s">${p.module_id ? chip(ref.moduleName(p.module_id)) : ''}${p.resolved ? chip(t('post.resolved'), 'green') : ''}
        ${p.status !== 'visible' ? chip(t('mod.status_' + p.status), 'red') : ''}<span class="muted small">${author(p)} · ${ago(p.created_at)}</span></div></a></div>`)
      : empty(t(kind === 'question' ? 'post.no_questions' : 'post.no_discussions'), 'chat')}</div>`;
}
function newPostDialog(kind) {
  openModal(t(kind === 'question' ? 'post.ask' : 'post.new_discussion'), html`<form class="stack" novalidate>
    <div class="field"><label>${t('post.title')}</label><input class="input" name="title" required minlength="5" maxlength="140"></div>
    <div class="field"><label>${t('post.body')}</label><textarea class="input" name="body" rows="6" required minlength="10" maxlength="3000"></textarea></div>
    <select class="input" name="module_id" aria-label="${t('common.module')}"><option value="">${t('post.no_module')}</option>${options(store.get().ref.modules, null, (m) => m.name)}</select>
    <label class="check"><input type="checkbox" name="anonymous"> ${t('post.anon_help')}</label>
    <p class="muted small">${t('post.anon_note')}</p><button class="btn primary block">${t('post.publish')}</button></form>`, {
    onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => {
        const v = formData(f);
        const row = await q(sb.from('posts').insert({ kind, title: v.title, body: v.body, module_id: v.module_id, anonymous: v.anonymous, group_id: me().group_id }).select('id').single());
        closeModal(); data.invalidate('posts'); go('post', row.id);
      }); }),
  });
}

// ========================= Détail d'une publication =========================
export const postView = {
  title: 'post.title_view',
  async render(el, id) {
    data.invalidate('posts');
    const p = (await data.get('posts')).find((x) => x.id === id);
    if (!p) { mount(el, empty(t('post.not_found'), 'chat')); return; }
    const replies = await q(sb.from('replies').select('id,post_id,author_id,body,status,created_at').eq('post_id', id).order('created_at'));
    const mine = p.author_id === myId();
    const mod = false;
    const best = replies.find((r) => r.id === p.best_reply_id);
    const ordered = best ? [best, ...replies.filter((r) => r !== best)] : replies;
    mount(el, html`${topbar(t('post.title_view'))}<a class="link" href="#/community">${icon('chevl', 14, 'class="flip"')} ${t('comm.back')}</a>
      <article class="card mt"><div class="row wrap">${chip(t('comm.' + p.kind), 'blue')}${p.module_id ? chip(ref.moduleName(p.module_id)) : ''}${p.resolved ? chip(t('post.resolved'), 'green') : ''}
        ${p.status !== 'visible' ? chip(t('mod.status_' + p.status), 'red') : ''}</div>
        <h2 class="mt-s">${p.title}</h2><p class="pre mt-s">${p.body}</p>
        <div class="between mt wrap"><span class="muted small">${author(p)} · ${ago(p.created_at)}${p.anonymous && (mine || role() === 'admin') ? ' · ' + t('post.anon_tag') : ''}</span>
          <div class="row wrap"><button class="btn sm ${p.voted ? 'primary' : 'ghost'}" data-vote="${p.id}" data-voted="${p.voted}">${icon('up', 16)} ${p.votes}</button>
          ${mine && p.kind === 'question' ? html`<button class="btn sm ghost" data-resolve>${p.resolved ? t('post.unresolve') : t('post.mark_resolved')}</button>` : ''}
          ${!mine ? html`<button class="btn sm ghost" data-report="${p.id}" data-kind="post">${icon('flag', 14)} ${t('report.short')}</button>` : ''}
          ${mine || role() === 'admin' ? html`<button class="btn sm danger" data-del-post>${icon('trash', 14)}</button>` : ''}
          </div></div></article>
      <section class="sec"><h2>${t('post.replies', { n: replies.length })}</h2><div class="stack mt-s">
        ${ordered.map((r) => html`<div class="answer ${r.id === p.best_reply_id ? 'best' : ''} ${r.status !== 'visible' ? 'hidden-post' : ''}">
          ${r.id === p.best_reply_id ? html`<div class="chip green mb-s">${icon('check', 12)} ${t('post.best')}</div>` : ''}
          <p class="pre">${r.body}</p><div class="between mt-s wrap"><span class="muted small">${ref.personName(r.author_id) || t('common.someone')} · ${ago(r.created_at)}</span>
          <div class="row">${mine && p.kind === 'question' && r.author_id !== myId() && r.id !== p.best_reply_id ? html`<button class="btn sm ghost" data-best="${r.id}">${t('post.choose_best')}</button>` : ''}
          ${r.author_id !== myId() ? html`<button class="icon-btn plain" data-report="${r.id}" data-kind="reply" aria-label="${t('report.short')}">${icon('flag', 14)}</button>` : ''}
          ${r.author_id === myId() || role() === 'admin' ? html`<button class="icon-btn plain" data-del-reply="${r.id}" aria-label="${t('common.delete')}">${icon('trash', 14)}</button>` : ''}
          </div></div></div>`)}
        ${replies.length ? '' : empty(t('post.no_replies'), 'chat')}</div></section>
      ${p.status === 'visible' ? html`<form class="card stack mt" data-reply><label class="small muted" for="rb">${t('post.your_reply')}</label>
        <textarea class="input" id="rb" name="body" rows="3" required minlength="2" maxlength="3000"></textarea><button class="btn primary">${icon('send', 16)} ${t('post.reply')}</button></form>` : ''}`);
    wireTopbar(el);
    on(el, 'click', '[data-vote]', (_e, b) => vote(b));
    on(el, 'click', '[data-report]', (_e, b) => reportDialog(b.dataset.kind, b.dataset.report));
    on(el, 'click', '[data-resolve]', (_e, b) => busy(b, async () => { await q(sb.from('posts').update({ resolved: !p.resolved }).eq('id', p.id)); data.invalidate('posts'); render(); }));
    on(el, 'click', '[data-best]', (_e, b) => busy(b, async () => { await q(sb.from('posts').update({ best_reply_id: b.dataset.best }).eq('id', p.id)); data.invalidate('posts'); render(); }));
    on(el, 'click', '[data-del-post]', async (_e, b) => { if (await confirmBox(t('post.confirm_delete'))) busy(b, async () => { await q(sb.from('posts').delete().eq('id', p.id)); data.invalidate('posts'); go('community'); }); });
    on(el, 'click', '[data-del-reply]', async (_e, b) => { if (await confirmBox(t('post.confirm_delete_reply'))) busy(b, async () => { await q(sb.from('replies').delete().eq('id', b.dataset.delReply)); render(); }); });
    on(el, 'submit', '[data-reply]', (e, f) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => { await q(sb.from('replies').insert({ post_id: p.id, body: f.body.value.trim() })); render(); }); });
  },
};
// ========================= Groupes de révision =========================
export const studyGroupsView = {
  title: 'nav.studygroups',
  async render(el) {
    mount(el, html`${topbar(t('nav.studygroups'))}${subnav('studygroups')}${await studyList()}`);
    wireTopbar(el);
    on(el, 'click', '[data-new-sg]', () => newStudyDialog());
    on(el, 'click', '[data-edit-sg]', async (_e, b) => newStudyDialog((await data.get('studyGroups')).find((g) => g.id === b.dataset.editSg)));
    on(el, 'click', '[data-join]', (_e, b) => busy(b, async () => { await q(sb.from('study_group_members').insert({ study_group_id: b.dataset.join })); data.invalidate('sgMembers'); render(); toast(t('sg.joined'), '', 'ok'); }));
    on(el, 'click', '[data-leave]', (_e, b) => busy(b, async () => { await q(sb.from('study_group_members').delete().eq('study_group_id', b.dataset.leave).eq('user_id', myId())); data.invalidate('sgMembers'); render(); }));
    on(el, 'click', '[data-del-sg]', async (_e, b) => { if (await confirmBox(t('sg.confirm_delete'))) busy(b, async () => { await q(sb.from('study_groups').delete().eq('id', b.dataset.delSg)); data.invalidate('studyGroups'); render(); }); });
    on(el, 'click', '[data-report]', (_e, b) => reportDialog(b.dataset.kind, b.dataset.report));
  },
};
async function studyList() {
  const [groups, members] = await data.all('studyGroups', 'sgMembers');
  const today = todayISO();
  const list = groups.filter((g) => g.meet_date >= today && g.status === 'visible');
  return html`${html`<button class="btn primary block" data-new-sg>${icon('plus', 16)} ${t('sg.new')}</button>`}
    <div class="stack mt">${list.length ? list.map((g) => { const m = members.filter((x) => x.study_group_id === g.id); const joined = m.some((x) => x.user_id === myId());
      const owner = g.created_by === myId();
      return html`<div class="card"><div class="between"><b>${g.subject}</b>${chip(`${m.length}/${g.capacity}`, m.length >= g.capacity ? 'red' : 'green')}</div>
        <div class="muted small mt-s">${fmtDate(g.meet_date, { weekday: 'long', day: 'numeric', month: 'short' })} · ${hm(g.start_time)}–${hm(g.end_time)} · ${icon('pin', 12)} ${g.place}</div>
        <div class="muted small">${g.module_id ? ref.moduleName(g.module_id) + ' · ' : ''}${t('sg.by', { name: ref.personName(g.created_by) || t('common.someone') })}</div>
        <div class="muted small">${m.map((x) => ref.personName(x.user_id)).filter(Boolean).join(', ')}</div>
        <div class="row wrap mt">${owner ? html`<button class="btn sm ghost" data-edit-sg="${g.id}">${icon('edit', 14)} ${t('common.edit')}</button><button class="btn sm danger" data-del-sg="${g.id}">${icon('trash', 14)} ${t('common.delete')}</button>`
          : joined ? html`<button class="btn sm ghost" data-leave="${g.id}">${t('sg.leave')}</button>`
          : html`<button class="btn sm primary" data-join="${g.id}" ${m.length >= g.capacity ? 'disabled' : ''}>${t('sg.join')}</button>`}
          ${!owner ? html`<button class="icon-btn plain" data-report="${g.id}" data-kind="study_group" aria-label="${t('report.short')}">${icon('flag', 14)}</button>` : ''}</div></div>`; })
      : empty(t('sg.none'), 'users')}</div>`;
}
function newStudyDialog(g0 = null) {
  const g = g0 || {};
  openModal(t(g.id ? 'sg.edit' : 'sg.new'), html`<form class="stack" novalidate>
    <input class="input" name="subject" required minlength="3" maxlength="120" placeholder="${t('sg.subject_ph')}" aria-label="${t('sg.subject')}" value="${g.subject || ''}">
    <select class="input" name="module_id" aria-label="${t('common.module')}"><option value="">${t('common.module')}</option>${options(store.get().ref.modules, g.module_id, (m) => m.name)}</select>
    <div class="grid3"><input class="input" type="date" name="meet_date" required min="${todayISO()}" value="${g.meet_date || todayISO()}" aria-label="${t('common.date')}">
      <input class="input" type="time" name="start_time" required value="${g.start_time ? hmF(g.start_time) : '12:45'}" aria-label="${t('common.start')}"><input class="input" type="time" name="end_time" required value="${g.end_time ? hmF(g.end_time) : '14:00'}" aria-label="${t('common.end')}"></div>
    <div class="grid2"><input class="input" name="place" required maxlength="80" placeholder="${t('sg.place_ph')}" aria-label="${t('sg.place')}" value="${g.place || ''}">
      <input class="input" type="number" name="capacity" min="2" max="30" value="${g.capacity || 6}" required aria-label="${t('sg.capacity')}"></div>
    <button class="btn primary block">${t(g.id ? 'common.save' : 'sg.create')}</button></form>`, {
    onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => {
        const v = formData(f);
        if (v.end_time <= v.start_time) throw new Error(t('err.time_order'));
        if (g.id) { await q(sb.from('study_groups').update({ ...v, capacity: Number(v.capacity) }).eq('id', g.id)); closeModal(); data.invalidate('studyGroups'); render(); toast(t('common.saved'), '', 'ok'); return; }
        const ng = await q(sb.from('study_groups').insert({ ...v, capacity: Number(v.capacity) }).select('id').single());
        await q(sb.from('study_group_members').insert({ study_group_id: ng.id }));
        closeModal(); data.invalidate('studyGroups', 'sgMembers'); render(); toast(t('sg.created'), '', 'ok');
      }); }),
  });
}

// ========================= Covoiturage =========================
export const ridesView = {
  title: 'nav.rides',
  async render(el) {
    mount(el, html`${topbar(t('nav.rides'))}${subnav('rides')}${await ridesList()}`);
    wireTopbar(el);
    on(el, 'click', '[data-new-ride]', () => newRideDialog());
    on(el, 'click', '[data-book]', (_e, b) => busy(b, async () => { await q(sb.from('ride_bookings').insert({ ride_id: b.dataset.book })); data.invalidate('bookings'); render(); toast(t('ride.booked'), t('ride.booked_help'), 'ok'); }));
    on(el, 'click', '[data-unbook]', (_e, b) => busy(b, async () => { await q(sb.from('ride_bookings').delete().eq('ride_id', b.dataset.unbook).eq('user_id', myId())); data.invalidate('bookings'); render(); }));
    on(el, 'click', '[data-del-ride]', async (_e, b) => { if (await confirmBox(t('ride.confirm_delete'))) busy(b, async () => { await q(sb.from('rides').delete().eq('id', b.dataset.delRide)); data.invalidate('rides'); render(); }); });
    on(el, 'click', '[data-report]', (_e, b) => reportDialog(b.dataset.kind, b.dataset.report));
    on(el, 'click', '[data-contacts]', (_e, b) => busy(b, async () => {
      const list = await rpc('ride_contacts', { p_ride: b.dataset.contacts });
      openModal(t('ride.contacts'), html`<div class="stack">${list.map((c) => html`<div class="item"><div class="ii bg-${c.is_driver ? 'green' : 'blue'}">${icon(c.is_driver ? 'car' : 'user', 18)}</div>
        <div class="grow"><div class="item-t">${c.full_name}</div><div class="item-b">${t(c.is_driver ? 'ride.driver' : 'ride.passenger')}</div></div>
        ${c.phone ? html`<a class="btn sm" href="tel:${c.phone.replace(/[^+0-9]/g, '')}">${icon('phone', 14)} ${c.phone}</a>` : html`<span class="xs muted">${c.user_id === myId() ? t('ride.you') : t('ride.no_phone')}</span>`}</div>`)}
        <p class="xs muted">${t('ride.contacts_help')}</p></div>`);
    }));
  },
};
async function ridesList() {
  const [rides, bookings] = await data.all('rides', 'bookings');
  const list = rides.filter((r) => r.status === 'visible');
  return html`<div class="warn mt">${icon('shield', 16)} ${t('ride.safety')}</div>
    ${html`<button class="btn primary block mt" data-new-ride>${icon('plus', 16)} ${t('ride.new')}</button>`}
    <div class="stack mt">${list.length ? list.map((r) => { const b = bookings.filter((x) => x.ride_id === r.id); const booked = b.some((x) => x.user_id === myId()); const owner = r.author_id === myId();
      return html`<div class="card"><div class="between"><div class="row">${icon('car', 18)}<b>${r.from_place} → CMC</b></div>${chip(t('ride.' + r.kind), r.kind === 'offer' ? 'green' : 'amber')}</div>
        <div class="muted small mt-s">${icon('clock', 12)} ${hm(r.depart_at)} · ${(r.days || []).map((d) => dayName(d, 'short')).join(', ')}${r.kind === 'offer' ? ' · ' + t('ride.seats_left', { n: Math.max(0, r.seats - b.length), total: r.seats }) : ''}</div>
        ${r.note ? html`<div class="small mt-s pre">${r.note}</div>` : ''}<div class="muted small">${ref.personName(r.author_id) || t('common.someone')}</div>
        ${owner && b.length ? html`<div class="small mt-s"><b>${t('ride.passengers')}</b> ${b.map((x) => ref.personName(x.user_id)).join(', ')}</div>` : ''}
        <div class="row wrap mt">${owner ? html`<button class="btn sm danger" data-del-ride="${r.id}">${icon('trash', 14)} ${t('common.delete')}</button>`
          : r.kind === 'offer' ? (booked ? html`<button class="btn sm ghost" data-unbook="${r.id}">${t('ride.cancel_booking')}</button>`
          : html`<button class="btn sm primary" data-book="${r.id}" ${r.seats - b.length <= 0 ? 'disabled' : ''}>${t('ride.book')}</button>`) : ''}
          ${owner || booked ? html`<button class="btn sm ghost" data-contacts="${r.id}">${icon('users', 14)} ${t('ride.contacts')}</button>` : ''}
          ${!owner ? html`<button class="icon-btn plain" data-report="${r.id}" data-kind="ride" aria-label="${t('report.short')}">${icon('flag', 14)}</button>` : ''}</div></div>`; })
      : empty(t('ride.none'), 'car')}</div>`;
}
function newRideDialog() {
  openModal(t('ride.new'), html`<form class="stack" novalidate>
    <div class="seg full"><label><input type="radio" name="kind" value="offer" checked> ${t('ride.offer')}</label><label><input type="radio" name="kind" value="request"> ${t('ride.request')}</label></div>
    <input class="input" name="from_place" required minlength="2" maxlength="80" placeholder="${t('ride.from_ph')}" aria-label="${t('ride.from')}">
    <div class="grid2"><input class="input" type="time" name="depart_at" required value="07:45" aria-label="${t('ride.time')}">
      <input class="input" type="number" name="seats" min="1" max="8" value="3" aria-label="${t('ride.seats')}"></div>
    <div class="row wrap">${[1, 2, 3, 4, 5, 6].map((d) => html`<label class="check"><input type="checkbox" name="d${d}" ${d <= 5 ? 'checked' : ''}> ${dayName(d, 'short')}</label>`)}</div>
    <textarea class="input" name="note" rows="2" maxlength="300" placeholder="${t('ride.note_ph')}"></textarea>
    <button class="btn primary block">${t('ride.publish')}</button></form>`, {
    onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => {
        const v = formData(f);
        const days = [1, 2, 3, 4, 5, 6].filter((d) => v['d' + d]);
        if (!days.length) throw new Error(t('ride.pick_day'));
        await q(sb.from('rides').insert({ kind: v.kind, from_place: v.from_place, depart_at: v.depart_at, seats: Number(v.seats || 1), days, note: v.note }));
        closeModal(); data.invalidate('rides'); render(); toast(t('ride.published'), '', 'ok');
      }); }),
  });
}
