// Annonces et notifications (filtres de la démo : Tous, Non lus, Important, Changements, Rappels ; « Tout lire »)
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, ago } from '../../core/i18n.js';
import { myId } from '../../core/store.js';
import { on, render, go } from '../../core/router.js';
import { sb, q } from '../../services/api.js';
import { data, refreshUnread } from '../../services/data.js';
import { busy } from '../../core/ui.js';
import { annItem, NOTIF_ICON, CHANGE_KINDS } from '../../shared/components.js';
import { topbar, wireTopbar } from '../ui.js';

export const announcementsView = {
  title: 'nav.announcements',
  async render(el) {
    const list = (await data.get('announcements')).filter((a) => a.status === 'published');
    mount(el, html`${topbar(t('nav.announcements'))}<div class="stack">${list.length ? list.map((a) => annItem(a)) : html`<div class="card empty">${icon('mega', 28)}${t('ann.none')}</div>`}</div>`);
    wireTopbar(el);
  },
};

const nf = { f: 'all' };
export const FILTERS = [['all', 'notif.f_all'], ['unread', 'notif.f_unread'], ['important', 'notif.f_important'], ['changes', 'notif.f_changes'], ['reminders', 'notif.f_reminders']];
export const filterNotifs = (list, read, f) => list.filter((n) => f === 'all' || (f === 'unread' && !read.has(n.id)) || (f === 'important' && n.important)
  || (f === 'changes' && CHANGE_KINDS.includes(n.kind)) || (f === 'reminders' && n.kind === 'reminder'));
export const notifItem = (n, read) => { const [ic, bg] = NOTIF_ICON[n.kind] || ['bell', 'blue'];
  return html`<button class="item ${read.has(n.id) ? '' : 'unread'} ${n.important ? 'imp' : ''} text-start" data-n="${n.id}">
    <div class="ii bg-${bg}">${icon(ic)}</div><div class="grow"><div class="item-t">${n.title}</div>${n.body ? html`<div class="item-b pre">${n.body}</div>` : ''}
    <div class="row wrap chips">${n.target_kind === 'user' ? html`<span class="chip green">${t('notif.personal')}</span>` : n.target_kind === 'all' ? html`<span class="chip violet">${t('common.all')}</span>` : ''}
      ${n.important ? html`<span class="chip red">${t('ann.important')}</span>` : ''}<span class="xs muted">${ago(n.created_at)}</span></div></div>${n.link ? icon('chev', 16, 'class="flip"') : ''}</button>`; };
export async function markRead(ids) {
  if (!ids.length) return;
  await q(sb.from('notification_reads').upsert(ids.map((id) => ({ notification_id: id, user_id: myId() })), { onConflict: 'notification_id,user_id', ignoreDuplicates: true }));
  data.invalidate('reads'); await refreshUnread();
}
export const openLink = (link, map = {}) => { if (!link) return false; const [name, param] = link.split(':'); go(map[name] || name, param); return true; };

export const notificationsView = {
  title: 'nav.notifications',
  async render(el) {
    const [list, reads] = await data.all('notifications', 'reads');
    const read = new Set(reads.map((r) => r.notification_id));
    const shown = filterNotifs(list, read, nf.f);
    const unread = list.filter((n) => !read.has(n.id));
    mount(el, html`${topbar(t('nav.notifications'), unread.length ? html`<button class="btn sm ghost" data-all>${icon('check', 16)} ${t('notif.mark_all')}</button>` : '')}
      <div class="tabs mb">${FILTERS.map(([k, l]) => html`<button class="tab ${nf.f === k ? 'on' : ''}" data-f="${k}">${t(l)}</button>`)}</div>
      <div class="stack">${shown.length ? shown.map((n) => notifItem(n, read)) : html`<div class="card empty">${icon('bell', 28)}${t('notif.none')}</div>`}</div>
      <p class="xs muted mt">${t('notif.honest')}</p>`);
    wireTopbar(el);
    on(el, 'click', '[data-f]', (_e, b) => { nf.f = b.dataset.f; render(); });
    on(el, 'click', '[data-all]', (_e, b) => busy(b, async () => { await markRead(unread.map((n) => n.id)); render(); }));
    on(el, 'click', '[data-n]', (_e, b) => busy(b, async () => {
      const n = list.find((x) => x.id === b.dataset.n);
      if (!read.has(n.id)) await markRead([n.id]);
      if (!openLink(n.link, { schedule: 'schedule', assignments: 'assignments', announcements: 'announcements', attendance: 'attendance' })) render();
    }));
  },
};
