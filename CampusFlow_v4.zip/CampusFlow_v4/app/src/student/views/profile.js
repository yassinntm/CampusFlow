// Profil (démo : identité, assiduité, réglages) + accessibilité, confidentialité, compte, export des données ; page Assiduité détaillée
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, setLang, getLang, fmtNum } from '../../core/i18n.js';
import { store, ref, me, myId, pref } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q } from '../../services/api.js';
import { data } from '../../services/data.js';
import { hm } from '../../core/dates.js';
import { openModal, closeModal, formData, busy, toast } from '../../core/ui.js';
import { initials, download } from '../../shared/components.js';
import { applyPrefs } from '../../shared/boot.js';
import { topbar, wireTopbar } from '../ui.js';
import { saveSettings } from './planner.js';

const ST = { present: 'green', absent: 'red', late: 'amber', excused: 'blue' };
const attendanceData = async () => {
  const [records, sessions, summary, justifs] = await data.all('attendance', 'sessions', 'summary', 'justifications');
  const s = summary.find((x) => x.student_id === myId());
  const bySession = Object.fromEntries(sessions.map((x) => [x.id, x]));
  const rows = records.filter((r) => r.student_id === myId() && bySession[r.session_id]).sort((a, b) => bySession[b.session_id].session_date.localeCompare(bySession[a.session_id].session_date));
  return { s, bySession, rows, justifs };
};
const statsCards = (s) => html`<div class="grid3 stats3">
  <div class="stat"><b class="c-green">${s ? s.present + s.excused : 0}</b><span>${t('att.presences')}</span></div>
  <div class="stat"><b class="c-red">${s?.absent || 0}</b><span>${t('att.absences')}</span></div>
  <div class="stat"><b class="c-amber">${s?.late || 0}</b><span>${t('att.lates')}</span></div></div>`;

export const profileView = {
  title: 'nav.profile',
  async render(el) {
    const p = me(); const stt = store.get().settings;
    const { s, rows, bySession } = await attendanceData();
    const perm = 'Notification' in window ? Notification.permission : 'unsupported';
    mount(el, html`${topbar(t('nav.profile'))}
      <div class="card row profile-card"><div class="ii bg-blue avatar-lg">${initials(p.full_name)}</div>
        <div class="grow"><div class="pname">${p.full_name}</div><div class="small muted">${p.email}</div>
          <div class="row wrap mt-s"><span class="chip blue">${t('common.group')} ${ref.groupCode(p.group_id)}</span><span class="chip green">${icon('shield', 12)} ${t('sched.official')}</span></div></div>
        <button class="icon-btn plain" data-edit aria-label="${t('profile.edit')}">${icon('edit', 18)}</button></div>
      <div class="sec"><div class="sec-h"><h2>${t('tile.attendance')}</h2><a class="link" href="#/attendance">${t('common.details')}</a></div>
        ${statsCards(s)}
        <div class="card audit-list mt">${rows.length ? rows.slice(0, 5).map((r) => { const se = bySession[r.session_id];
          return html`<div class="audit"><span class="chip ${ST[r.status]}">${t('att.' + r.status)}</span><span class="grow">${ref.moduleName(se.module_id)}</span><span class="xs muted">${fmtDate(se.session_date, { day: 'numeric', month: 'short' })}</span></div>`; })
          : html`<div class="empty small">${t('att.none_yet')}</div>`}</div>
        <div class="xs muted mt-s">${s ? t('att.based_on', { n: s.total }) : t('att.source')}</div></div>
      <div class="sec card stack"><h3>${t('profile.settings')}</h3>
        <div class="between"><span class="row small">${icon('globe', 18)} ${t('common.language')}</span><div class="seg"><button class="${getLang() === 'fr' ? 'on' : ''}" data-lang="fr">Français</button><button class="${getLang() === 'ar' ? 'on' : ''}" data-lang="ar">العربية</button></div></div>
        <div class="between"><span class="row small">${icon(document.documentElement.dataset.theme === 'dark' ? 'moon' : 'sun', 18)} ${t('profile.theme')}</span><div class="seg"><button class="${document.documentElement.dataset.theme !== 'dark' ? 'on' : ''}" data-theme="light">${t('profile.light')}</button><button class="${document.documentElement.dataset.theme === 'dark' ? 'on' : ''}" data-theme="dark">${t('profile.dark_short')}</button></div></div>
        <div class="between"><span class="row small">${icon('bell', 18)} ${t('profile.browser_notif')}</span>
          <label class="switch"><input type="checkbox" data-bnotif ${stt.browserNotif && perm === 'granted' ? 'checked' : ''} ${perm === 'unsupported' ? 'disabled' : ''}><span></span></label></div>
        <p class="xs muted">${t('profile.browser_notif_help')}</p></div>
      <div class="sec card stack"><h3>${t('profile.accessibility')}</h3>
        <div class="between"><span class="small">${t('profile.font_size')}</span><div class="seg">${['normal', 'large', 'xlarge'].map((k) => html`<button class="${pref.get('fontsize', 'normal') === k ? 'on' : ''}" data-font="${k}">${t('profile.font_' + k)}</button>`)}</div></div>
        <div class="between"><span class="small">${t('profile.reduce_motion')}</span><label class="switch"><input type="checkbox" data-motion ${pref.get('motion', 'full') === 'reduced' ? 'checked' : ''}><span></span></label></div></div>
      <div class="sec card stack"><h3>${t('profile.privacy_title')}</h3>
        <div class="between"><div><div class="small">${t('profile.share_phone')}</div><div class="xs muted">${p.phone ? t('profile.share_phone_help') : t('profile.share_phone_nophone')}</div></div>
          <label class="switch"><input type="checkbox" data-share ${p.share_phone ? 'checked' : ''} ${p.phone ? '' : 'disabled'}><span></span></label></div>
        <p class="xs muted">${t('profile.privacy')}</p></div>
      <div class="sec card stack"><h3>${t('profile.security')}</h3>
        <button class="btn ghost" data-pw>${icon('key', 16)} ${t('profile.change_password')}</button>
        <button class="btn ghost" data-export>${icon('down', 16)} ${t('profile.export')}</button></div>
      <button class="btn danger block sec" data-logout>${icon('out', 18)} ${t('auth.logout')}</button>
      <p class="xs muted center mt">CampusFlow · CMC Agadir</p>`);
    wireTopbar(el);
    on(el, 'click', '[data-lang]', (_e, b) => busy(b, async () => { setLang(b.dataset.lang); pref.set('lang', b.dataset.lang); await saveSettings({ lang: b.dataset.lang }); render(); }));
    on(el, 'click', '[data-theme]', (_e, b) => { pref.set('theme', b.dataset.theme); applyPrefs(); render(); });
    on(el, 'click', '[data-font]', (_e, b) => { pref.set('fontsize', b.dataset.font); applyPrefs(); render(); });
    on(el, 'change', '[data-motion]', (_e, c) => { pref.set('motion', c.checked ? 'reduced' : 'full'); applyPrefs(); });
    on(el, 'change', '[data-share]', (_e, c) => busy(c, async () => { await q(sb.from('profiles').update({ share_phone: c.checked }).eq('id', myId())); store.set({ profile: { ...p, share_phone: c.checked } }); toast(t('common.saved'), '', 'ok'); }));
    on(el, 'change', '[data-bnotif]', async (_e, c) => {
      if (c.checked && Notification.permission !== 'granted') {
        const r = await Notification.requestPermission();
        if (r !== 'granted') { c.checked = false; toast(t('notif.perm_denied'), '', 'error'); return; }
      }
      saveSettings({ browserNotif: c.checked }).catch((e) => toast(e.message, '', 'error'));
    });
    on(el, 'click', '[data-edit]', () => openModal(t('profile.edit'), html`<form class="stack" novalidate>
      <div class="field"><label>${t('auth.full_name')}</label><input class="input" name="full_name" required minlength="3" maxlength="80" value="${p.full_name}"></div>
      <div class="field"><label>${t('profile.phone')}</label><input class="input" name="phone" type="tel" maxlength="20" pattern="[+0-9 ]{8,20}" value="${p.phone || ''}"></div>
      <p class="muted small">${t('profile.locked_fields')}</p><button class="btn primary block">${t('common.save')}</button></form>`, {
      onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; if (!f.checkValidity()) return f.reportValidity();
        busy(f.querySelector('button'), async () => { const v = formData(f);
          await q(sb.from('profiles').update({ full_name: v.full_name, phone: v.phone, ...(v.phone ? {} : { share_phone: false }) }).eq('id', myId()));
          store.set({ profile: { ...p, full_name: v.full_name, phone: v.phone } }); data.invalidate('people'); closeModal(); render(); toast(t('common.saved'), '', 'ok'); }); }),
    }));
    on(el, 'click', '[data-pw]', () => openModal(t('profile.change_password'), html`<form class="stack"><div class="field"><label>${t('auth.password')}</label>
      <input class="input" name="password" type="password" minlength="8" autocomplete="new-password" required><small class="muted">${t('auth.password_rule')}</small></div>
      <button class="btn primary block">${t('common.save')}</button></form>`, {
      onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const pw = e.target.password.value;
        if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return toast(t('auth.password_rule'), '', 'error');
        busy(e.target.querySelector('button'), async () => { const { error } = await sb.auth.updateUser({ password: pw }); if (error) throw error; closeModal(); toast(t('common.saved'), '', 'ok'); }); }),
    }));
    on(el, 'click', '[data-export]', (_e, b) => busy(b, async () => {
      const keys = ['tasks', 'study', 'progress', 'attendance', 'justifications', 'submissions'];
      const vals = await data.all(...keys);
      const out = { exported_at: new Date().toISOString(), profile: p, settings: stt, ...Object.fromEntries(keys.map((k, i) => [k, vals[i].filter((x) => !x.student_id || x.student_id === myId())])) };
      download(`campusflow-mes-donnees-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(out, null, 2), 'application/json');
    }));
  },
};

export const attendanceView = {
  title: 'tile.attendance',
  async render(el) {
    const { s, rows, bySession, justifs } = await attendanceData();
    const jOf = (sid) => justifs.find((j) => j.session_id === sid && j.student_id === myId());
    mount(el, html`${topbar(t('tile.attendance'))}
      <div class="card att-rate"><div class="between"><div><div class="xs muted b">${t('att.rate')}</div><div class="big-num">${s?.rate == null ? '—' : fmtNum(s.rate) + ' %'}</div></div>
        <div class="xs muted text-end">${s ? t('att.based_on', { n: s.total }) : t('att.none_yet')}</div></div>${s?.rate != null ? html`<div class="progress mt-s"><i style="width:${s.rate}%"></i></div>` : ''}</div>
      <div class="sec">${statsCards(s)}</div>
      <section class="sec"><h2>${t('att.history')}</h2><div class="stack mt-s">
        ${rows.length ? rows.map((r) => { const se = bySession[r.session_id]; const j = jOf(r.session_id);
          return html`<div class="item"><div class="ii bg-${ST[r.status]}">${icon(r.status === 'present' ? 'check' : r.status === 'excused' ? 'shield' : 'alert', 18)}</div>
            <div class="grow"><div class="item-t">${ref.moduleName(se.module_id)}</div><div class="item-b">${fmtDate(se.session_date, { weekday: 'short', day: 'numeric', month: 'short' })} · ${hm(se.start_time)}–${hm(se.end_time)}</div>
            <div class="row wrap chips"><span class="chip ${ST[r.status]}">${t('att.' + r.status)}${r.status === 'late' && r.minutes_late ? ` (${r.minutes_late} min)` : ''}</span>
            ${j ? html`<span class="chip ${j.status === 'accepted' ? 'green' : j.status === 'rejected' ? 'red' : 'amber'}">${t('justif.' + j.status)}</span>` : ''}</div></div>
            ${(r.status === 'absent' || r.status === 'late') && !j ? html`<button class="btn sm" data-justify="${r.session_id}">${t('justif.send')}</button>` : ''}</div>`; })
          : html`<div class="card empty">${icon('check', 28)}${t('att.no_records')}</div>`}</div></section>`);
    wireTopbar(el);
    on(el, 'click', '[data-justify]', (_e, b) => openModal(t('justif.send'), html`<form class="stack"><p class="muted small">${t('justif.help')}</p>
      <textarea class="input" name="reason" rows="4" required minlength="5" maxlength="1000" placeholder="${t('justif.ph')}"></textarea>
      <button class="btn primary block">${t('common.send')}</button></form>`, {
      onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); if (!e.target.checkValidity()) return e.target.reportValidity();
        busy(e.target.querySelector('button'), async () => {
          await q(sb.from('absence_justifications').insert({ session_id: b.dataset.justify, student_id: myId(), reason: e.target.reason.value.trim() }));
          closeModal(); data.invalidate('justifications'); render(); toast(t('justif.sent'), '', 'ok');
        }); }),
    }));
  },
};
