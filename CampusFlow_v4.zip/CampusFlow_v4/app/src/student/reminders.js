// Rappels du Planner (départ, avant chaque cours) : affichés quand l'application est ouverte (alerte + notification du
// navigateur si autorisée). Il n'y a pas de notification « push » serveur : rien n'est envoyé quand l'application est fermée.
import { t } from '../core/i18n.js';
import { store, ref, me } from '../core/store.js';
import { data } from '../services/data.js';
import { todayISO, nowMinutes, toMin, fromMin } from '../core/dates.js';
import { effectiveSlots } from '../shared/components.js';
import { notifyLocal } from '../shared/boot.js';
import { depPrefs, departureInfo } from './views/planner.js';

const fired = new Set();
const once = (key, n) => {
  const k = 'cf.rem.' + key;
  try { if (fired.has(k) || sessionStorage.getItem(k)) return; sessionStorage.setItem(k, '1'); } catch { if (fired.has(k)) return; }
  fired.add(k); notifyLocal(n);
};
async function tick() {
  if (!store.get().profile) return;
  const p = depPrefs();
  const [slots, exceptions] = await data.all('slots', 'exceptions');
  const mine = slots.filter((s) => s.group_id === me().group_id);
  const today = todayISO(); const nm = nowMinutes();
  if (p.depRem) {
    const d = departureInfo(mine, exceptions, p);
    if (d?.isToday && nm >= d.leaveMin - Number(p.interval) && nm <= d.leaveMin) {
      once(`dep.${today}`, { id: 'dep' + today, title: t('rem.departure_title', { time: fromMin(d.leaveMin) }), body: t('rem.departure_body', { m: ref.moduleName(d.first.module_id), time: d.first.start_time.slice(0, 5) }) });
    }
  }
  if (p.classRem) {
    for (const s of effectiveSlots(mine, exceptions, today).filter((x) => x.status === 'active')) {
      const st = toMin(s.start_time);
      if (nm >= st - Number(p.interval) && nm < st) once(`class.${today}.${s.id}`, { id: 'c' + s.id, title: t('rem.class_title', { m: ref.moduleName(s.module_id) }), body: t('rem.class_body', { time: s.start_time.slice(0, 5), room: ref.roomName(s.room_id) || '—' }) });
    }
  }
}
export function startReminders() {
  tick().catch(() => {});
  setInterval(() => tick().catch(() => {}), 30000);
}
