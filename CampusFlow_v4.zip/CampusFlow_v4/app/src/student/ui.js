// Barre de titre des pages (identique à la démo : titre + recherche + cloche)
import { html } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { store } from '../core/store.js';
import { openSearch } from './search.js';

export const topbar = (title, extra = '') => {
  const u = store.get().unread;
  return html`<div class="topbar"><h1>${title}</h1><div class="row">${extra}
    <button class="icon-btn" data-search aria-label="${t('nav.search')}">${icon('search')}</button>
    <a class="icon-btn" href="#/notifs" aria-label="${t('nav.notifications')}">${icon('bell')}${u ? html`<span class="dot">${u > 99 ? '99+' : u}</span>` : ''}</a></div></div>`;
};
// Branche la recherche sur le bouton de la barre de titre de la vue
export const wireTopbar = (el) => el.querySelectorAll('[data-search]').forEach((b) => (b.onclick = () => openSearch()));
export const sectionHead = (title, to, label = t('common.see_all')) => html`<div class="sec-h"><h2>${title}</h2>${to ? html`<a class="link" href="#/${to}">${label}</a>` : ''}</div>`;
