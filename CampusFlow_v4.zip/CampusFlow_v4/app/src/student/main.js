// CampusFlow Stagiaire — application dédiée aux stagiaires (même backend que l'application d'administration)
import { html, mount } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t } from '../core/i18n.js';
import { store, ref } from '../core/store.js';
import { route } from '../core/router.js';
import { startApp, messageScreen, otherAppUrl } from '../shared/boot.js';
import { initials } from '../shared/components.js';
import { homeView } from './views/home.js';
import { scheduleView } from './views/schedule.js';
import { assignmentsView, examsView } from './views/assignments.js';
import { plannerView } from './views/planner.js';
import { announcementsView, notificationsView } from './views/inbox.js';
import { profileView, attendanceView } from './views/profile.js';
import { communityView, postView, studyGroupsView, ridesView } from './views/community.js';
import { freeTimeView, resourcesView, aiView, campusView } from './views/campus.js';
import { startReminders } from './reminders.js';

// Navigation de la démo d'origine ; « extra » = visibles seulement dans la barre latérale (ordinateur)
const NAV = [
  ['home', 'home', 'nav.home', ['home']],
  ['schedule', 'cal', 'nav.schedule_short', ['schedule']],
  ['assignments', 'book', 'nav.assignments', ['assignments'], true],
  ['exams', 'target', 'nav.exams', ['exams'], true],
  ['planner', 'clock', 'nav.planner_short', ['planner']],
  ['announcements', 'mega', 'nav.announcements', ['announcements'], true],
  ['community', 'chat', 'nav.community', ['community', 'post', 'studygroups', 'rides'], true],
  ['campus', 'grid', 'nav.campus', ['campus', 'freetime', 'resources', 'ai', 'attendance'], true],
  ['notifs', 'bell', 'nav.notifications', ['notifs']],
  ['profile', 'user', 'nav.profile_short', ['profile']],
];

function layout(name) {
  const { profile, unread, online } = store.get();
  mount(document.getElementById('app'), html`<div class="shell student">
    <nav class="nav" aria-label="${t('nav.menu')}">
      <div class="brand"><div class="logo">${icon('spark', 20)}</div>CampusFlow</div>
      ${NAV.map(([to, ic, label, match, extra]) => html`<a class="nav-item ${extra ? 'extra' : ''} ${match.includes(name) ? 'on' : ''}" href="#/${to}" ${match.includes(name) ? 'aria-current="page"' : ''}>
        ${icon(ic, 22)}<span>${t(label)}</span>${to === 'notifs' && unread ? html`<span class="badge">${unread}</span>` : ''}</a>`)}
      <a class="nav-foot card" href="#/profile"><div class="row"><div class="ii bg-blue avatar-sm">${initials(profile.full_name)}</div>
        <div class="grow"><div class="nf-name">${profile.full_name}</div><div class="xs muted">${t('common.group')} ${ref.groupCode(profile.group_id)}</div></div></div></a>
    </nav>
    <main class="main">${online ? '' : html`<div class="offline" role="status">${icon('wifi', 16)} ${t('common.offline')}</div>`}<div id="content"></div></main>
  </div>`);
  return document.getElementById('content');
}

function register() {
  const views = { home: homeView, schedule: scheduleView, assignments: assignmentsView, exams: examsView, planner: plannerView,
    announcements: announcementsView, notifs: notificationsView, profile: profileView, attendance: attendanceView,
    community: communityView, post: postView, studygroups: studyGroupsView, rides: ridesView,
    campus: campusView, freetime: freeTimeView, resources: resourcesView, ai: aiView };
  for (const [k, v] of Object.entries(views)) route(k, v);
}

startApp({
  kind: 'student',
  accept: (p) => p.role === 'student',
  // Le personnel utilise l'application d'administration
  redirect: () => { location.replace(otherAppUrl('student')); },
  layout,
  register,
  onReady: () => startReminders(),
});
