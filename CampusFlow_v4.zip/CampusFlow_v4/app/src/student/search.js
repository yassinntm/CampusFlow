// Recherche globale (fenêtre comme dans la démo) : emploi du temps, modules, formateurs, devoirs, examens, annonces,
// ressources, communauté — uniquement ce que le compte peut voir (filtré par RLS côté serveur)
import { html, mount, esc, raw } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t, dayName, fmtInstant } from '../core/i18n.js';
import { store, ref, me } from '../core/store.js';
import { go } from '../core/router.js';
import { data } from '../services/data.js';
import { hm } from '../core/dates.js';
import { openModal, closeModal } from '../core/ui.js';
import { normalize } from '../shared/components.js';

// Surligne la recherche sans jamais injecter de HTML venant des données (échappement avant le surlignage)
const hl = (s, n) => {
  const txt = String(s || ''); if (!n) return txt;
  const norm = normalize(txt); const i = norm.indexOf(n);
  if (i < 0) return txt;
  return raw(esc(txt.slice(0, i)) + '<mark>' + esc(txt.slice(i, i + n.length)) + '</mark>' + esc(txt.slice(i + n.length)));
};
export async function openSearch() {
  const sheet = openModal(t('nav.search'), html`<input class="input" data-q placeholder="${t('search.ph')}" autocomplete="off" aria-label="${t('nav.search')}"><div class="search-res mt" data-res></div>`);
  const [slots, assessments, anns, resources, posts] = await data.all('slots', 'assessments', 'announcements', 'resources', 'posts');
  const mine = slots.filter((s) => s.group_id === me().group_id);
  const input = sheet.querySelector('[data-q]'); const box = sheet.querySelector('[data-res]');
  const run = () => {
    const n = normalize(input.value.trim());
    if (n.length < 2) { mount(box, html`<div class="empty small">${t('search.hint')}</div>`); return; }
    const has = (...xs) => xs.some((x) => normalize(x).includes(n));
    const res = [
      ...mine.filter((s) => has(ref.moduleName(s.module_id), ref.personName(s.teacher_id), ref.roomName(s.room_id)))
        .map((s) => ({ i: 'cal', c: 'bg-blue', t: ref.moduleName(s.module_id), b: `${dayName(s.weekday)} ${hm(s.start_time)}–${hm(s.end_time)} · ${ref.roomName(s.room_id)} · ${ref.personName(s.teacher_id)}`, to: 'schedule' })),
      ...assessments.filter((a) => has(a.title, a.description, ref.moduleName(a.module_id)))
        .map((a) => ({ i: a.kind === 'exam' ? 'target' : 'book', c: a.kind === 'exam' ? 'bg-red' : 'bg-amber', t: a.title, b: `${t('assess.' + a.kind)} · ${ref.moduleName(a.module_id)} · ${fmtInstant(a.due_at)}`, to: a.kind === 'exam' ? 'exams' : 'assignments' })),
      ...anns.filter((a) => a.status === 'published' && has(a.title, a.body)).map((a) => ({ i: 'mega', c: 'bg-violet', t: a.title, b: a.body.slice(0, 100), to: 'announcements' })),
      ...resources.filter((r) => has(r.title, r.description, ref.moduleName(r.module_id))).map((r) => ({ i: 'file', c: 'bg-blue', t: r.title, b: ref.moduleName(r.module_id), to: 'resources' })),
      ...posts.filter((p) => has(p.title, p.body)).map((p) => ({ i: 'chat', c: 'bg-green', t: p.title, b: t('comm.' + p.kind), to: 'post/' + p.id })),
      ...store.get().ref.modules.filter((m) => has(m.name, m.code) && mine.some((s) => s.module_id === m.id)).map((m) => ({ i: 'book', c: 'bg-green', t: m.name, b: t('common.module') + ' · ' + m.code, to: 'resources' })),
    ];
    mount(box, res.length ? html`${res.slice(0, 30).map((r) => html`<button class="item text-start w-full" data-go="${r.to}"><div class="ii ${r.c}">${icon(r.i)}</div>
      <div class="grow"><div class="item-t">${hl(r.t, n)}</div><div class="item-b">${hl(r.b, n)}</div></div></button>`)}` : html`<div class="empty small">${t('search.none', { q: input.value.trim() })}</div>`);
  };
  input.addEventListener('input', run); run();
  box.addEventListener('click', (e) => { const b = e.target.closest('[data-go]'); if (!b) return; closeModal(); const [name, ...p] = b.dataset.go.split('/'); go(name, p.join('/') || undefined); });
  input.focus();
}
