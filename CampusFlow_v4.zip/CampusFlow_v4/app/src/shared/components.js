// Éléments réutilisés par les deux applications — balisage identique à la démo d'origine (slot, item, chips)
import { html } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t, fmtDate, fmtInstant, ago } from '../core/i18n.js';
import { ref } from '../core/store.js';
import { hm, toMin, nowMinutes, todayISO, isoWeekday, isoOfInstant, diffDays } from '../core/dates.js';

export const KIND_CLASS = { cours: 'blue', tp: 'violet', td: 'green', exam: 'red', autre: '' };

// Créneaux d'une date précise : emploi du temps hebdomadaire + annulations / déplacements ponctuels de ce jour
export const effectiveSlots = (slots, exceptions, iso) => slots
  .filter((s) => s.weekday === isoWeekday(iso))
  .map((s) => {
    const ex = (exceptions || []).find((e) => e.slot_id === s.id && e.session_date === iso);
    if (!ex) return s;
    if (ex.kind === 'cancelled') return { ...s, status: 'cancelled', note: ex.note || t('slot.cancelled_today'), exception: ex };
    return { ...s, room_id: ex.room_id || s.room_id, start_time: ex.start_time || s.start_time, end_time: ex.end_time || s.end_time,
      note: [t('slot.moved_today'), ex.note].filter(Boolean).join(' · '), exception: ex };
  })
  .sort((a, b) => toMin(a.start_time) - toMin(b.start_time));
export const slotsOn = (slots, iso, exceptions = []) => effectiveSlots(slots, exceptions, iso);

export const slotCard = (s, { date = null, showGroup = false, actions = '' } = {}) => {
  const isToday = date && date === todayISO();
  const now = isToday && s.status === 'active' && toMin(s.start_time) <= nowMinutes() && nowMinutes() < toMin(s.end_time);
  const cls = s.status === 'cancelled' ? 'cancelled' : s.note ? 'modified' : '';
  const badge = s.status === 'cancelled' ? html`<span class="chip red">${t('slot.cancelled')}</span>` : s.note ? html`<span class="chip amber">${t('slot.modified')}</span>` : '';
  return html`<div class="slot ${cls} ${now ? 'now' : ''}">
    <div class="slot-time"><b>${hm(s.start_time)}</b><span>${hm(s.end_time)}</span></div>
    <div class="slot-body"><div class="slot-title"><span class="t">${ref.moduleName(s.module_id)}</span>${badge}
      ${s.kind && s.kind !== 'cours' ? html`<span class="chip ${KIND_CLASS[s.kind] || ''}">${t('kind.' + s.kind)}</span>` : ''}${now ? html`<span class="chip blue">${t('slot.now')}</span>` : ''}</div>
      <div class="slot-meta">${icon('pin', 14)} ${ref.roomName(s.room_id) || '—'} <span>·</span> ${ref.personName(s.teacher_id) || t('slot.teacher_unknown')}
        ${showGroup ? html`<span>·</span> ${ref.groupCode(s.group_id)}` : ''}</div>
      ${s.note ? html`<div class="slot-note">${icon('alert', 14)}<span>${s.note}</span></div>` : ''}</div>${actions}</div>`;
};

export const PRIO = { high: 'red', normal: 'amber', low: '' };
export const dueChip = (ts) => {
  const d = diffDays(todayISO(), isoOfInstant(ts));
  if (new Date(ts) < new Date()) return html`<span class="chip">${t('due.past')}</span>`;
  if (d === 0) return html`<span class="chip red">${t('due.today')}</span>`;
  if (d === 1) return html`<span class="chip amber">${t('due.tomorrow')}</span>`;
  return html`<span class="chip ${d <= 3 ? 'amber' : ''}">${t('due.in_days', { n: d })}</span>`;
};
export const targetChip = (groupId) => (groupId ? html`<span class="chip blue">${ref.groupCode(groupId)}</span>` : html`<span class="chip violet">${t('common.all')}</span>`);

// Devoir / examen (structure de la démo : icône ambre, titre, matière · formateur, consigne, chips date / salle / cible)
export const assignItem = (a, { status = null, teacher = null, actions = '', extra = '', onClick = false } = {}) => html`<div class="item ${status === 'done' ? 'done' : ''} ${onClick ? 'clickable' : ''}" ${onClick ? html`data-open="${a.id}" role="button" tabindex="0"` : ''}>
  <div class="ii ${a.kind === 'exam' ? 'bg-red' : 'bg-amber'}">${icon(a.kind === 'exam' ? 'target' : 'book')}</div>
  <div class="grow"><div class="between top-start"><div class="item-t">${a.title}</div>${isoOfInstant(a.due_at) === todayISO() ? html`<span class="chip red">${t('due.today')}</span>` : ''}</div>
    <div class="item-b">${ref.moduleName(a.module_id)}${teacher ? ' · ' + teacher : ''}</div>
    ${a.description ? html`<div class="item-b desc">${a.description}</div>` : ''}
    <div class="row wrap chips">
      <span class="chip">${icon('cal', 12)} ${fmtInstant(a.due_at, { weekday: 'short', day: 'numeric', month: 'short' })} · ${fmtInstant(a.due_at, { hour: '2-digit', minute: '2-digit' })}</span>
      ${a.room_id ? html`<span class="chip">${icon('pin', 12)} ${ref.roomName(a.room_id)}</span>` : ''}
      ${a.duration_min ? html`<span class="chip">${icon('clock', 12)} ${t('assess.duration', { n: a.duration_min })}</span>` : ''}
      ${targetChip(a.group_id)}${a.priority === 'high' ? html`<span class="chip red">${t('prio.high')}</span>` : ''}
      ${status ? html`<span class="chip ${status === 'done' ? 'green' : status === 'in_progress' ? 'amber' : ''}">${t('progress.' + status)}</span>` : ''}${extra}</div>
  </div>${actions}</div>`;

// Annonce (structure de la démo : épinglée, importante, cible, date relative)
export const annItem = (a, actions = '') => html`<div class="item ${a.important ? 'imp' : ''}">
  <div class="ii ${a.important ? 'bg-red' : 'bg-violet'}">${icon(a.pinned ? 'tack' : 'mega')}</div>
  <div class="grow"><div class="item-t">${a.title}</div><div class="item-b pre">${a.body}</div>
    <div class="row wrap chips">${a.pinned ? html`<span class="chip blue">${icon('tack', 12)} ${t('ann.pinned')}</span>` : ''}${a.important ? html`<span class="chip red">${t('ann.important')}</span>` : ''}
      ${a.scope === 'all' ? html`<span class="chip violet">${t('common.all')}</span>` : a.scope === 'users' ? html`<span class="chip green">${t('ann.scope_personal')}</span>`
        : html`<span class="chip blue">${ref.groupCode(a.group_id)}${a.scope === 'module' ? ' · ' + ref.moduleName(a.module_id) : ''}</span>`}
      ${a.status && a.status !== 'published' ? html`<span class="chip amber">${t('ann.status_' + a.status)}${a.status === 'scheduled' ? ' · ' + fmtInstant(a.publish_at) : ''}</span>` : ''}
      <span class="xs muted">${ago(a.published_at || a.created_at)}</span></div></div>${actions}</div>`;
// Compatibilité (anciens noms)
export const announcementItem = annItem;
export const assessmentItem = (a, status = null, actions = '') => assignItem(a, { status, actions });

export const NOTIF_ICON = { timetable: ['cal', 'blue'], room: ['pin', 'amber'], cancel: ['ban', 'red'], assignment: ['book', 'amber'], exam: ['target', 'red'],
  announcement: ['mega', 'violet'], attendance: ['check', 'amber'], community: ['chat', 'green'], reminder: ['clock', 'blue'], system: ['bell', 'blue'] };
export const CHANGE_KINDS = ['timetable', 'room', 'cancel'];

export const initials = (n) => String(n || '?').trim().split(/\s+/).map((x) => x[0]).slice(0, 2).join('').toUpperCase();

// Exportation CSV (séparateur « ; » pour Excel en français, BOM UTF-8 pour l'arabe) + neutralisation des formules
export const toCSV = (rows, cols) => {
  const cell = (v) => { let s = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return '﻿' + [cols.map((c) => cell(c.label)).join(';'), ...rows.map((r) => cols.map((c) => cell(typeof c.get === 'function' ? c.get(r) : r[c.key])).join(';'))].join('\r\n');
};
export const download = (name, content, type = 'text/csv;charset=utf-8') => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
};
// Lecture CSV (« ; » ou « , » détecté), guillemets gérés
export const parseCSV = (text) => {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/)[0] || '';
  const sep = (first.match(/;/g) || []).length >= (first.match(/,/g) || []).length ? ';' : ',';
  const rows = []; let row = [], cur = '', inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else inQ = false; } else cur += c; }
    else if (c === '"') inQ = true;
    else if (c === sep) { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); rows.push(row); row = []; cur = ''; }
    else cur += c;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  const clean = rows.filter((r) => r.some((x) => x.trim() !== ''));
  if (!clean.length) return [];
  const head = clean[0].map((h) => h.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, '_'));
  return clean.slice(1).map((r, i) => Object.assign(Object.fromEntries(head.map((h, j) => [h, (r[j] ?? '').trim()])), { _line: i + 2 }));
};
export const normalize = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ًͯ-ٟ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي');
export { fmtDate };
