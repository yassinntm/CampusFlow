// Démarrage commun aux deux applications (Stagiaire et Administration) : configuration, session Supabase,
// profil, données de référence, temps réel, mode hors ligne. Chaque application fournit sa mise en page et ses vues.
import '../styles/base.css';
import '../styles/app.css';
import { html, mount } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t, setLang, getLang } from '../core/i18n.js';
import { store, pref } from '../core/store.js';
import { render, setLayout, current, go, hasRoute } from '../core/router.js';
import { sb, q, configured, secretKeyDetected } from '../services/api.js';
import { data, loadRef, refreshUnread, TABLE_KEYS } from '../services/data.js';
import { toast } from '../core/ui.js';
import { renderLogin, renderNewPassword } from './login.js';

const root = () => document.getElementById('app');
export const applyPrefs = () => {
  setLang(pref.get('lang', 'fr'));
  const th = pref.get('theme', 'light');
  document.documentElement.dataset.theme = th === 'dark' ? 'dark' : 'light';
  document.documentElement.dataset.fontsize = pref.get('fontsize', 'normal');
  document.documentElement.dataset.motion = pref.get('motion', 'full');
};

// ---------- Temps réel : invalide le cache et réaffiche (sauf pendant une saisie ou une fenêtre ouverte) ----------
let channel = null, timer = null;
const isTyping = () => ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
function startRealtime(onNotification) {
  stopRealtime();
  channel = sb.channel('cf-live-' + Math.random().toString(36).slice(2, 8));
  for (const table of Object.keys(TABLE_KEYS)) {
    channel.on('postgres_changes', { event: '*', schema: 'public', table }, (payload) => {
      data.invalidate(...TABLE_KEYS[table]);
      if (table === 'notifications') {
        data.invalidate('reads');
        refreshUnread().then(() => { if (payload?.eventType === 'INSERT' && payload.new?.title) onNotification?.(payload.new); render({ soft: true }); });
      }
      clearTimeout(timer);
      timer = setTimeout(() => { if (!document.querySelector('.overlay') && !isTyping() && !document.querySelector('.view[data-dirty]')) render({ soft: true }); }, 600);
    });
  }
  channel.subscribe();
}
// Un formulaire de la page en cours de saisie n'est jamais effacé par une mise à jour en temps réel
for (const ev of ['input', 'change']) document.addEventListener(ev, (e) => { if (e.target.closest?.('.view form')) e.target.closest('.view').dataset.dirty = '1'; }, true);
function stopRealtime() { if (channel) { sb.removeChannel(channel); channel = null; } }

// Notification du navigateur : seulement si activée ET appli ouverte (aucune infrastructure push serveur)
export function notifyLocal(n) {
  toast(n.title, n.body || '');
  if (store.get().settings.browserNotif && 'Notification' in window && Notification.permission === 'granted' && document.hidden) {
    try { new Notification(n.title, { body: n.body || '', icon: new URL('icons/icon-192.png', document.baseURI).href, tag: n.id }); } catch { /* non supporté */ }
  }
}

const configScreen = () => {
  if (secretKeyDetected) return html`<div class="login"><div class="login-card card stack"><h2>${t('config.secret_title')}</h2><p>${t('config.secret_body')}</p></div></div>`;
  return html`<div class="login"><div class="login-card card stack"><div class="brand big"><div class="logo">${icon('spark', 24)}</div>CampusFlow</div>
    <h2>${t('config.title')}</h2><p class="muted">${t('config.body')}</p><pre class="code">VITE_SUPABASE_URL=https://xxxx.supabase.co\nVITE_SUPABASE_ANON_KEY=…</pre></div></div>`;
};
export const messageScreen = (msg, actions = '') => html`<div class="login"><div class="login-card"><div class="brand big center-brand"><div class="logo">${icon('spark', 24)}</div>CampusFlow</div>
  <div class="card stack mt"><div class="warn">${icon('alert', 18)} <span>${msg}</span></div>${actions}</div></div></div>`;

/**
 * @param {object} app
 *  - kind: 'student' | 'admin'
 *  - accept(profile) → true si ce compte utilise cette application ; sinon redirect(profile) est appelé
 *  - layout(name, view) → élément conteneur de la vue
 *  - register(profile) → enregistre les vues autorisées
 *  - onReady(profile) → tâches de fond (rappels…)
 */
export async function startApp(app) {
  applyPrefs();
  const el = root();
  if (!configured || secretKeyDetected) { mount(el, configScreen()); return; }
  let booted = false;

  async function enter(session) {
    try {
      const profile = await q(sb.from('profiles').select('id,full_name,email,role,group_id,phone,status,muted_until,share_phone').eq('id', session.user.id).maybeSingle());
      if (!profile) throw new Error(t('auth.no_profile'));
      if (profile.status === 'suspended') { await sb.auth.signOut(); throw new Error(t('auth.suspended')); }
      if (!app.accept(profile)) { app.redirect(profile); return; }
      const s = await q(sb.from('user_settings').select('data').eq('user_id', session.user.id).maybeSingle());
      store.set({ session, profile, settings: s?.data || {} });
      if (s?.data?.lang && s.data.lang !== getLang()) { setLang(s.data.lang); pref.set('lang', s.data.lang); }
      await loadRef();
      await refreshUnread();
      app.register(profile);
      setLayout(app.layout);
      startRealtime(notifyLocal);
      booted = true;
      if (!hasRoute(current().name)) go('home'); else render();
      app.onReady?.(profile);
    } catch (e) {
      mount(el, messageScreen(e.message, html`<button class="btn primary block" data-logout>${t('auth.back_login')}</button>`));
    }
  }
  function leave() {
    stopRealtime(); data.clear(); booted = false;
    store.set({ session: null, profile: null, settings: {}, unread: 0, teachGroups: null });
    setLayout(null);
    renderLogin(el, null, null, app.kind);
  }
  el.addEventListener('click', async (e) => {
    if (e.target.closest('[data-logout]')) { e.preventDefault(); await sb.auth.signOut(); leave(); }
  });
  sb.auth.onAuthStateChange((event, session) => {
    if (event === 'PASSWORD_RECOVERY') { renderNewPassword(el); return; }
    if (event === 'SIGNED_OUT') { if (booted) leave(); return; }
    if (event === 'SIGNED_IN' && session && !booted) enter(session);
    if (event === 'TOKEN_REFRESHED' && session) store.set({ session });
  });
  const { data: { session } } = await sb.auth.getSession();
  if (session) enter(session); else renderLogin(el, null, null, app.kind);

  const setOnline = (v) => { store.set({ online: v }); if (booted) render(); if (v) toast(t('common.back_online')); };
  window.addEventListener('online', () => setOnline(true));
  window.addEventListener('offline', () => setOnline(false));
  if ('serviceWorker' in navigator && import.meta.env.PROD && location.protocol === 'https:') {
    navigator.serviceWorker.register(new URL('sw.js', new URL(app.kind === 'admin' ? '../' : './', document.baseURI)).href).catch(() => { /* PWA facultative */ });
  }
}
// Lien vers l'autre application (même domaine)
export const otherAppUrl = (kind) => (kind === 'admin' ? '../' : './admin/');
