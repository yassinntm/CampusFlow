// Connexion, inscription (liste pré-inscrite ou code de groupe), mot de passe oublié — via Supabase Auth
import { html, mount } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t, setLang, getLang } from '../core/i18n.js';
import { pref } from '../core/store.js';
import { sb, rpc } from '../services/api.js';
import { formData } from '../core/ui.js';

let tab = 'login';
let kind = 'student';
const otherUrl = () => (kind === 'admin' ? '../' : './admin/');
// Même écran que la démo d'origine : marque centrée, phrase d'accroche, carte avec onglets, langue et thème en bas
const card = (body) => html`<div class="login"><div class="login-card">
  <div class="brand big center-brand"><div class="logo">${icon('spark', 24)}</div>CampusFlow${kind === 'admin' ? html`<span class="chip blue">${t('admin.badge')}</span>` : ''}</div>
  <p class="muted center mb-l">${t(kind === 'admin' ? 'auth.tagline_admin' : 'auth.tagline')}</p>
  <div class="card stack login-box">${body}</div>
  <div class="between mt"><div class="row"><button class="btn sm ghost" data-lang>${icon('globe', 16)} ${getLang() === 'fr' ? 'العربية' : 'Français'}</button>
    <button class="btn sm ghost" data-theme-toggle aria-label="${t('profile.theme')}">${icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', 16)}</button></div>
    <a class="btn sm ghost" href="${otherUrl()}">${t(kind === 'admin' ? 'auth.to_student' : 'auth.to_admin')} ${icon('chev', 14, 'class="flip"')}</a></div>
  <p class="muted small center mt">${t('auth.footer')}</p></div></div>`;

// Traduit précisément les erreurs de Supabase Auth (au lieu d'un message générique)
const authError = (error) => {
  const code = error?.code || '';
  const msg = String(error?.message || '');
  const reasons = error?.reasons || error?.weak_password?.reasons || [];
  if (code === 'weak_password' || reasons.length || /password/i.test(msg)) {
    const parts = [];
    if (reasons.includes('pwned') || /pwned|leaked|known/i.test(msg)) parts.push(t('auth.pw_pwned'));
    if (reasons.includes('characters') || /character|uppercase|lowercase|symbol|digit/i.test(msg)) parts.push(t('auth.pw_characters'));
    if (reasons.includes('length') || /at least|length|short/i.test(msg)) parts.push(t('auth.pw_length'));
    return parts.length ? parts.join(' ') : t('auth.signup_failed', { msg });
  }
  if (code === 'user_already_exists' || /registered|already exists/i.test(msg)) return t('auth.exists');
  if (code === 'over_email_send_rate_limit' || /rate limit/i.test(msg)) return t('auth.rate_limited');
  if (code === 'email_address_invalid' || /email.*invalid|invalid.*email/i.test(msg)) return t('auth.email_invalid');
  if (code === 'signup_disabled' || /signups? not allowed/i.test(msg)) return t('auth.signup_disabled');
  if (/Database error/i.test(msg)) return t('auth.signup_refused');
  return t('auth.signup_failed', { msg });
};

export function renderLogin(app, msg = null, keep = null, appKind = null) {
  if (appKind) kind = appKind;
  const tabs = html`<div class="seg full" role="tablist">
    ${['login', 'signup', 'forgot'].map((k) => html`<button role="tab" class="${tab === k ? 'on' : ''}" data-tab="${k}" aria-selected="${tab === k}">${t(kind === 'admin' && k === 'signup' ? 'auth.tab_first' : 'auth.tab_' + k)}</button>`)}</div>`;
  const note = msg ? html`<div class="${msg.ok ? 'okbox' : 'warn'}" role="alert">${icon(msg.ok ? 'check' : 'alert', 18)} <span>${msg.text}</span></div>` : '';
  let form;
  if (tab === 'login') form = html`<form class="stack" data-form="login" novalidate>
      <div class="field"><label for="em">${t('auth.email')}</label><input class="input" id="em" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="pw">${t('auth.password')}</label><input class="input" id="pw" name="password" type="password" autocomplete="current-password" required></div>
      <button class="btn primary block" type="submit">${t('auth.login')}</button></form>`;
  else if (tab === 'signup') form = html`<form class="stack" data-form="signup" novalidate>
      <div class="field"><label for="fn">${t('auth.full_name')}</label><input class="input" id="fn" name="full_name" autocomplete="name" required minlength="3" maxlength="80"></div>
      <div class="field"><label for="em">${t('auth.email')}</label><input class="input" id="em" name="email" type="email" autocomplete="email" required></div>
      <div class="field"><label for="pw">${t('auth.password')}</label><input class="input" id="pw" name="password" type="password" autocomplete="new-password" required minlength="8">
        <small class="muted">${t('auth.password_rule')}</small></div>
      ${kind === 'admin' ? html`<p class="muted small">${t('auth.staff_first_help')}</p>` : html`<div class="field"><label for="jc">${t('auth.join_code')}</label><input class="input mono" id="jc" name="join_code" maxlength="12" autocapitalize="characters" placeholder="ex. 7KQ2MD">
        <small class="muted">${t('auth.join_code_help')}</small><small data-code-info></small></div>`}
      <label class="check"><input type="checkbox" name="consent" required> <span>${t('auth.consent')}</span></label>
      <button class="btn primary block" type="submit">${t('auth.signup')}</button></form>`;
  else form = html`<form class="stack" data-form="forgot" novalidate><p class="muted small">${t('auth.forgot_help')}</p>
      <div class="field"><label for="em">${t('auth.email')}</label><input class="input" id="em" name="email" type="email" autocomplete="email" required></div>
      <button class="btn primary block" type="submit">${t('auth.send_link')}</button></form>`;
  mount(app, card(html`${tabs}${note}${form}`));

  app.querySelectorAll('[data-tab]').forEach((b) => (b.onclick = () => { tab = b.dataset.tab; renderLogin(app); }));
  app.querySelector('[data-lang]').onclick = () => { const l = getLang() === 'fr' ? 'ar' : 'fr'; setLang(l); pref.set('lang', l); renderLogin(app); };
  app.querySelector('[data-theme-toggle]').onclick = () => { const th = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = th; pref.set('theme', th); renderLogin(app); };
  const f = app.querySelector('form');
  if (keep) for (const [k, v] of Object.entries(keep)) { const el = f.elements[k]; if (el && k !== 'password') { if (el.type === 'checkbox') el.checked = !!v; else if (v != null) el.value = v; } }
  const jc = f.querySelector('[name=join_code]');
  if (jc) jc.addEventListener('change', async () => {
    const info = f.querySelector('[data-code-info]');
    const code = jc.value.trim().toUpperCase();
    if (!code) { info.textContent = ''; return; }
    try {
      const r = await rpc('check_join_code', { p_code: code });
      const g = Array.isArray(r) ? r[0] : r;
      info.className = g ? 'ok small' : 'err';
      info.textContent = g ? t('auth.code_ok', { group: `${g.code} · ${g.label}` }) : t('auth.code_bad');
    } catch { info.textContent = ''; }
  });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = f.querySelector('[type=submit]');
    const v = formData(f);
    const fail = (text) => renderLogin(app, { text }, v);
    if (!f.checkValidity()) { f.reportValidity(); return; }
    btn.disabled = true;
    try {
      if (tab === 'login') {
        const { error } = await sb.auth.signInWithPassword({ email: v.email, password: v.password });
        if (error) return fail(/confirm/i.test(error.message) ? t('auth.not_confirmed') : t('auth.bad_credentials'));
      } else if (tab === 'signup') {
        if (!/[A-Za-z]/.test(v.password) || !/\d/.test(v.password)) return fail(t('auth.password_rule'));
        const code = v.join_code ? v.join_code.toUpperCase() : null;
        if (code) {
          const r = await rpc('check_join_code', { p_code: code });
          if (!(Array.isArray(r) ? r[0] : r)) return fail(t('auth.code_bad'));
        }
        const { data: d, error } = await sb.auth.signUp({ email: v.email, password: v.password,
          options: { data: { full_name: v.full_name, ...(code ? { join_code: code } : {}) }, emailRedirectTo: location.origin + location.pathname } });
        if (error) return fail(authError(error));
        if (!d.session) { tab = 'login'; return renderLogin(app, { ok: true, text: t('auth.check_email') }); }
      } else {
        const { error } = await sb.auth.resetPasswordForEmail(v.email, { redirectTo: location.origin + location.pathname });
        // Même message que l'e-mail existe ou non (ne révèle pas les comptes)
        if (error && /rate|limit/i.test(error.message)) return fail(t('auth.rate_limited'));
        tab = 'login'; return renderLogin(app, { ok: true, text: t('auth.link_sent') });
      }
    } catch (err) { fail(err.message); } finally { btn.disabled = false; }
  });
}

export function renderNewPassword(app, msg = null) {
  mount(app, card(html`<h2>${t('auth.new_password')}</h2>${msg ? html`<div class="warn">${msg}</div>` : ''}
    <form class="stack" novalidate><div class="field"><label for="np">${t('auth.password')}</label><input class="input" id="np" name="password" type="password" minlength="8" autocomplete="new-password" required>
    <small class="muted">${t('auth.password_rule')}</small></div><button class="btn primary block" type="submit">${t('common.save')}</button></form>`));
  app.querySelector('[data-lang]').onclick = () => { const l = getLang() === 'fr' ? 'ar' : 'fr'; setLang(l); pref.set('lang', l); renderNewPassword(app); };
  app.querySelector('[data-theme-toggle]').onclick = () => { const th = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = th; pref.set('theme', th); renderNewPassword(app); };
  app.querySelector('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const pw = e.target.password.value;
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return renderNewPassword(app, t('auth.password_rule'));
    const { error } = await sb.auth.updateUser({ password: pw });
    if (error) return renderNewPassword(app, error.message);
    location.hash = '#/home'; location.reload();
  });
}
