// Éléments d'interface propres à l'application d'administration (structure de la console de la démo d'origine)
import { html } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t, fmtNum } from '../core/i18n.js';
import { store, myId, role } from '../core/store.js';
import { data, loadRef } from '../services/data.js';

export const isAdmin = () => role() === 'admin';
export const isStaff = () => ['admin', 'supervisor'].includes(role());
export const isTeacher = () => role() === 'teacher';
export const stamp = () => new Date().toISOString().slice(0, 10);
export const refreshRef = async (...keys) => { data.invalidate(...keys); await loadRef(); };
export const teachers = () => store.get().ref.people.filter((p) => p.role === 'teacher');
export const studentsOf = (gid) => store.get().ref.people.filter((p) => p.role === 'student' && (!gid || p.group_id === gid));

// En-tête de page : titre, sous-titre discret, actions à droite (classe .atop de la démo)
export const atop = (title, sub = '', actions = '') => html`<div class="atop"><div><h1>${title}</h1>${sub ? html`<div class="muted small">${sub}</div>` : ''}</div>
  ${actions ? html`<div class="row wrap">${actions}</div>` : ''}</div>`;

// Onglets de groupe (« Tous les groupes » optionnel), comme groupTabs() dans la démo
export const groupTabs = (groups, cur, attr = 'data-g', withAll = false) => html`<div class="tabs">${withAll ? html`<button class="tab ${!cur ? 'on' : ''}" ${attr}="">${t('admin.all_groups')}</button>` : ''}
  ${groups.map((g) => html`<button class="tab ${cur === g.id ? 'on' : ''}" ${attr}="${g.id}">${g.code}</button>`)}</div>`;

// Groupes / couples (groupe, module) qu'un formateur enseigne ; le personnel voit tout
export async function myPairs() {
  const ta = await data.get('teaching');
  return isTeacher() ? ta.filter((x) => x.teacher_id === myId()) : null;
}
export async function myGroups() {
  const groups = store.get().ref.groups;
  if (!isTeacher()) return groups;
  const ids = new Set((await myPairs()).map((x) => x.group_id));
  return groups.filter((g) => ids.has(g.id));
}
export const rateChip = (r) => (r == null ? '—' : html`<span class="chip ${r < 80 ? 'red' : r < 90 ? 'amber' : 'green'}">${fmtNum(Number(r))} %</span>`);
export const tabsBar = (items, cur, attr = 'data-tab', prefix = '') => html`<div class="tabs mb">${items.map((k) => html`<button class="tab ${cur === k ? 'on' : ''}" ${attr}="${k}">${t(prefix + k)}</button>`)}</div>`;
export const backLink = (to) => html`<a class="link" href="#/${to}">${icon('chevl', 14, 'class="flip"')} ${t('common.back')}</a>`;
