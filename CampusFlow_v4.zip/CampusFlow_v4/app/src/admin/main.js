// CampusFlow Administration — console du personnel (administration, surveillance générale, formateurs).
// Même backend que l'application Stagiaire ; chaque droit est vérifié côté base (RLS + fonctions), le menu n'est qu'un confort.
import { html, mount } from '../core/html.js';
import { icon } from '../core/icons.js';
import { t, setLang, getLang } from '../core/i18n.js';
import { store, pref, myId } from '../core/store.js';
import { route, render } from '../core/router.js';
import { sb, q, rpc } from '../services/api.js';
import { startApp, messageScreen, otherAppUrl } from '../shared/boot.js';
import { overviewView } from './views/overview.js';
import { timetableView, historyView } from './views/timetable.js';
import { assessmentsView, calendarView, resourcesAdminView } from './views/academic.js';
import { studentsView, staffView, groupsView, catalogView } from './views/people.js';
import { announcementsAdminView, notifyView, myNotificationsView } from './views/comms.js';
import { rollView, attendanceAdminView, justificationsView } from './views/attendance.js';
import { moderationView, reportsView, auditView, exportsView } from './views/control.js';

// [route, icône, libellé, rôles autorisés]
const NAV = [
  ['overview', 'grid', 'nav.overview', ['admin', 'supervisor', 'teacher']],
  ['timetable', 'cal', 'nav.timetable', ['admin', 'supervisor', 'teacher']],
  ['history', 'hist', 'nav.history', ['admin', 'supervisor']],
  ['roll', 'check', 'nav.roll', ['admin', 'supervisor', 'teacher']],
  ['attendance', 'chart', 'nav.attendance', ['admin', 'supervisor']],
  ['justifications', 'shield', 'nav.justifications', ['admin', 'supervisor', 'teacher']],
  ['assessments', 'book', 'nav.assessments', ['admin', 'teacher']],
  ['resources', 'file', 'nav.resources', ['admin', 'teacher']],
  ['calendar', 'target', 'nav.calendar', ['admin', 'supervisor']],
  ['announcements', 'mega', 'nav.announcements', ['admin', 'supervisor', 'teacher']],
  ['notify', 'send', 'nav.notify', ['admin', 'supervisor']],
  ['students', 'users', 'nav.students', ['admin', 'supervisor']],
  ['staff', 'user', 'nav.staff', ['admin']],
  ['groups', 'layers', 'nav.groups', ['admin']],
  ['catalog', 'door2', 'nav.catalog', ['admin']],
  ['moderation', 'flag', 'nav.moderation', ['admin', 'supervisor', 'teacher']],
  ['reports', 'chart', 'nav.reports', ['admin', 'supervisor']],
  ['audit', 'key', 'nav.audit', ['admin']],
  ['exports', 'down', 'nav.exports', ['admin']],
  ['notifs', 'bell', 'nav.notifications', ['admin', 'supervisor', 'teacher']],
];
const VIEWS = { overview: overviewView, timetable: timetableView, history: historyView, roll: rollView, attendance: attendanceAdminView,
  justifications: justificationsView, assessments: assessmentsView, resources: resourcesAdminView, calendar: calendarView,
  announcements: announcementsAdminView, notify: notifyView, students: studentsView, staff: staffView, groups: groupsView,
  catalog: catalogView, moderation: moderationView, reports: reportsView, audit: auditView, exports: exportsView, notifs: myNotificationsView };
const SUB = { roll: 'roll', post: 'moderation' };
const ROLE_ICON = { admin: 'key', supervisor: 'shield', teacher: 'book' };

const saveLang = async (lang) => {
  const settings = { ...store.get().settings, lang };
  try { await q(sb.from('user_settings').upsert({ user_id: myId(), data: settings }, { onConflict: 'user_id' })); store.set({ settings }); } catch { /* préférence locale conservée */ }
};

function layout(name) {
  const { profile, unread, online } = store.get();
  const items = NAV.filter((n) => n[3].includes(profile.role));
  const active = SUB[name] || name;
  const app = document.getElementById('app');
  mount(app, html`<div class="admin">
    <aside class="side">
      <div class="between"><div class="brand"><div class="logo">${icon('spark', 20)}</div>CampusFlow</div><span class="chip blue">${t('admin.badge')}</span></div>
      <nav class="side-nav" aria-label="${t('nav.menu')}">${items.map(([to, ic, label]) => html`<a class="side-item ${active === to ? 'on' : ''}" href="#/${to}" ${active === to ? 'aria-current="page"' : ''}>
        ${icon(ic)}<span>${t(label)}</span>${to === 'notifs' && unread ? html`<span class="badge">${unread}</span>` : ''}</a>`)}</nav>
      <div class="side-foot card">
        <div class="row"><div class="ii bg-blue avatar-sm">${icon(ROLE_ICON[profile.role] || 'user', 18)}</div>
          <div class="grow min0"><div class="nf-name">${profile.full_name}</div><div class="xs muted">${t('role.' + profile.role)} · ${profile.email}</div></div></div>
        <div class="row mt-s gap-6"><button class="btn sm ghost" data-lang aria-label="${t('profile.language')}">${icon('globe', 16)}</button>
          <button class="btn sm ghost" data-theme-toggle aria-label="${t('profile.theme')}">${icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', 16)}</button>
          <button class="btn sm ghost grow" data-logout aria-label="${t('profile.logout')}">${icon('out', 16)}</button></div>
      </div>
    </aside>
    <main class="amain">${online ? '' : html`<div class="offline" role="status">${icon('wifi', 16)} ${t('common.offline')}</div>`}<div id="content"></div></main>
  </div>`);
  app.querySelector('[data-lang]').onclick = () => { const l = getLang() === 'fr' ? 'ar' : 'fr'; setLang(l); pref.set('lang', l); saveLang(l); render(); };
  app.querySelector('[data-theme-toggle]').onclick = () => { const th = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = th; pref.set('theme', th); render(); };
  return document.getElementById('content');
}

function register(profile) {
  for (const [to, , , roles] of NAV) if (roles.includes(profile.role)) route(to, VIEWS[to]);
  route('home', overviewView);
}

startApp({
  kind: 'admin',
  accept: (p) => ['admin', 'supervisor', 'teacher'].includes(p.role),
  // Les stagiaires ont leur propre application
  redirect: () => { mount(document.getElementById('app'), messageScreen(t('admin.staff_only'), html`<a class="btn primary block" href="${otherAppUrl('admin')}">${t('auth.to_student')}</a>
    <button class="btn ghost block" data-logout>${t('profile.logout')}</button>`)); },
  layout,
  register,
  // Publie les annonces programmées arrivées à échéance (le pg_cron serveur le fait aussi chaque minute quand il est disponible)
  onReady: (p) => { if (p.role !== 'teacher') rpc('publish_due_announcements').catch(() => { /* sans effet si rien à publier */ }); },
});
