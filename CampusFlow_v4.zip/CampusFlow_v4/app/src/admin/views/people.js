// Comptes : stagiaires (tableau de la démo + assiduité), personnel (formateurs, surveillance, administration),
// groupes & codes d'accès, modules / salles / affectations. Les invitations passent par la fonction serveur « admin-users ».
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, ago, fmtNum } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { openModal, closeModal, formData, busy, toast, empty, options, confirmBox, chip } from '../../core/ui.js';
import { toCSV, download, parseCSV, normalize } from '../../shared/components.js';
import { otherAppUrl } from '../../shared/boot.js';
import { atop, groupTabs, tabsBar, isAdmin, refreshRef, teachers, stamp, rateChip } from '../ui.js';
import { weekTable } from './timetable.js';
import { hm } from '../../core/dates.js';

const ROLE_CHIP = { admin: 'violet', supervisor: 'amber', teacher: 'green', student: 'blue' };
const STAFF_ROLES = ['teacher', 'supervisor', 'admin'];
const statusChip = (p) => (p.status === 'suspended' ? chip(t('users.suspended'), 'red') : p.muted_until && new Date(p.muted_until) > new Date() ? chip(t('users.muted'), 'amber') : chip(t('users.active'), 'green'));

// Invitation par e-mail (fonction serveur, clé de service jamais exposée) ; repli honnête si la fonction n'est pas déployée
async function invite(v) {
  const redirect_to = new URL(v.role === 'student' ? otherAppUrl('admin') : './', location.href).href;
  const { data: d, error } = await sb.functions.invoke('admin-users', { body: { action: 'invite', email: v.email, full_name: v.full_name, role: v.role, group_code: v.group_code || null, redirect_to } });
  if (!error) return { ok: true, d };
  let body = null; try { body = await error.context?.json?.(); } catch { /* réponse illisible */ }
  const status = error.context?.status;
  if (status === 409 || body?.error === 'exists') throw new Error(t('invite.exists'));
  if (status === 429) throw new Error(t('invite.rate'));
  if (body?.error === 'group') throw new Error(t('invite.bad_group'));
  if (status === 502 && body?.error === 'invite_failed') return { ok: false, roster: true, message: body.message };
  if (status === 404 || /Failed to send|FunctionsFetchError|FunctionsRelayError/i.test(`${error.name} ${error.message}`)) {
    // Fonction absente : on ajoute à la liste pré-inscrite, la personne crée elle-même son compte avec cette adresse
    const g = v.group_code ? store.get().ref.groups.find((x) => x.code === v.group_code) : null;
    await q(sb.from('roster').upsert({ email: v.email.toLowerCase(), full_name: v.full_name, role: v.role, group_id: v.role === 'student' ? g?.id : null }, { onConflict: 'email' }));
    return { ok: false, roster: true };
  }
  throw new Error(body?.error ? t('invite.failed', { e: body.message || body.error }) : error.message);
}
const inviteForm = (roles, groups) => html`<form class="stack" novalidate>
  <div class="field"><label>${t('auth.full_name')}</label><input class="input" name="full_name" required minlength="3" maxlength="80"></div>
  <div class="field"><label>${t('auth.email')}</label><input class="input" name="email" type="email" required maxlength="160" placeholder="prenom.nom@ofppt-edu.ma"></div>
  <div class="grid2"><div class="field"><label>${t('users.role')}</label><select class="input" name="role">${roles.map((r) => html`<option value="${r}">${t('role.' + r)}</option>`)}</select></div>
    <div class="field" data-groupfield><label>${t('common.group')}</label><select class="input" name="group_code"><option value="">—</option>${groups.map((g) => html`<option value="${g.code}">${g.code}</option>`)}</select></div></div>
  <p class="muted small">${t('invite.help')}</p><button class="btn primary block">${icon('send', 16)} ${t('invite.send')}</button></form>`;
const openInvite = (roles) => openModal(t('invite.title'), inviteForm(roles, store.get().ref.groups), {
  onMount: (sheet) => {
    const f = sheet.querySelector('form'); const gf = sheet.querySelector('[data-groupfield]');
    const sync = () => gf.classList.toggle('hidden', f.role.value !== 'student'); f.role.addEventListener('change', sync); sync();
    f.addEventListener('submit', (e) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => { const v = formData(f);
        if (v.role === 'student' && !v.group_code) throw new Error(t('roster.group_required'));
        const r = await invite({ ...v, email: v.email.toLowerCase() });
        closeModal(); render();
        if (r.ok) toast(t('invite.sent', { email: v.email }), t('invite.sent_body'), 'ok');
        else toast(t('invite.roster_only', { email: v.email }), r.message ? t('invite.failed', { e: r.message }) : t('invite.roster_body'), 'info'); }); });
  },
});

function editAccount(p, groups) {
  openModal(t('users.edit_role'), html`<form class="stack"><p><b>${p.full_name}</b> · <span class="muted">${p.email}</span></p>
    <div class="field"><label>${t('users.role')}</label><select class="input" name="role">${['student', ...STAFF_ROLES].map((r) => html`<option value="${r}" ${p.role === r ? 'selected' : ''}>${t('role.' + r)}</option>`)}</select></div>
    <div class="field"><label>${t('common.group')} (${t('role.student')})</label><select class="input" name="group"><option value="">—</option>${options(groups, p.group_id, (g) => g.code)}</select></div>
    <div class="field"><label>${t('users.mute')}</label><select class="input" name="mute"><option value="">${t('users.no_change')}</option><option value="0">${t('users.unmute')}</option>
      ${[1, 3, 7, 30].map((d) => html`<option value="${d}">${t('users.mute_days', { n: d })}</option>`)}</select></div>
    <p class="muted small">${t('users.role_note')}</p><button class="btn primary block">${t('common.save')}</button></form>`, {
    onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); busy(e.target.querySelector('button'), async () => {
      const v = formData(e.target);
      if (v.role !== p.role || (v.group || null) !== (p.group_id || null)) await rpc('admin_set_role', { p_user: p.id, p_role: v.role, p_group: v.group });
      if (v.mute != null) await rpc('mute_user', { p_user: p.id, p_days: Number(v.mute) });
      closeModal(); await refreshRef('people'); render(); toast(t('common.saved'), '', 'ok');
    }); }),
  });
}
const accountActions = (p) => (p.id === myId() ? html`<span class="muted small">${t('users.you')}</span>` : html`
  <button class="icon-btn plain" data-edit="${p.id}" aria-label="${t('common.edit')}">${icon('edit', 17)}</button>
  <button class="btn sm ghost" data-status="${p.id}" data-to="${p.status === 'active' ? 'suspended' : 'active'}">${p.status === 'active' ? t('users.suspend') : t('users.reactivate')}</button>
  <button class="icon-btn plain" data-del="${p.id}" aria-label="${t('common.delete')}">${icon('trash', 17)}</button>`);
function wireAccountActions(el, list, groups) {
  on(el, 'click', '[data-edit]', (_e, b) => editAccount(list.find((x) => x.id === b.dataset.edit), groups));
  on(el, 'click', '[data-status]', async (_e, b) => {
    if (b.dataset.to === 'suspended' && !(await confirmBox(t('users.confirm_suspend')))) return;
    busy(b, async () => { await rpc('admin_set_status', { p_user: b.dataset.status, p_status: b.dataset.to }); await refreshRef('people'); render(); });
  });
  on(el, 'click', '[data-del]', async (_e, b) => { const p = list.find((x) => x.id === b.dataset.del);
    if (await confirmBox(t('users.confirm_delete_named', { name: p.full_name }))) busy(b, async () => { await rpc('admin_delete_user', { p_user: p.id }); await refreshRef('people'); render(); toast(t('users.deleted'), '', 'ok'); }); });
}

// ========================= Stagiaires =========================
const st = { group: '', text: '', tab: 'accounts' };
export const studentsView = {
  title: 'nav.students',
  async render(el) {
    const groups = store.get().ref.groups;
    if (st.tab === 'roster' && isAdmin()) return rosterView(el, groups);
    const [list, summary] = await Promise.all([q(sb.from('profiles').select('id,full_name,email,role,group_id,status,muted_until,created_at').eq('role', 'student').order('full_name')), data.get('summary')]);
    const nt = normalize(st.text);
    const shown = list.filter((p) => (!st.group || p.group_id === st.group) && (!nt || normalize(p.full_name + ' ' + p.email).includes(nt)));
    const sm = (id) => summary.find((x) => x.student_id === id);
    mount(el, html`${atop(t('nav.students'), t('users.count_n', { n: shown.length }), html`${groupTabs(groups, st.group, 'data-g', true)}
        ${isAdmin() ? html`<button class="btn primary" data-invite>${icon('plus', 18)} ${t('invite.add')}</button>` : ''}`)}
      ${isAdmin() ? tabsBar(['accounts', 'roster'], st.tab, 'data-tab', 'users.') : ''}
      <div class="row wrap mb"><input class="input grow" type="search" data-text value="${st.text}" placeholder="${t('users.search')}" aria-label="${t('users.search')}">
        <button class="btn ghost" data-export>${icon('down', 16)} CSV</button></div>
      <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('auth.full_name')}</th><th>${t('auth.email')}</th><th>${t('common.group')}</th>
        <th>${t('att.presences')}</th><th>${t('att.absences')}</th><th>${t('att.lates')}</th><th>${t('att.rate')}</th><th>${t('users.status')}</th>${isAdmin() ? html`<th></th>` : ''}</tr></thead><tbody>
      ${shown.map((p) => { const s = sm(p.id); return html`<tr><td><b>${p.full_name}</b></td><td class="muted">${p.email}</td><td>${p.group_id ? chip(ref.groupCode(p.group_id), 'blue') : '—'}</td>
        <td>${s?.present ?? 0}</td><td class="red b6">${s?.absent ?? 0}</td><td class="amber b6">${s?.late ?? 0}</td><td>${rateChip(s?.rate ?? null)}</td><td>${statusChip(p)}</td>
        ${isAdmin() ? html`<td class="nowrap text-end">${accountActions(p)}</td>` : ''}</tr>`; })}
      </tbody></table></div>${shown.length ? '' : empty(t('users.none'), 'users')}</div>
      <p class="xs muted mt-s">${isAdmin() ? t('invite.footer') : t('users.read_only_staff')}</p>`);
    on(el, 'click', '[data-g]', (_e, b) => { st.group = b.dataset.g; render(); });
    on(el, 'click', '[data-tab]', (_e, b) => { st.tab = b.dataset.tab; render(); });
    on(el, 'change', '[data-text]', (_e, i) => { st.text = i.value; render(); });
    on(el, 'click', '[data-invite]', () => openInvite(['student']));
    on(el, 'click', '[data-export]', () => download(`stagiaires_${stamp()}.csv`, toCSV(shown, [{ key: 'full_name', label: 'nom' }, { key: 'email', label: 'email' },
      { label: 'groupe', get: (p) => ref.groupCode(p.group_id) }, { label: 'presences', get: (p) => sm(p.id)?.present ?? 0 }, { label: 'absences', get: (p) => sm(p.id)?.absent ?? 0 },
      { label: 'retards', get: (p) => sm(p.id)?.late ?? 0 }, { label: 'taux', get: (p) => sm(p.id)?.rate ?? '' }, { key: 'status', label: 'statut' }])));
    if (isAdmin()) wireAccountActions(el, list, groups);
  },
};

// Liste pré-inscrite : seules ces adresses peuvent créer un compte (inscription libre impossible)
async function rosterView(el, groups) {
  const [list, accounts] = await Promise.all([q(sb.from('roster').select('email,full_name,role,group_id,created_at').order('email')), q(sb.from('profiles').select('email'))]);
  const has = new Set(accounts.map((p) => p.email));
  const nt = normalize(st.text);
  const shown = list.filter((r) => (!st.group || r.group_id === st.group) && (!nt || normalize(r.email + ' ' + (r.full_name || '')).includes(nt)));
  mount(el, html`${atop(t('nav.students'), t('roster.what'), html`${groupTabs(groups, st.group, 'data-g', true)}<button class="btn primary" data-invite>${icon('plus', 18)} ${t('invite.add')}</button>`)}
    ${tabsBar(['accounts', 'roster'], st.tab, 'data-tab', 'users.')}
    <div class="card stack mb"><p class="muted small">${t('roster.help')}</p><div class="row wrap"><button class="btn primary" data-import>${icon('upload', 16)} ${t('roster.import')}</button>
      <button class="btn ghost" data-tpl>${icon('down', 16)} ${t('common.template')}</button><button class="btn ghost" data-export>${icon('down', 16)} CSV</button></div></div>
    <div class="row wrap mb"><input class="input grow" type="search" data-text value="${st.text}" placeholder="${t('users.search')}" aria-label="${t('users.search')}"></div>
    <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('auth.email')}</th><th>${t('auth.full_name')}</th><th>${t('users.role')}</th><th>${t('common.group')}</th><th>${t('roster.account')}</th><th></th></tr></thead>
      <tbody>${shown.map((r) => html`<tr><td class="small">${r.email}</td><td>${r.full_name || '—'}</td><td>${chip(t('role.' + r.role), ROLE_CHIP[r.role])}</td><td>${ref.groupCode(r.group_id) || '—'}</td>
        <td>${has.has(r.email) ? chip(t('roster.created'), 'green') : chip(t('roster.waiting'), 'amber')}</td>
        <td class="text-end"><button class="icon-btn plain" data-rm="${r.email}" aria-label="${t('common.delete')}">${icon('trash', 16)}</button></td></tr>`)}</tbody></table></div>
      ${shown.length ? '' : empty(t('roster.none'), 'users')}</div>`);
  on(el, 'click', '[data-g]', (_e, b) => { st.group = b.dataset.g; render(); });
  on(el, 'click', '[data-tab]', (_e, b) => { st.tab = b.dataset.tab; render(); });
  on(el, 'change', '[data-text]', (_e, i) => { st.text = i.value; render(); });
  on(el, 'click', '[data-invite]', () => openInvite(['student', ...STAFF_ROLES]));
  on(el, 'click', '[data-tpl]', () => download('modele_liste_stagiaires.csv', toCSV([{ email: 'prenom.nom@ofppt-edu.ma', full_name: 'Prénom Nom', role: 'student', group_code: groups[0]?.code || 'DD101' }],
    ['email', 'full_name', 'role', 'group_code'].map((k) => ({ key: k, label: k })))));
  on(el, 'click', '[data-export]', () => download(`liste_preinscrite_${stamp()}.csv`, toCSV(shown, [{ key: 'email', label: 'email' }, { key: 'full_name', label: 'full_name' }, { key: 'role', label: 'role' },
    { label: 'group_code', get: (r) => ref.groupCode(r.group_id) }, { label: 'compte_cree', get: (r) => (has.has(r.email) ? 'oui' : 'non') }])));
  on(el, 'click', '[data-rm]', async (_e, b) => { if (await confirmBox(t('roster.confirm_remove'))) busy(b, async () => { await q(sb.from('roster').delete().eq('email', b.dataset.rm)); render(); }); });
  on(el, 'click', '[data-import]', () => openModal(t('roster.import'), html`<p class="muted small">${t('roster.import_help')}</p><pre class="code">email;full_name;role;group_code</pre>
    <input class="input" type="file" accept=".csv,text/csv" data-file aria-label="CSV"><div data-report class="mt"></div>`, {
    wide: true,
    onMount: (sheet) => { sheet.querySelector('[data-file]').onchange = async (e) => {
      const file = e.target.files[0]; if (!file) return;
      const text = await file.text(); e.target.value = '';
      const rows = parseCSV(text).map((r) => ({ email: r.email || r.e_mail || r.mail, full_name: r.full_name || r.nom || r.nom_complet, role: r.role || 'student', group_code: r.group_code || r.groupe || r.group }));
      const rep = sheet.querySelector('[data-report]');
      await busy(null, async () => {
        const dry = await rpc('import_roster', { p_rows: rows, p_dry_run: true });
        mount(rep, html`<div class="card"><b>${t('roster.dry', { valid: dry.valid, dup: dry.duplicates, err: dry.errors.length })}</b>
          ${dry.errors.length ? html`<ul class="small mt-s err">${dry.errors.slice(0, 40).map((x) => html`<li>${t('imp.line', { n: Number(x.line) + 1 })} : ${x.error}</li>`)}</ul>` : ''}
          <button class="btn primary block mt" data-go ${dry.errors.length || !dry.valid ? 'disabled' : ''}>${t('imp.confirm', { n: dry.valid })}</button>
          ${dry.errors.length ? html`<p class="muted small mt-s">${t('imp.fix_first')}</p>` : ''}</div>`);
        rep.querySelector('[data-go]').onclick = (ev) => busy(ev.currentTarget, async () => { const r = await rpc('import_roster', { p_rows: rows, p_dry_run: false }); closeModal(); render(); toast(t('imp.done', { n: r.imported }), t('roster.import_after'), 'ok'); });
      });
    }; },
  }));
}

// ========================= Personnel =========================
const sf = { role: '' };
export const staffView = {
  title: 'nav.staff',
  async render(el) {
    data.invalidate('teaching', 'slots');
    const [list, ta, slots] = await Promise.all([q(sb.from('profiles').select('id,full_name,email,role,group_id,status,muted_until,created_at').neq('role', 'student').order('full_name')),
      data.get('teaching'), data.get('slots')]);
    const shown = list.filter((p) => !sf.role || p.role === sf.role);
    const groups = store.get().ref.groups;
    mount(el, html`${atop(t('nav.staff'), t('staff.sub', { n: list.length }), html`<button class="btn primary" data-invite>${icon('plus', 18)} ${t('invite.add_staff')}</button>`)}
      <div class="tabs mb"><button class="tab ${!sf.role ? 'on' : ''}" data-r="">${t('staff.all')}</button>${STAFF_ROLES.map((r) => html`<button class="tab ${sf.role === r ? 'on' : ''}" data-r="${r}">${t('role.' + r)}</button>`)}</div>
      <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('auth.full_name')}</th><th>${t('auth.email')}</th><th>${t('users.role')}</th><th>${t('staff.teaching')}</th><th>${t('staff.per_week')}</th><th>${t('users.status')}</th><th></th></tr></thead><tbody>
      ${shown.map((p) => { const mine = ta.filter((x) => x.teacher_id === p.id); const n = slots.filter((s) => s.teacher_id === p.id && s.status === 'active').length;
        return html`<tr><td><b>${p.full_name}</b></td><td class="muted">${p.email}</td><td>${chip(t('role.' + p.role), ROLE_CHIP[p.role])}</td>
          <td class="small">${p.role === 'teacher' ? (mine.length ? mine.map((x) => `${ref.moduleName(x.module_id)} (${ref.groupCode(x.group_id)})`).join(', ') : html`<span class="amber">${t('staff.no_teaching')}</span>`) : '—'}</td>
          <td>${p.role === 'teacher' ? html`<button class="btn sm ghost" data-sched="${p.id}" ${n ? '' : 'disabled'}>${icon('cal', 14)} ${n}</button>` : '—'}</td>
          <td>${statusChip(p)}</td><td class="nowrap text-end">${accountActions(p)}</td></tr>`; })}
      </tbody></table></div>${shown.length ? '' : empty(t('users.none'), 'users')}</div>
      <p class="xs muted mt-s">${t('staff.help')} <a class="link" href="#/catalog">${t('staff.manage_teaching')}</a></p>`);
    on(el, 'click', '[data-r]', (_e, b) => { sf.role = b.dataset.r; render(); });
    on(el, 'click', '[data-invite]', () => openInvite(STAFF_ROLES));
    on(el, 'click', '[data-sched]', (_e, b) => { const p = list.find((x) => x.id === b.dataset.sched);
      openModal(t('staff.schedule_of', { name: p.full_name }), weekTable(slots.filter((s) => s.teacher_id === p.id).map((s) => ({ weekday: s.weekday, start: hm(s.start_time), end: hm(s.end_time),
        title: ref.moduleName(s.module_id), room: ref.roomName(s.room_id), who: ref.groupCode(s.group_id), status: s.status, note: s.note }))), { wide: true }); });
    wireAccountActions(el, list, groups);
  },
};

// ========================= Groupes & codes d'accès =========================
export const groupsView = {
  title: 'nav.groups',
  async render(el) {
    const codes = await rpc('admin_group_codes');
    const groups = store.get().ref.groups;
    mount(el, html`${atop(t('nav.groups'), t('groups.help'), html`<button class="btn primary" data-new>${icon('plus', 18)} ${t('groups.new')}</button>`)}
      <div class="gcards">${codes.map((c) => { const g = groups.find((x) => x.id === c.id) || {};
        return html`<div class="card stack"><div class="between"><h2>${c.code}</h2>${chip(t('groups.students', { n: c.students }), 'blue')}</div>
          <div class="muted small">${c.label || ''}${g.filiere ? ' · ' + g.filiere : ''}${g.year ? ' · ' + t('groups.year', { n: g.year }) : ''}</div>
          <div class="codebox"><span class="mono big">${c.join_code}</span><button class="icon-btn plain" data-copy="${c.join_code}" aria-label="${t('common.copy')}">${icon('copy', 16)}</button></div>
          <div class="row wrap"><button class="btn sm ghost" data-regen="${c.id}">${icon('refresh', 14)} ${t('groups.regen')}</button><button class="btn sm ghost" data-edit="${c.id}" aria-label="${t('common.edit')}">${icon('edit', 14)}</button>
          <button class="btn sm danger" data-del="${c.id}" ${c.students ? 'disabled' : ''} aria-label="${t('common.delete')}">${icon('trash', 14)}</button></div></div>`; })}</div>
      ${codes.length ? '' : empty(t('tt.no_groups'), 'layers')}`);
    const form = (g = {}) => html`<form class="stack" novalidate><div class="field"><label>${t('groups.code')}</label><input class="input mono" name="code" required pattern="[A-Z0-9_\\-]{2,20}" value="${g.code || ''}" placeholder="DD101"></div>
      <div class="field"><label>${t('groups.label')}</label><input class="input" name="label" maxlength="80" value="${g.label || ''}"></div>
      <div class="grid2"><div class="field"><label>${t('groups.filiere')}</label><input class="input" name="filiere" maxlength="80" value="${g.filiere || ''}"></div>
      <div class="field"><label>${t('groups.year_label')}</label><input class="input" name="year" type="number" min="1" max="6" value="${g.year || ''}"></div></div><button class="btn primary block">${t('common.save')}</button></form>`;
    const save = (g) => (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; f.code.value = f.code.value.toUpperCase(); if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => { const v = formData(f); const row = { code: v.code, label: v.label, filiere: v.filiere, year: v.year ? Number(v.year) : null };
        if (g.id) await q(sb.from('groups').update(row).eq('id', g.id)); else await q(sb.from('groups').insert(row));
        closeModal(); await refreshRef('groups'); render(); toast(t('common.saved'), '', 'ok'); }); });
    on(el, 'click', '[data-new]', () => openModal(t('groups.new'), form(), { onMount: save({}) }));
    on(el, 'click', '[data-edit]', (_e, b) => { const g = groups.find((x) => x.id === b.dataset.edit); openModal(t('common.edit'), form(g), { onMount: save(g) }); });
    on(el, 'click', '[data-copy]', async (_e, b) => { try { await navigator.clipboard.writeText(b.dataset.copy); toast(t('common.copied'), b.dataset.copy, 'ok'); } catch { toast(b.dataset.copy); } });
    on(el, 'click', '[data-regen]', async (_e, b) => { if (await confirmBox(t('groups.confirm_regen'))) busy(b, async () => { const c = await rpc('regenerate_join_code', { p_group: b.dataset.regen }); toast(t('groups.new_code'), c, 'ok'); render(); }); });
    on(el, 'click', '[data-del]', async (_e, b) => { if (await confirmBox(t('groups.confirm_delete'))) busy(b, async () => { await q(sb.from('groups').delete().eq('id', b.dataset.del)); await refreshRef('groups'); render(); }); });
  },
};

// ========================= Modules, salles, affectations =========================
const ct = { tab: 'modules' };
export const catalogView = {
  title: 'nav.catalog',
  async render(el) {
    if (ct.tab === 'teaching') await refreshRef('people');
    const { modules, rooms, groups } = store.get().ref;
    let body;
    if (ct.tab === 'modules') body = html`<div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('groups.code')}</th><th>${t('cat.name')}</th><th></th></tr></thead><tbody>
      ${modules.map((m) => html`<tr><td class="mono">${m.code}</td><td>${m.name}</td><td class="nowrap text-end"><button class="icon-btn plain" data-edit-mod="${m.id}" aria-label="${t('common.edit')}">${icon('edit', 17)}</button><button class="icon-btn plain" data-del-mod="${m.id}" aria-label="${t('common.delete')}">${icon('trash', 17)}</button></td></tr>`)}</tbody></table></div>${modules.length ? '' : empty(t('cat.none'), 'book')}</div>`;
    else if (ct.tab === 'rooms') body = html`<div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('cat.name')}</th><th>${t('cat.room_kind')}</th><th>${t('cat.capacity')}</th><th></th></tr></thead><tbody>
      ${rooms.map((r) => html`<tr><td>${r.name}</td><td>${t('room.' + r.kind)}</td><td>${r.capacity ?? '—'}</td><td class="nowrap text-end"><button class="icon-btn plain" data-edit-room="${r.id}" aria-label="${t('common.edit')}">${icon('edit', 17)}</button><button class="icon-btn plain" data-del-room="${r.id}" aria-label="${t('common.delete')}">${icon('trash', 17)}</button></td></tr>`)}</tbody></table></div>${rooms.length ? '' : empty(t('cat.none'), 'door2')}</div>`;
    else {
      data.invalidate('teaching');
      const ta = await data.get('teaching');
      body = html`<p class="muted small mb">${t('cat.teaching_help')}</p><form class="card grid4 mb" data-ta>
          <select class="input" name="group_id" required aria-label="${t('common.group')}"><option value="">${t('common.group')}</option>${options(groups, null, (g) => g.code)}</select>
          <select class="input" name="module_id" required aria-label="${t('common.module')}"><option value="">${t('common.module')}</option>${options(modules, null, (m) => `${m.code} · ${m.name}`)}</select>
          <select class="input" name="teacher_id" required aria-label="${t('common.teacher')}"><option value="">${t('common.teacher')}</option>${options(teachers(), null, (p) => p.full_name)}</select>
          <button class="btn primary">${icon('plus', 16)} ${t('common.add')}</button></form>
        ${!teachers().length ? html`<div class="warn mb">${icon('alert', 16)} <span>${t('cat.no_teachers')}</span></div>` : ''}
        <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('common.group')}</th><th>${t('common.module')}</th><th>${t('common.teacher')}</th><th></th></tr></thead><tbody>
        ${ta.map((x) => html`<tr><td>${chip(ref.groupCode(x.group_id), 'blue')}</td><td>${ref.moduleName(x.module_id)}</td><td>${ref.personName(x.teacher_id)}</td>
          <td class="text-end"><button class="icon-btn plain" data-rm-ta="${x.group_id}|${x.module_id}|${x.teacher_id}" aria-label="${t('common.delete')}">${icon('trash', 16)}</button></td></tr>`)}</tbody></table></div>${ta.length ? '' : empty(t('cat.no_teaching'), 'target')}</div>`;
    }
    const add = ct.tab === 'modules' ? html`<button class="btn primary" data-new-mod>${icon('plus', 18)} ${t('cat.new_module')}</button>` : ct.tab === 'rooms' ? html`<button class="btn primary" data-new-room>${icon('plus', 18)} ${t('cat.new_room')}</button>` : '';
    mount(el, html`${atop(t('nav.catalog'), t('cat.sub'), add)}${tabsBar(['modules', 'rooms', 'teaching'], ct.tab, 'data-tab', 'cat.')}${body}`);
    const crud = (table, key, form, fields) => (item = {}) => openModal(item.id ? t('common.edit') : t('common.add'), form(item), {
      onMount: (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; if (f.code) f.code.value = f.code.value.toUpperCase(); if (!f.checkValidity()) return f.reportValidity();
        busy(f.querySelector('button'), async () => { const v = fields(formData(f));
          if (item.id) await q(sb.from(table).update(v).eq('id', item.id)); else await q(sb.from(table).insert(v));
          closeModal(); await refreshRef(key); render(); toast(t('common.saved'), '', 'ok'); }); }),
    });
    const modDialog = crud('modules', 'modules', (m) => html`<form class="stack"><div class="field"><label>${t('groups.code')}</label><input class="input mono" name="code" required pattern="[A-Z0-9_.\\-]{2,20}" value="${m.code || ''}" placeholder="M110"></div>
      <div class="field"><label>${t('cat.name')}</label><input class="input" name="name" required minlength="2" maxlength="100" value="${m.name || ''}"></div><button class="btn primary block">${t('common.save')}</button></form>`, (v) => ({ code: v.code, name: v.name }));
    const roomDialog = crud('rooms', 'rooms', (r) => html`<form class="stack"><div class="field"><label>${t('cat.name')}</label><input class="input" name="name" required maxlength="40" value="${r.name || ''}"></div>
      <div class="grid2"><div class="field"><label>${t('cat.room_kind')}</label><select class="input" name="kind">${['salle', 'labo', 'amphi', 'atelier', 'autre'].map((k) => html`<option value="${k}" ${(r.kind || 'salle') === k ? 'selected' : ''}>${t('room.' + k)}</option>`)}</select></div>
      <div class="field"><label>${t('cat.capacity')}</label><input class="input" name="capacity" type="number" min="1" max="1000" value="${r.capacity || ''}"></div></div><button class="btn primary block">${t('common.save')}</button></form>`,
    (v) => ({ name: v.name, kind: v.kind, capacity: v.capacity ? Number(v.capacity) : null }));
    const del = (table, key, id) => async (b) => { if (await confirmBox(t('cat.confirm_delete'))) busy(b, async () => { await q(sb.from(table).delete().eq('id', id)); await refreshRef(key); render(); }); };
    on(el, 'click', '[data-tab]', (_e, b) => { ct.tab = b.dataset.tab; render(); });
    on(el, 'click', '[data-new-mod]', () => modDialog());
    on(el, 'click', '[data-edit-mod]', (_e, b) => modDialog(modules.find((m) => m.id === b.dataset.editMod)));
    on(el, 'click', '[data-del-mod]', (_e, b) => del('modules', 'modules', b.dataset.delMod)(b));
    on(el, 'click', '[data-new-room]', () => roomDialog());
    on(el, 'click', '[data-edit-room]', (_e, b) => roomDialog(rooms.find((r) => r.id === b.dataset.editRoom)));
    on(el, 'click', '[data-del-room]', (_e, b) => del('rooms', 'rooms', b.dataset.delRoom)(b));
    on(el, 'submit', '[data-ta]', (e, f) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity(); busy(f.querySelector('button'), async () => { await q(sb.from('teaching_assignments').insert(formData(f))); data.invalidate('teaching'); render(); }); });
    on(el, 'click', '[data-rm-ta]', (_e, b) => busy(b, async () => { const [g, m, tch] = b.dataset.rmTa.split('|'); await q(sb.from('teaching_assignments').delete().eq('group_id', g).eq('module_id', m).eq('teacher_id', tch)); data.invalidate('teaching'); render(); }));
  },
};
void ago;
