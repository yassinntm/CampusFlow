// Emplois du temps — éditeur de la démo (brouillon par groupe, colonnes par jour, « Prévisualiser & publier »),
// branché sur le serveur : conflits formateur / salle / groupe vérifiés en base, publication versionnée et notifiée.
// En plus : séances ponctuelles (annuler / déplacer un cours à une date), lecture seule pour la surveillance et les formateurs.
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, fmtInstant, dayName, ago } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { on, go, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, isoWeekday, hm, toMin } from '../../core/dates.js';
import { openModal, closeModal, formData, busy, toast, empty, options, confirmBox, chip } from '../../core/ui.js';
import { toCSV, download, parseCSV, normalize, KIND_CLASS, effectiveSlots, slotCard } from '../../shared/components.js';
import { atop, groupTabs, isAdmin, isStaff, isTeacher, refreshRef, teachers, studentsOf } from '../ui.js';

const WD = [1, 2, 3, 4, 5, 6];
const tt = { group: null, open: new Set(), date: null, hist: '' };
const SAME = ['module_id', 'teacher_id', 'room_id', 'weekday', 'start_time', 'end_time', 'kind', 'status', 'note'];
const norm = (k, v) => (['start_time', 'end_time'].includes(k) ? hm(v) : String(v ?? ''));
const changed = (d, published) => { const s = published.find((x) => x.id === d.source_slot_id); return !s || SAME.some((k) => norm(k, s[k]) !== norm(k, d[k])); };

// Message lisible d'un changement (aperçu avant publication, mêmes formulations que la démo)
const when = (x) => `${dayName(x.weekday).toLowerCase()} ${hm(x.start_time)}`;
function changeList(drafts, published) {
  const out = [];
  for (const d of drafts) {
    const o = published.find((x) => x.id === d.source_slot_id);
    const m = ref.moduleName(d.module_id);
    if (!o) out.push({ type: 'add', text: t('chg.add', { m, when: when(d), room: ref.roomName(d.room_id) || '—' }) });
    else if (d.status === 'cancelled' && o.status !== 'cancelled') out.push({ type: 'cancel', text: t('chg.cancel', { m, when: when(d) }) });
    else if (d.status !== 'cancelled' && o.status === 'cancelled') out.push({ type: 'restore', text: t('chg.restore', { m, when: when(d) }) });
    else if (d.weekday !== o.weekday || hm(d.start_time) !== hm(o.start_time) || hm(d.end_time) !== hm(o.end_time)) out.push({ type: 'time', text: t('chg.time', { m, from: when(o), to: when(d) }) });
    else if (d.room_id !== o.room_id) out.push({ type: 'room', text: t('chg.room', { m, when: when(d), room: ref.roomName(d.room_id) || '—' }) });
    else if (changed(d, published)) out.push({ type: 'edit', text: t('chg.edit', { m, when: when(d) }) });
  }
  for (const o of published) if (!drafts.some((d) => d.source_slot_id === o.id)) out.push({ type: 'remove', text: t('chg.remove', { m: ref.moduleName(o.module_id), when: when(o) }) });
  return out;
}
const CHG_ICON = { add: ['plus', 'bg-green'], remove: ['trash', 'bg-red'], cancel: ['ban', 'bg-red'], restore: ['restore', 'bg-green'], time: ['clock', 'bg-amber'], room: ['pin', 'bg-amber'], edit: ['edit', 'bg-amber'] };

// Grille hebdomadaire en lecture seule (aperçu d'une version, emploi du temps d'un formateur)
export const weekTable = (items) => {
  const ranges = [...new Set(items.map((s) => s.start + '–' + s.end))].sort((a, b) => toMin(a.slice(0, 5)) - toMin(b.slice(0, 5)));
  if (!ranges.length) return empty(t('sched.none'), 'cal');
  return html`<div class="scroll-x card wtable-card"><table class="wtable"><thead><tr><th></th>${WD.map((d) => html`<th>${dayName(d)}</th>`)}</tr></thead><tbody>
    ${ranges.map((r) => html`<tr><th class="xs nowrap">${r}</th>${WD.map((d) => { const list = items.filter((x) => x.weekday === d && x.start + '–' + x.end === r);
      return html`<td>${list.length ? list.map((s) => html`<div class="wcell ${s.status === 'cancelled' ? 'cancelled' : s.note ? 'modified' : ''}" title="${s.note || ''}"><b>${s.title}</b>${s.room || ''}<br><span class="muted">${s.who || ''}</span></div>`) : html`<div class="wcell empty"></div>`}</td>`; })}</tr>`)}
  </tbody></table></div>`;
};
const asItems = (slots, { showGroup = false } = {}) => slots.map((s) => ({ weekday: s.weekday, start: hm(s.start_time), end: hm(s.end_time), title: ref.moduleName(s.module_id),
  room: ref.roomName(s.room_id), who: showGroup ? ref.groupCode(s.group_id) : ref.personName(s.teacher_id), status: s.status, note: s.note }));

const slotForm = (d = {}) => html`<form class="stack" novalidate>
  <div class="grid2"><div class="field"><label>${t('common.module')}</label><select class="input" name="module_id" required><option value="">—</option>${options(store.get().ref.modules, d.module_id, (m) => `${m.code} · ${m.name}`)}</select></div>
    <div class="field"><label>${t('common.teacher')}</label><select class="input" name="teacher_id"><option value="">${t('tt.no_teacher')}</option>${options(teachers(), d.teacher_id, (p) => p.full_name)}</select></div></div>
  <div class="grid3"><div class="field"><label>${t('common.day')}</label><select class="input" name="weekday" required>${WD.map((w) => html`<option value="${w}" ${Number(d.weekday) === w ? 'selected' : ''}>${dayName(w)}</option>`)}</select></div>
    <div class="field"><label>${t('common.start')}</label><input class="input" type="time" name="start_time" required min="07:00" max="22:00" value="${hm(d.start_time) || '08:30'}"></div>
    <div class="field"><label>${t('common.end')}</label><input class="input" type="time" name="end_time" required min="07:00" max="22:00" value="${hm(d.end_time) || '10:30'}"></div></div>
  <div class="grid3"><div class="field"><label>${t('common.room')}</label><select class="input" name="room_id"><option value="">—</option>${options(store.get().ref.rooms, d.room_id, (r) => r.name)}</select></div>
    <div class="field"><label>${t('tt.kind')}</label><select class="input" name="kind">${['cours', 'tp', 'td', 'exam', 'autre'].map((k) => html`<option value="${k}" ${(d.kind || 'cours') === k ? 'selected' : ''}>${t('kind.' + k)}</option>`)}</select></div>
    <div class="field"><label>${t('tt.status')}</label><select class="input" name="status">${['active', 'cancelled'].map((k) => html`<option value="${k}" ${(d.status || 'active') === k ? 'selected' : ''}>${t('tt.st_' + k)}</option>`)}</select></div></div>
  <div class="field"><label>${t('tt.note')}</label><input class="input" name="note" maxlength="200" value="${d.note || ''}" placeholder="${t('tt.note_ph')}"></div>
  <div data-local-conflict></div><button class="btn primary block">${d.id ? t('common.save') : t('common.add')}</button></form>`;

export const timetableView = {
  title: 'nav.timetable',
  async render(el, param) {
    await refreshRef('people');
    if (isTeacher()) return teacherTimetable(el);
    const groups = store.get().ref.groups;
    if (!groups.length) { mount(el, html`${atop(t('nav.timetable'))}${empty(t('tt.no_groups'), 'layers')}`); return; }
    if (param && groups.some((g) => g.id === param)) tt.group = param;
    if (!tt.group || !groups.some((g) => g.id === tt.group)) tt.group = groups[0].id;
    data.invalidate('slots', 'versions', 'exceptions');
    const [slots, versions, exceptions] = await data.all('slots', 'versions', 'exceptions');
    const published = slots.filter((s) => s.group_id === tt.group);
    const last = versions.find((v) => v.group_id === tt.group);
    const sub = last ? t('tt.published_v', { n: last.version, when: ago(last.published_at) }) : t('tt.never');
    const head = atop(isAdmin() ? t('tt.editor') : t('nav.timetable'), sub, groupTabs(groups, tt.group));

    let editor = '', drafts = [], conflicts = [], diffs = [];
    if (isAdmin()) {
      drafts = await q(sb.from('timetable_drafts').select('*').eq('group_id', tt.group).order('weekday').order('start_time'));
      const hasDraft = drafts.length > 0 || tt.open.has(tt.group);
      conflicts = hasDraft ? await rpc('check_timetable_conflicts', { p_group: tt.group }) : [];
      diffs = hasDraft ? changeList(drafts, published) : [];
      const conflictIds = new Set(conflicts.map((c) => c.draft_id));
      const rows = hasDraft ? drafts : published;
      const g = ref.groupCode(tt.group);
      const card = (s) => { const ch = hasDraft && changed(s, published);
        return html`<div class="eslot ${ch ? 'changed' : ''} ${s.status === 'cancelled' ? 'cancelled' : ''} ${conflictIds.has(s.id) ? 'conflict' : ''}">
          ${hasDraft ? html`<div class="acts"><button class="icon-btn plain sm28" data-edit="${s.id}" aria-label="${t('common.edit')}">${icon('edit', 15)}</button>
            <button class="icon-btn plain sm28" data-del="${s.id}" aria-label="${t('common.delete')}">${icon('trash', 15)}</button></div>` : ''}
          <div class="xs muted b6 pe56">${hm(s.start_time)}–${hm(s.end_time)}</div><b>${ref.moduleName(s.module_id)}</b>
          <div class="xs muted">${ref.roomName(s.room_id) || '—'} · ${ref.personName(s.teacher_id) || t('tt.no_teacher')}</div>
          ${s.kind && s.kind !== 'cours' ? html`<span class="chip ${KIND_CLASS[s.kind]} mt-6">${t('kind.' + s.kind)}</span>` : ''}
          ${s.status === 'cancelled' ? html`<span class="chip red mt-6">${t('slot.cancelled')}</span>` : ''}${ch ? html`<span class="chip amber mt-6">${t('tt.draft_chip')}</span>` : ''}
          ${conflictIds.has(s.id) ? html`<span class="chip red mt-6">${icon('alert', 12)} ${t('tt.conflict_chip')}</span>` : ''}</div>`; };
      editor = html`${hasDraft ? html`<div class="draftbar ${diffs.length || conflicts.length ? '' : 'clean'}"><span class="row">${icon(diffs.length || conflicts.length ? 'alert' : 'check', 18)}
            ${conflicts.length ? t('tt.conflicts', { n: conflicts.length }) : diffs.length ? t('tt.changes_for', { n: diffs.length, g }) : t('tt.same_as_published', { g })}</span>
          <div class="row wrap"><button class="btn sm ghost" data-import>${icon('upload', 16)} ${t('tt.import')}</button>
            <button class="btn sm ghost" data-discard>${t('tt.discard')}</button>
            <button class="btn sm primary" data-preview ${conflicts.length || !diffs.length ? 'disabled' : ''}>${icon('eye', 16)} ${t('tt.preview_publish')}</button></div></div>
          ${conflicts.length ? html`<div class="card conflicts mb"><b>${icon('alert', 16)} ${t('tt.conflicts_title')}</b><ul class="mt-s small">${conflicts.map((c) => html`<li><span class="chip red">${t('tt.c_' + c.kind)}</span> ${dayName(c.weekday)} ${hm(c.start_time)}–${hm(c.end_time)} : ${c.message}</li>`)}</ul></div>` : ''}`
        : html`<div class="draftbar clean"><span class="row">${icon('check', 18)} ${published.length ? t('tt.published_info', { n: published.length }) : t('tt.empty_info')}</span>
          <button class="btn sm primary" data-start>${icon('edit', 16)} ${t('tt.edit')}</button></div>`}
        <div class="editor">${WD.map((w) => { const list = rows.filter((s) => s.weekday === w).sort((a, b) => toMin(a.start_time) - toMin(b.start_time));
          return html`<div class="ecol"><h3>${dayName(w)}<span class="xs muted">${list.length}</span></h3>${list.map(card)}
            ${hasDraft ? html`<button class="add-slot" data-add-day="${w}">${icon('plus', 16)} ${t('common.add')}</button>` : ''}${!list.length && !hasDraft ? html`<div class="muted small center">—</div>` : ''}</div>`; })}</div>
        ${diffs.filter((d) => d.type === 'remove').length ? html`<div class="warn sec">${icon('trash', 16)} <span>${t('tt.removed_list')} ${diffs.filter((d) => d.type === 'remove').map((d) => d.text).join(' ')}</span></div>` : ''}`;
    } else {
      // Surveillance : emploi du temps publié, en lecture seule (la construction reste à l'administration)
      editor = html`<div class="draftbar clean"><span class="row">${icon('shield', 18)} ${t('tt.read_only_staff')}</span></div>${weekTable(asItems(published))}`;
    }

    // ---------- Séances ponctuelles (annuler / déplacer un cours à une date donnée) ----------
    const today = todayISO();
    if (!tt.date || tt.date < today) tt.date = isoWeekday(today) === 7 ? addDays(today, 1) : today;
    const dayList = effectiveSlots(published, exceptions, tt.date);
    const upcomingEx = exceptions.filter((e) => e.group_id === tt.group && e.session_date >= today);
    const oneOff = html`<section class="sec card"><div class="between wrap"><div><h2>${t('exc.title')}</h2><div class="muted small">${t('exc.help')}</div></div>
        <input class="input w-auto" type="date" data-date min="${today}" value="${tt.date}" aria-label="${t('common.date')}"></div>
      <div class="stack mt">${dayList.length ? dayList.map((s) => slotCard(s, { date: tt.date, actions: html`<div class="col-acts">
          ${s.exception ? html`<button class="btn sm ghost" data-restore="${s.id}">${icon('restore', 14)} ${t('exc.restore')}</button>`
          : html`<button class="btn sm ghost" data-move="${s.id}">${icon('pin', 14)} ${t('exc.move')}</button><button class="btn sm danger" data-cancel="${s.id}">${icon('ban', 14)} ${t('exc.cancel')}</button>`}</div>` }))
        : empty(isoWeekday(tt.date) === 7 ? t('exc.sunday') : t('home.no_class_today'), 'coffee')}</div>
      ${upcomingEx.length ? html`<h3 class="mt">${t('exc.upcoming')}</h3><div class="stack mt-s">${upcomingEx.map((e) => { const s = published.find((x) => x.id === e.slot_id);
        return html`<div class="audit"><span class="chip ${e.kind === 'cancelled' ? 'red' : 'amber'}">${t('exc.k_' + e.kind)}</span><span class="grow small">${fmtDate(e.session_date, { weekday: 'short', day: 'numeric', month: 'short' })} · ${s ? ref.moduleName(s.module_id) + ' ' + hm(s.start_time) : '—'}
          ${e.kind === 'moved' ? html` → ${ref.roomName(e.room_id) || ''} ${e.start_time ? hm(e.start_time) + '–' + hm(e.end_time) : ''}` : ''}${e.note ? ' · ' + e.note : ''}</span>
          <button class="btn sm ghost" data-clear="${e.slot_id}|${e.session_date}">${icon('restore', 14)} ${t('exc.restore')}</button></div>`; })}</div>` : ''}</section>`;

    mount(el, html`${head}${editor}${oneOff}`);

    // ---------- Actions ----------
    on(el, 'click', '[data-g]', (_e, b) => { tt.group = b.dataset.g; go('timetable', tt.group); });
    on(el, 'change', '[data-date]', (_e, i) => { tt.date = i.value; render(); });
    const exceptionDialog = (slotId, kind) => {
      const s = published.find((x) => x.id === slotId);
      if (kind === 'cancelled') return openModal(t('exc.cancel_title'), html`<form class="stack"><p><b>${ref.moduleName(s.module_id)}</b> · ${fmtDate(tt.date)} · ${hm(s.start_time)}–${hm(s.end_time)}</p>
        <div class="field"><label>${t('exc.reason')}</label><input class="input" name="note" maxlength="200" placeholder="${t('exc.reason_ph')}"></div>
        <p class="muted small">${t('exc.notify_note', { n: studentsOf(s.group_id).length })}</p><button class="btn danger block">${icon('ban', 16)} ${t('exc.confirm_cancel')}</button></form>`, {
        onMount: (sh) => sh.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); busy(e.target.querySelector('button'), async () => {
          await rpc('set_session_exception', { p_slot: slotId, p_date: tt.date, p_kind: 'cancelled', p_note: formData(e.target).note });
          closeModal(); data.invalidate('exceptions', 'notifications'); toast(t('exc.cancelled_ok'), '', 'ok'); render(); }); }),
      });
      return openModal(t('exc.move_title'), html`<form class="stack" novalidate><p><b>${ref.moduleName(s.module_id)}</b> · ${fmtDate(tt.date)}</p>
        <div class="field"><label>${t('common.room')}</label><select class="input" name="room">${options(store.get().ref.rooms, s.room_id, (r) => r.name)}</select></div>
        <div class="grid2"><div class="field"><label>${t('common.start')}</label><input class="input" type="time" name="start" required value="${hm(s.start_time)}"></div>
          <div class="field"><label>${t('common.end')}</label><input class="input" type="time" name="end" required value="${hm(s.end_time)}"></div></div>
        <div class="field"><label>${t('tt.note')}</label><input class="input" name="note" maxlength="200"></div>
        <p class="muted small">${t('exc.move_note')}</p><button class="btn primary block">${icon('send', 16)} ${t('exc.confirm_move')}</button></form>`, {
        onMount: (sh) => sh.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const f = e.target; if (!f.checkValidity()) return f.reportValidity();
          busy(f.querySelector('button'), async () => { const v = formData(f);
            if (toMin(v.end) <= toMin(v.start)) throw new Error(t('err.time_order'));
            const timeChanged = v.start !== hm(s.start_time) || v.end !== hm(s.end_time);
            await rpc('set_session_exception', { p_slot: slotId, p_date: tt.date, p_kind: 'moved', p_room: v.room,
              p_start: timeChanged ? v.start : null, p_end: timeChanged ? v.end : null, p_note: v.note });
            closeModal(); data.invalidate('exceptions', 'notifications'); toast(t('exc.moved_ok'), '', 'ok'); render(); }); }),
      });
    };
    on(el, 'click', '[data-cancel]', (_e, b) => exceptionDialog(b.dataset.cancel, 'cancelled'));
    on(el, 'click', '[data-move]', (_e, b) => exceptionDialog(b.dataset.move, 'moved'));
    const clearEx = (slot, date) => async (b) => { if (await confirmBox(t('exc.confirm_restore'), { danger: false })) busy(b, async () => { await rpc('clear_session_exception', { p_slot: slot, p_date: date }); data.invalidate('exceptions', 'notifications'); render(); }); };
    on(el, 'click', '[data-restore]', (_e, b) => clearEx(b.dataset.restore, tt.date)(b));
    on(el, 'click', '[data-clear]', (_e, b) => { const [s, d] = b.dataset.clear.split('|'); clearEx(s, d)(b); });
    if (!isAdmin()) return;

    const localCheck = (v, id) => {
      if (toMin(v.end_time) <= toMin(v.start_time)) return t('err.time_order');
      const s = toMin(v.start_time), e = toMin(v.end_time);
      const clash = drafts.find((d) => d.id !== id && Number(d.weekday) === Number(v.weekday) && toMin(d.start_time) < e && s < toMin(d.end_time) && d.status === 'active' && v.status === 'active');
      return clash ? t('tt.local_clash', { m: ref.moduleName(clash.module_id), a: hm(clash.start_time), b: hm(clash.end_time) }) : null;
    };
    const editDialog = (d) => openModal(d.id ? t('tt.edit_slot') : t('tt.add_slot'), slotForm(d), {
      onMount: (sheet) => {
        const f = sheet.querySelector('form'); const box = sheet.querySelector('[data-local-conflict]');
        f.addEventListener('change', () => { const msg = localCheck(formData(f), d.id); box.innerHTML = ''; if (msg) mount(box, html`<div class="warn">${icon('alert', 16)} <span>${msg}</span></div>`); });
        f.addEventListener('submit', (e) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
          busy(f.querySelector('button.primary'), async () => {
            const v = formData(f);
            if (toMin(v.end_time) <= toMin(v.start_time)) throw new Error(t('err.time_order'));
            const row = { module_id: v.module_id, teacher_id: v.teacher_id, room_id: v.room_id, weekday: Number(v.weekday), start_time: v.start_time, end_time: v.end_time, kind: v.kind, status: v.status, note: v.note };
            if (d.id) await q(sb.from('timetable_drafts').update(row).eq('id', d.id)); else await q(sb.from('timetable_drafts').insert({ ...row, group_id: tt.group }));
            closeModal(); render();
          }); });
      },
    });
    on(el, 'click', '[data-start]', (_e, b) => busy(b, async () => { await rpc('start_timetable_draft', { p_group: tt.group, p_reset: false }); tt.open.add(tt.group); render(); }));
    on(el, 'click', '[data-add-day]', (_e, b) => editDialog({ weekday: Number(b.dataset.addDay) }));
    on(el, 'click', '[data-edit]', (_e, b) => editDialog(drafts.find((d) => d.id === b.dataset.edit)));
    on(el, 'click', '[data-del]', async (_e, b) => { const s = drafts.find((d) => d.id === b.dataset.del);
      if (await confirmBox(t('tt.confirm_remove', { m: ref.moduleName(s.module_id), when: when(s) }))) busy(b, async () => { await q(sb.from('timetable_drafts').delete().eq('id', s.id)); render(); }); });
    on(el, 'click', '[data-discard]', async (_e, b) => { if (await confirmBox(t('tt.confirm_discard'))) busy(b, async () => { await q(sb.from('timetable_drafts').delete().eq('group_id', tt.group)); tt.open.delete(tt.group); render(); }); });
    on(el, 'click', '[data-preview]', () => {
      const g = ref.groupCode(tt.group); const next = (last?.version || 0) + 1;
      const teachersHit = new Set([...drafts.map((d) => d.teacher_id), ...published.map((s) => s.teacher_id)].filter(Boolean)).size;
      const sheet = openModal(t('tt.publish_title', { g }), html`<div class="small muted">${t('tt.version_arrow', { a: last?.version || 0 })} <b class="text">${next}</b> · ${t('tt.will_notify', { n: studentsOf(tt.group).length, tn: teachersHit })}</div>
        <div class="stack mt">${diffs.map((d) => { const [ic, bg] = CHG_ICON[d.type]; return html`<div class="item compact"><div class="ii ${bg} sm32">${icon(ic, 16)}</div><div class="small grow">${d.text}</div></div>`; })}</div>
        <div class="preview-phone mt"><div class="xs muted b6 mb-6">${t('tt.student_preview')}</div><div class="toast static"><div class="ti">${icon('cal', 18)}</div><div><b>${t('tt.notif_title')}</b>${t('tt.notif_body', { v: next })}</div></div></div>
        <div class="row gap mt"><button class="btn ghost block" data-close>${t('common.cancel')}</button><button class="btn primary block" data-confirm>${icon('send', 16)} ${t('tt.confirm_publish_btn')}</button></div>`, { wide: true });
      sheet.querySelector('[data-confirm]').onclick = (ev) => busy(ev.currentTarget, async () => {
        const r = await rpc('publish_timetable', { p_group: tt.group });
        tt.open.delete(tt.group); closeModal(); data.invalidate('slots', 'versions', 'notifications');
        toast(`${g} · ${t('tt.published', { v: r.version, n: r.changes?.length ?? diffs.length })}`, t('tt.published_body'), 'ok'); render();
      });
    });
    on(el, 'click', '[data-import]', () => importTimetable());
  },
};

// Formateur : son propre emploi du temps (tous groupes) + séances du jour
async function teacherTimetable(el) {
  const [slots, exceptions] = await data.all('slots', 'exceptions');
  const mine = slots.filter((s) => s.teacher_id === myId());
  const today = todayISO();
  const days = Array.from({ length: 7 }, (_, i) => addDays(today, i)).filter((d) => isoWeekday(d) !== 7);
  mount(el, html`${atop(t('tt.mine'), t('tt.mine_help'))}${weekTable(asItems(mine, { showGroup: true }))}
    <section class="sec"><h2>${t('tt.next_days')}</h2>${days.map((d) => { const list = effectiveSlots(mine, exceptions, d);
      return list.length ? html`<div class="day-h">${fmtDate(d)}</div><div class="stack">${list.map((s) => slotCard(s, { date: d, showGroup: true }))}</div>` : ''; })}</section>`);
}

// ---------- Import CSV vers le brouillon : jour;debut;fin;module;formateur;salle;type ----------
const DAYS = { lundi: 1, mardi: 2, mercredi: 3, jeudi: 4, vendredi: 5, samedi: 6, 'الاثنين': 1, 'الثلاثاء': 2, 'الأربعاء': 3, 'الخميس': 4, 'الجمعة': 5, 'السبت': 6 };
function importTimetable() {
  openModal(t('tt.import'), html`<p class="muted small">${t('tt.import_help')}</p><pre class="code">jour;debut;fin;module;formateur;salle;type\nLundi;08:30;10:30;M101;formateur@ofppt-edu.ma;Labo 1;tp</pre>
    <button class="btn sm ghost" data-tpl>${icon('down', 14)} ${t('common.template')}</button>
    <input class="input mt" type="file" accept=".csv,text/csv" data-file aria-label="CSV"><label class="check mt"><input type="checkbox" data-replace> ${t('tt.import_replace')}</label><div data-report class="mt"></div>`, {
    wide: true,
    onMount: async (sheet) => {
      const profiles = await q(sb.from('profiles').select('id,email,full_name').eq('role', 'teacher'));
      sheet.querySelector('[data-tpl]').onclick = () => download('modele_emploi_du_temps.csv', toCSV([{ jour: 'Lundi', debut: '08:30', fin: '10:30', module: 'M101', formateur: 'formateur@ofppt-edu.ma', salle: 'Labo 1', type: 'cours' }],
        ['jour', 'debut', 'fin', 'module', 'formateur', 'salle', 'type'].map((k) => ({ key: k, label: k }))));
      sheet.querySelector('[data-file]').onchange = async (e) => {
        const file = e.target.files[0]; if (!file) return;
        const text = await file.text(); e.target.value = '';
        const { modules, rooms } = store.get().ref;
        const errors = []; const ok = [];
        const tm = (x) => (/^\d{1,2}[:h]\d{2}$/.test(String(x || '').trim()) ? String(x).trim().replace('h', ':').padStart(5, '0') : null);
        for (const r of parseCSV(text)) {
          const wd = DAYS[normalize(r.jour).replace(/[^a-z؀-ۿ]/g, '')] ?? DAYS[(r.jour || '').trim()] ?? (Number(r.jour) >= 1 && Number(r.jour) <= 6 ? Number(r.jour) : null);
          const m = modules.find((x) => normalize(x.code) === normalize(r.module) || normalize(x.name) === normalize(r.module));
          const tch = r.formateur ? profiles.find((p) => normalize(p.email) === normalize(r.formateur) || normalize(p.full_name) === normalize(r.formateur)) : null;
          const room = r.salle ? rooms.find((x) => normalize(x.name) === normalize(r.salle)) : null;
          const kind = ['cours', 'tp', 'td', 'exam', 'autre'].includes(normalize(r.type)) ? normalize(r.type) : 'cours';
          const err = !wd ? t('imp.bad_day') : !tm(r.debut) || !tm(r.fin) ? t('imp.bad_time') : toMin(tm(r.fin)) <= toMin(tm(r.debut)) ? t('err.time_order')
            : !m ? t('imp.bad_module', { v: r.module }) : r.formateur && !tch ? t('imp.bad_teacher', { v: r.formateur }) : r.salle && !room ? t('imp.bad_room', { v: r.salle }) : null;
          if (err) errors.push({ line: r._line, error: err });
          else ok.push({ group_id: tt.group, module_id: m.id, teacher_id: tch?.id || null, room_id: room?.id || null, weekday: wd, start_time: tm(r.debut), end_time: tm(r.fin), kind });
        }
        const rep = sheet.querySelector('[data-report]');
        mount(rep, html`<div class="card"><b>${t('imp.summary', { ok: ok.length, err: errors.length })}</b>
          ${errors.length ? html`<ul class="small mt-s err">${errors.slice(0, 30).map((x) => html`<li>${t('imp.line', { n: x.line })} : ${x.error}</li>`)}</ul>` : ''}
          <button class="btn primary block mt" data-go ${errors.length || !ok.length ? 'disabled' : ''}>${t('imp.confirm', { n: ok.length })}</button>
          ${errors.length ? html`<p class="muted small mt-s">${t('imp.fix_first')}</p>` : ''}</div>`);
        rep.querySelector('[data-go]').onclick = (ev) => busy(ev.currentTarget, async () => {
          if (sheet.querySelector('[data-replace]').checked) await q(sb.from('timetable_drafts').delete().eq('group_id', tt.group));
          await q(sb.from('timetable_drafts').insert(ok));
          tt.open.add(tt.group); closeModal(); toast(t('imp.done', { n: ok.length }), t('tt.check_conflicts'), 'ok'); render();
        });
      };
    },
  });
}

// ========================= Historique des versions =========================
export const historyView = {
  title: 'nav.history',
  async render(el) {
    data.invalidate('versions');
    const groups = store.get().ref.groups;
    const all = await q(sb.from('timetable_versions').select('id,group_id,version,published_at,published_by,changes,snapshot').order('published_at', { ascending: false }).limit(200));
    const current = {}; for (const v of all) current[v.group_id] = Math.max(current[v.group_id] || 0, v.version);
    const list = all.filter((v) => !tt.hist || v.group_id === tt.hist);
    mount(el, html`${atop(t('nav.history'), t('hist.sub'), groupTabs(groups, tt.hist, 'data-hg', true))}
      <div class="stack">${list.length ? list.map((v) => html`<div class="card"><div class="between wrap"><div class="row wrap"><span class="chip blue">${ref.groupCode(v.group_id)}</span><b>${t('sched.version', { n: v.version })}</b>
          ${v.version === current[v.group_id] ? html`<span class="chip green">${t('hist.current')}</span>` : ''}</div>
          <span class="xs muted">${fmtInstant(v.published_at)}${v.published_by ? ' · ' + ref.personName(v.published_by) : ''}</span></div>
        <ul class="changes small">${(v.changes || []).map((c) => html`<li class="ch-${c.type}">${c.text}</li>`)}</ul>
        <div class="row mt"><button class="btn sm ghost" data-view="${v.id}">${icon('eye', 16)} ${t('hist.view')}</button>
          ${isAdmin() && v.version !== current[v.group_id] ? html`<button class="btn sm ghost" data-restore="${v.id}">${icon('restore', 16)} ${t('hist.restore')}</button>` : ''}</div></div>`)
        : empty(t('sched.no_history'), 'hist')}</div>`);
    on(el, 'click', '[data-hg]', (_e, b) => { tt.hist = b.dataset.hg; render(); });
    on(el, 'click', '[data-view]', (_e, b) => { const v = all.find((x) => x.id === b.dataset.view);
      const items = (v.snapshot || []).map((e) => ({ weekday: Number(e.weekday), start: String(e.start).slice(0, 5), end: String(e.end).slice(0, 5), title: e.module || ref.moduleName(e.module_id),
        room: e.room || ref.roomName(e.room_id), who: e.teacher || ref.personName(e.teacher_id), status: e.status, note: e.note }));
      openModal(`${ref.groupCode(v.group_id)} — ${t('sched.version', { n: v.version })}`, weekTable(items), { wide: true }); });
    on(el, 'click', '[data-restore]', async (_e, b) => { const v = all.find((x) => x.id === b.dataset.restore);
      if (!(await confirmBox(t('hist.confirm_restore', { v: v.version, g: ref.groupCode(v.group_id) }), { danger: false, ok: t('hist.restore') }))) return;
      busy(b, async () => { const n = await rpc('restore_version', { p_version: v.id }); tt.group = v.group_id; tt.open.add(v.group_id); toast(t('hist.restored', { n }), t('hist.restored_body'), 'ok'); go('timetable', v.group_id); }); });
  },
};
