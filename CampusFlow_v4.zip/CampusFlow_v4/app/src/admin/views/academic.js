// Gestion pédagogique : devoirs & examens (tableau de la démo + pièces jointes, rendus, retours), ressources des modules,
// calendrier académique (vacances, périodes d'examens, événements, échéances).
import { html, mount, safeUrl } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, fmtInstant, ago } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, isoOfInstant, timeOfInstant, instantFrom } from '../../core/dates.js';
import { openModal, closeModal, formData, busy, toast, empty, options, confirmBox, chip } from '../../core/ui.js';
import { targetChip, toCSV, download } from '../../shared/components.js';
import { atop, tabsBar, isAdmin, isTeacher, myPairs, studentsOf, stamp } from '../ui.js';

const MAX_RES = 25 * 1024 * 1024;
const safeName = (n) => n.normalize('NFD').replace(/[^\w.-]+/g, '_').slice(-80);
async function uploadResource(file, row) {
  if (file.size > MAX_RES) throw new Error(t('res.too_big'));
  const path = `${myId()}/${crypto.randomUUID()}-${safeName(file.name)}`;
  const { error } = await sb.storage.from('resources').upload(path, file, { contentType: file.type || 'application/octet-stream', upsert: false });
  if (error) throw new Error(/mime|type/i.test(error.message) ? t('res.bad_type') : error.message);
  try { await q(sb.from('resources').insert({ ...row, kind: 'file', storage_path: path, size_bytes: file.size, mime: file.type })); }
  catch (e) { await sb.storage.from('resources').remove([path]); throw e; }
}
const openSigned = async (bucket, path) => {
  const { data: d, error } = await sb.storage.from(bucket).createSignedUrl(path, 300);
  if (error) throw error;
  window.open(d.signedUrl, '_blank', 'noopener');
};

// ========================= Devoirs & examens =========================
const as = { tab: 'upcoming', group: '' };
const assessForm = (pairs, a = {}) => {
  const due = a.due_at ? { d: isoOfInstant(a.due_at), t: timeOfInstant(a.due_at) } : { d: addDays(todayISO(), 7), t: '23:59' };
  const target = a.id ? `${a.group_id || ''}|${a.module_id}` : '';
  const { modules, groups, rooms } = store.get().ref;
  return html`<form class="stack" novalidate>
    <div class="seg full">${['assignment', 'exam'].map((k) => html`<label><input type="radio" name="kind" value="${k}" ${(a.kind || 'assignment') === k ? 'checked' : ''}> ${t('assess.' + k)}</label>`)}</div>
    <div class="field"><label>${t('common.module')} / ${t('common.group')}</label><select class="input" name="target" required><option value="">—</option>
      ${isAdmin() ? modules.map((m) => html`<option value="|${m.id}" ${target === '|' + m.id ? 'selected' : ''}>${m.name} · ${t('assess.all_groups')}</option>
        ${groups.map((g) => html`<option value="${g.id}|${m.id}" ${target === g.id + '|' + m.id ? 'selected' : ''}>${m.name} · ${g.code}</option>`)}`)
      : pairs.map((p) => html`<option value="${p.group_id}|${p.module_id}" ${target === p.group_id + '|' + p.module_id ? 'selected' : ''}>${ref.moduleName(p.module_id)} · ${ref.groupCode(p.group_id)}</option>`)}</select></div>
    <div class="field"><label>${t('assess.title')}</label><input class="input" name="title" required minlength="3" maxlength="140" value="${a.title || ''}"></div>
    <div class="field"><label>${t('assess.description')}</label><textarea class="input" name="description" rows="3" maxlength="2000">${a.description || ''}</textarea></div>
    <div class="grid2"><div class="field"><label>${t('assess.due_date')}</label><input class="input" type="date" name="due_date" required value="${due.d}"></div>
      <div class="field"><label>${t('assess.due_time')}</label><input class="input" type="time" name="due_time" required value="${due.t}"></div></div>
    <div class="grid3"><div class="field"><label>${t('assess.duration_label')}</label><input class="input" type="number" name="duration_min" min="10" max="600" value="${a.duration_min || ''}"></div>
      <div class="field"><label>${t('common.room')}</label><select class="input" name="room_id"><option value="">—</option>${options(rooms, a.room_id, (r) => r.name)}</select></div>
      <div class="field"><label>${t('plan.priority')}</label><select class="input" name="priority">${['normal', 'high', 'low'].map((p) => html`<option value="${p}" ${(a.priority || 'normal') === p ? 'selected' : ''}>${t('prio.' + p)}</option>`)}</select></div></div>
    ${a.id ? '' : html`<div class="field"><label>${t('assess.attachments')}</label><input class="input" type="file" name="files" multiple accept=".pdf,.pptx,.docx,.xlsx,.zip,.png,.jpg,.jpeg,.txt"><small class="muted">${t('res.file_rules')}</small></div>`}
    <p class="muted small">${t('assess.notify_note')}</p><button class="btn primary block">${a.id ? t('common.save') : t('assess.create')}</button></form>`;
};

export const assessmentsView = {
  title: 'nav.assessments',
  async render(el) {
    data.invalidate('assessments', 'submissions', 'attachments');
    const [assessments, submissions, attachments] = await data.all('assessments', 'submissions', 'attachments');
    const pairs = await myPairs();
    const canEdit = (a) => isAdmin() || a.created_by === myId();
    const now = new Date();
    const visible = assessments.filter((a) => isAdmin() || a.created_by === myId() || pairs.some((p) => p.group_id === a.group_id && p.module_id === a.module_id));
    const list = visible.filter((a) => (as.tab === 'upcoming' ? new Date(a.due_at) > now : new Date(a.due_at) <= now)).filter((a) => !as.group || a.group_id === as.group);
    if (as.tab === 'past') list.reverse();
    const groupsUsed = store.get().ref.groups.filter((g) => visible.some((a) => a.group_id === g.id));
    const subsOf = (a) => submissions.filter((s) => s.assessment_id === a.id);
    const audience = (a) => studentsOf(a.group_id).length;
    mount(el, html`${atop(t('nav.assessments'), t('assess.count', { n: visible.length }), html`<button class="btn primary" data-new ${pairs && !pairs.length ? 'disabled' : ''}>${icon('plus', 18)} ${t('assess.new')}</button>`)}
      ${pairs && !pairs.length ? html`<div class="warn mb">${icon('alert', 16)} <span>${t('teach.no_groups')}</span></div>` : ''}
      <div class="between wrap mb"><div class="seg">${['upcoming', 'past'].map((f) => html`<button class="${as.tab === f ? 'on' : ''}" data-f="${f}">${t('assess.f_' + f)}</button>`)}</div>
        <select class="input w-auto" data-gf aria-label="${t('common.group')}"><option value="">${t('admin.all_groups')}</option>${options(groupsUsed, as.group, (g) => g.code)}</select></div>
      <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('common.date')}</th><th>${t('common.group')}</th><th>${t('common.module')}</th><th>${t('assess.title')}</th><th>${t('common.room')}</th><th>${t('sub.col')}</th><th></th></tr></thead><tbody>
      ${list.map((a) => { const s = subsOf(a); const att = attachments.filter((x) => x.assessment_id === a.id).length; const todo = s.filter((x) => !x.feedback_at).length;
        return html`<tr><td class="nowrap">${fmtInstant(a.due_at, { weekday: 'short', day: 'numeric', month: 'short' })}<div class="xs muted">${fmtInstant(a.due_at, { hour: '2-digit', minute: '2-digit' })}</div></td>
          <td>${targetChip(a.group_id)}</td><td>${ref.moduleName(a.module_id)}</td>
          <td><b>${a.title}</b> ${a.kind === 'exam' ? chip(t('assess.exam'), 'red') : ''}${att ? html` <span class="chip">${icon('file', 12)} ${att}</span>` : ''}</td><td>${ref.roomName(a.room_id) || '—'}</td>
          <td>${a.kind === 'assignment' ? html`<button class="btn sm ghost" data-subs="${a.id}">${s.length}/${audience(a)}${todo ? html` · <span class="amber">${t('sub.to_review', { n: todo })}</span>` : ''}</button>` : '—'}</td>
          <td class="nowrap text-end">${canEdit(a) ? html`<button class="icon-btn plain" data-attach="${a.id}" aria-label="${t('assess.attachments')}">${icon('upload', 17)}</button>
            <button class="icon-btn plain" data-edit="${a.id}" aria-label="${t('common.edit')}">${icon('edit', 17)}</button><button class="icon-btn plain" data-del="${a.id}" aria-label="${t('common.delete')}">${icon('trash', 17)}</button>` : ''}</td></tr>`; })}
      </tbody></table></div>${list.length ? '' : empty(t('plan.none'), 'target')}</div>`);

    const submit = (a) => (sheet) => sheet.querySelector('form').addEventListener('submit', (e) => {
      e.preventDefault(); const f = e.target; if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button.primary'), async () => {
        const v = formData(f);
        const [group_id, module_id] = v.target.split('|');
        const due_at = instantFrom(v.due_date, v.due_time);
        if (!a.id && new Date(due_at) < new Date()) throw new Error(t('assess.past_date'));
        const row = { kind: v.kind, group_id: group_id || null, module_id, title: v.title, description: v.description, due_at,
          duration_min: v.duration_min ? Number(v.duration_min) : null, room_id: v.room_id, priority: v.priority };
        let id = a.id;
        if (a.id) await q(sb.from('assessments').update(row).eq('id', a.id));
        else id = (await q(sb.from('assessments').insert(row).select('id').single())).id;
        const files = f.files?.files ? [...f.files.files] : [];
        for (const file of files) await uploadResource(file, { title: file.name.slice(0, 140), module_id, group_id: group_id || null, assessment_id: id });
        closeModal(); data.invalidate('assessments', 'notifications', 'attachments'); render(); toast(t(a.id ? 'common.saved' : 'assess.created'), files.length ? t('assess.files_added', { n: files.length }) : '', 'ok');
      });
    });
    on(el, 'click', '[data-f]', (_e, b) => { as.tab = b.dataset.f; render(); });
    on(el, 'change', '[data-gf]', (_e, s) => { as.group = s.value; render(); });
    on(el, 'click', '[data-new]', () => openModal(t('assess.new'), assessForm(pairs || []), { onMount: submit({}), wide: true }));
    on(el, 'click', '[data-edit]', (_e, b) => { const a = assessments.find((x) => x.id === b.dataset.edit); openModal(t('common.edit'), assessForm(pairs || [], a), { onMount: submit(a), wide: true }); });
    on(el, 'click', '[data-del]', async (_e, b) => { const a = assessments.find((x) => x.id === b.dataset.del);
      if (await confirmBox(t('assess.confirm_delete_named', { title: a.title }))) busy(b, async () => { await q(sb.from('assessments').delete().eq('id', a.id)); data.invalidate('assessments'); render(); }); });
    on(el, 'click', '[data-attach]', (_e, b) => attachmentsDialog(assessments.find((x) => x.id === b.dataset.attach), attachments));
    on(el, 'click', '[data-subs]', (_e, b) => submissionsDialog(assessments.find((x) => x.id === b.dataset.subs), submissions));
  },
};

function attachmentsDialog(a, all) {
  const list = all.filter((x) => x.assessment_id === a.id);
  openModal(t('assess.attachments') + ' — ' + a.title, html`<div class="stack">${list.length ? list.map((r) => html`<div class="item compact"><div class="ii bg-violet sm32">${icon('file', 16)}</div>
      <div class="grow"><div class="item-t">${r.title}</div><div class="item-b">${ago(r.created_at)}</div></div>
      <button class="btn sm ghost" data-open="${r.id}">${icon('down', 14)}</button><button class="icon-btn plain" data-rm="${r.id}" aria-label="${t('common.delete')}">${icon('trash', 16)}</button></div>`) : empty(t('assess.no_attachments'), 'file')}</div>
    <form class="stack mt"><input class="input" type="file" name="files" multiple required accept=".pdf,.pptx,.docx,.xlsx,.zip,.png,.jpg,.jpeg,.txt" aria-label="${t('assess.attachments')}">
      <button class="btn primary block">${icon('upload', 16)} ${t('res.add')}</button></form>`, {
    onMount: (sheet) => {
      sheet.querySelectorAll('[data-open]').forEach((b) => (b.onclick = () => busy(b, () => openSigned('resources', list.find((x) => x.id === b.dataset.open).storage_path))));
      sheet.querySelectorAll('[data-rm]').forEach((b) => (b.onclick = async () => { const r = list.find((x) => x.id === b.dataset.rm);
        if (!(await confirmBox(t('res.confirm_delete')))) return attachmentsDialog(a, all);
        await busy(null, async () => { await q(sb.from('resources').delete().eq('id', r.id)); if (r.storage_path) await sb.storage.from('resources').remove([r.storage_path]); data.invalidate('attachments'); render(); }); }));
      sheet.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const files = [...e.target.files.files]; if (!files.length) return;
        busy(e.target.querySelector('button'), async () => { for (const file of files) await uploadResource(file, { title: file.name.slice(0, 140), module_id: a.module_id, group_id: a.group_id, assessment_id: a.id });
          closeModal(); data.invalidate('attachments'); toast(t('assess.files_added', { n: files.length }), '', 'ok'); render(); }); });
    },
  });
}

function submissionsDialog(a, all) {
  const subs = all.filter((s) => s.assessment_id === a.id);
  const students = studentsOf(a.group_id);
  const late = (s) => new Date(s.submitted_at) > new Date(a.due_at);
  const rows = students.map((p) => ({ p, s: subs.find((x) => x.student_id === p.id) }));
  const sheet = openModal(t('sub.title', { title: a.title }), html`<div class="row wrap mb">${chip(t('sub.received', { n: subs.length, total: students.length }), 'blue')}
      ${chip(t('sub.reviewed', { n: subs.filter((s) => s.feedback_at).length }), 'green')}${chip(t('sub.late_n', { n: subs.filter(late).length }), 'amber')}
      <button class="btn sm ghost" data-csv>${icon('down', 14)} CSV</button></div>
    <div class="stack">${rows.map(({ p, s }) => html`<div class="card ${s ? '' : 'muted-card'}"><div class="between wrap"><b>${p.full_name}</b>
        ${s ? html`<span class="row wrap">${late(s) ? chip(t('sub.late'), 'amber') : chip(t('sub.on_time'), 'green')}<span class="xs muted">${fmtInstant(s.submitted_at)}</span></span>` : chip(t('sub.missing'), '')}</div>
      ${s ? html`${s.content ? html`<p class="pre small mt-s">${s.content}</p>` : ''}
        <div class="row wrap mt-s">${s.link ? html`<a class="btn sm ghost" href="${safeUrl(s.link)}" target="_blank" rel="noopener noreferrer">${icon('link', 14)} ${t('sub.link')}</a>` : ''}
          ${s.storage_path ? html`<button class="btn sm ghost" data-file="${p.id}">${icon('down', 14)} ${s.file_name || t('sub.file')}</button>` : ''}</div>
        <form class="stack mt-s" data-fb="${p.id}"><textarea class="input" name="feedback" rows="2" maxlength="3000" required placeholder="${t('sub.feedback_ph')}">${s.feedback || ''}</textarea>
          <div class="row"><input class="input w-auto" name="grade" maxlength="20" placeholder="${t('sub.grade')}" value="${s.grade || ''}" aria-label="${t('sub.grade')}">
          <button class="btn sm primary">${icon('send', 14)} ${s.feedback_at ? t('sub.update_feedback') : t('sub.send_feedback')}</button>
          ${s.feedback_at ? html`<span class="xs muted">${t('sub.sent_ago', { when: ago(s.feedback_at) })}</span>` : ''}</div></form>` : ''}</div>`)}
      ${rows.length ? '' : empty(t('att.no_students'), 'users')}</div>`, { wide: true });
  sheet.querySelectorAll('[data-file]').forEach((b) => (b.onclick = () => busy(b, () => openSigned('submissions', subs.find((x) => x.student_id === b.dataset.file).storage_path))));
  sheet.querySelectorAll('[data-fb]').forEach((f) => f.addEventListener('submit', (e) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
    busy(f.querySelector('button'), async () => { const v = formData(f);
      await rpc('give_feedback', { p_assessment: a.id, p_student: f.dataset.fb, p_feedback: v.feedback, p_grade: v.grade });
      data.invalidate('submissions'); toast(t('sub.feedback_sent'), '', 'ok');
      const fresh = await data.get('submissions'); submissionsDialog(a, fresh); }); }));
  sheet.querySelector('[data-csv]').onclick = () => download(`rendus_${stamp()}.csv`, toCSV(rows, [{ label: 'stagiaire', get: (r) => r.p.full_name },
    { label: 'rendu', get: (r) => (r.s ? 'oui' : 'non') }, { label: 'date', get: (r) => r.s?.submitted_at || '' }, { label: 'retard', get: (r) => (r.s && late(r.s) ? 'oui' : '') },
    { label: 'note', get: (r) => r.s?.grade || '' }, { label: 'retour', get: (r) => r.s?.feedback || '' }]));
}

// ========================= Ressources des modules =========================
const rs = { module: '' };
export const resourcesAdminView = {
  title: 'nav.resources',
  async render(el) {
    data.invalidate('resources');
    const list = await data.get('resources');
    const pairs = await myPairs();
    const { modules, groups } = store.get().ref;
    const shown = list.filter((r) => !rs.module || r.module_id === rs.module);
    mount(el, html`${atop(t('nav.resources'), t('res.admin_sub', { n: list.length }), html`<select class="input w-auto" data-filter aria-label="${t('common.module')}"><option value="">${t('res.all_modules')}</option>${options(modules.filter((m) => list.some((r) => r.module_id === m.id)), rs.module, (m) => m.name)}</select>
        <button class="btn primary" data-new ${pairs && !pairs.length ? 'disabled' : ''}>${icon('plus', 18)} ${t('res.add')}</button>`)}
      <div class="stack">${shown.length ? shown.map((r) => html`<div class="item"><div class="ii bg-violet">${icon(r.kind === 'file' ? 'file' : 'link', 18)}</div>
        <div class="grow"><div class="item-t">${r.title}</div><div class="item-b">${ref.moduleName(r.module_id)} · ${r.group_id ? ref.groupCode(r.group_id) : t('res.all_groups')} · ${ref.personName(r.created_by)} · ${ago(r.created_at)}</div>
        ${r.description ? html`<div class="item-b pre">${r.description}</div>` : ''}</div>
        <div class="col-acts">${r.kind === 'file' ? html`<button class="btn sm" data-open="${r.id}">${icon('down', 16)} ${t('res.open')}</button>` : html`<a class="btn sm" href="${safeUrl(r.url)}" target="_blank" rel="noopener noreferrer">${icon('link', 16)} ${t('res.open')}</a>`}
          ${isAdmin() || r.created_by === myId() ? html`<button class="icon-btn plain" data-del="${r.id}" aria-label="${t('common.delete')}">${icon('trash', 16)}</button>` : ''}</div></div>`)
        : empty(t('res.none'), 'file')}</div>`);
    on(el, 'change', '[data-filter]', (_e, s) => { rs.module = s.value; render(); });
    on(el, 'click', '[data-open]', (_e, b) => busy(b, () => openSigned('resources', list.find((x) => x.id === b.dataset.open).storage_path)));
    on(el, 'click', '[data-del]', async (_e, b) => { if (!(await confirmBox(t('res.confirm_delete')))) return;
      busy(b, async () => { const r = list.find((x) => x.id === b.dataset.del); await q(sb.from('resources').delete().eq('id', r.id)); if (r.storage_path) await sb.storage.from('resources').remove([r.storage_path]); data.invalidate('resources'); render(); }); });
    on(el, 'click', '[data-new]', () => {
      const targets = isAdmin() ? modules.flatMap((m) => [{ v: `${m.id}|`, l: `${m.name} · ${t('res.all_groups')}` }, ...groups.map((g) => ({ v: `${m.id}|${g.id}`, l: `${m.name} · ${g.code}` }))])
        : pairs.map((p) => ({ v: `${p.module_id}|${p.group_id}`, l: `${ref.moduleName(p.module_id)} · ${ref.groupCode(p.group_id)}` }));
      openModal(t('res.add'), html`<form class="stack" novalidate>
        <div class="field"><label>${t('res.title')}</label><input class="input" name="title" required maxlength="140"></div>
        <div class="field"><label>${t('common.module')} / ${t('common.group')}</label><select class="input" name="target" required>${targets.map((x) => html`<option value="${x.v}">${x.l}</option>`)}</select></div>
        <div class="seg full"><button type="button" class="on" data-kind="link">${t('res.link')}</button><button type="button" data-kind="file">${t('res.file')}</button></div>
        <input type="hidden" name="kind" value="link">
        <div class="field" data-k="link"><label>${t('res.url')}</label><input class="input" name="url" type="url" placeholder="https://…"></div>
        <div class="field hidden" data-k="file"><label>${t('res.file_label')}</label><input class="input" name="file" type="file" accept=".pdf,.pptx,.docx,.xlsx,.zip,.png,.jpg,.jpeg,.txt"><small class="muted">${t('res.file_rules')}</small></div>
        <div class="field"><label>${t('res.description')}</label><textarea class="input" name="description" rows="3" maxlength="1000"></textarea></div>
        <button class="btn primary block">${t('common.add')}</button></form>`, {
        onMount: (sheet) => {
          const f = sheet.querySelector('form');
          sheet.querySelectorAll('[data-kind]').forEach((b) => (b.onclick = () => { sheet.querySelectorAll('[data-kind]').forEach((x) => x.classList.toggle('on', x === b));
            f.kind.value = b.dataset.kind; sheet.querySelectorAll('[data-k]').forEach((x) => x.classList.toggle('hidden', x.dataset.k !== b.dataset.kind)); }));
          f.addEventListener('submit', (e) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
            busy(f.querySelector('button.primary'), async () => {
              const v = formData(f); const [module_id, group_id] = v.target.split('|');
              const row = { title: v.title, description: v.description, module_id, group_id: group_id || null };
              if (v.kind === 'link') { if (!v.url || safeUrl(v.url) === '#') throw new Error(t('res.https_only')); await q(sb.from('resources').insert({ ...row, kind: 'link', url: v.url }));
              } else { const file = f.file.files[0]; if (!file) throw new Error(t('res.choose_file')); await uploadResource(file, row); }
              closeModal(); data.invalidate('resources'); render(); toast(t('res.added'), '', 'ok');
            }); });
        },
      });
    });
  },
};

// ========================= Calendrier académique =========================
const KINDS = ['holiday', 'exam_period', 'event', 'deadline'];
const KCHIP = { holiday: 'green', exam_period: 'red', event: 'blue', deadline: 'amber' };
const cs = { show: 'upcoming' };
export const calendarView = {
  title: 'nav.calendar',
  async render(el) {
    data.invalidate('calendar');
    const events = await data.get('calendar');
    const today = todayISO();
    const list = events.filter((e) => (cs.show === 'upcoming' ? e.end_date >= today : e.end_date < today));
    if (cs.show === 'past') list.reverse();
    mount(el, html`${atop(t('nav.calendar'), t('cal.admin_sub'), html`<button class="btn primary" data-new>${icon('plus', 18)} ${t('cal.new')}</button>`)}
      <div class="seg mb">${['upcoming', 'past'].map((f) => html`<button class="${cs.show === f ? 'on' : ''}" data-f="${f}">${t('assess.f_' + f)}</button>`)}</div>
      <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('cal.dates')}</th><th>${t('cal.kind')}</th><th>${t('ann.title')}</th><th>${t('common.group')}</th><th></th></tr></thead><tbody>
        ${list.map((e) => html`<tr><td class="nowrap">${fmtDate(e.start_date, { day: 'numeric', month: 'short', year: 'numeric' })}${e.end_date !== e.start_date ? html` → ${fmtDate(e.end_date, { day: 'numeric', month: 'short', year: 'numeric' })}` : ''}</td>
          <td>${chip(t('cal.kind_' + e.kind), KCHIP[e.kind])}</td><td><b>${e.title}</b>${e.description ? html`<div class="xs muted">${e.description}</div>` : ''}</td><td>${targetChip(e.group_id)}</td>
          <td class="nowrap text-end"><button class="icon-btn plain" data-edit="${e.id}" aria-label="${t('common.edit')}">${icon('edit', 17)}</button><button class="icon-btn plain" data-del="${e.id}" aria-label="${t('common.delete')}">${icon('trash', 17)}</button></td></tr>`)}
      </tbody></table></div>${list.length ? '' : empty(t('cal.none'), 'cal')}</div>`);
    const form = (e = {}) => html`<form class="stack" novalidate>
      <div class="field"><label>${t('ann.title')}</label><input class="input" name="title" required minlength="2" maxlength="140" value="${e.title || ''}"></div>
      <div class="grid2"><div class="field"><label>${t('cal.kind')}</label><select class="input" name="kind">${KINDS.map((k) => html`<option value="${k}" ${(e.kind || 'event') === k ? 'selected' : ''}>${t('cal.kind_' + k)}</option>`)}</select></div>
        <div class="field"><label>${t('common.group')}</label><select class="input" name="group_id"><option value="">${t('cal.everyone')}</option>${options(store.get().ref.groups, e.group_id, (g) => g.code)}</select></div></div>
      <div class="grid2"><div class="field"><label>${t('cal.start')}</label><input class="input" type="date" name="start_date" required value="${e.start_date || today}"></div>
        <div class="field"><label>${t('cal.end')}</label><input class="input" type="date" name="end_date" required value="${e.end_date || today}"></div></div>
      <div class="field"><label>${t('assess.description')}</label><textarea class="input" name="description" rows="3" maxlength="1000">${e.description || ''}</textarea></div>
      <button class="btn primary block">${t('common.save')}</button></form>`;
    const save = (e) => (sheet) => sheet.querySelector('form').addEventListener('submit', (ev) => { ev.preventDefault(); const f = ev.target; if (!f.checkValidity()) return f.reportValidity();
      busy(f.querySelector('button'), async () => { const v = formData(f);
        if (v.end_date < v.start_date) throw new Error(t('cal.order'));
        const row = { title: v.title, kind: v.kind, group_id: v.group_id, start_date: v.start_date, end_date: v.end_date, description: v.description };
        if (e.id) await q(sb.from('calendar_events').update(row).eq('id', e.id)); else await q(sb.from('calendar_events').insert(row));
        closeModal(); data.invalidate('calendar'); render(); toast(t('common.saved'), '', 'ok'); }); });
    on(el, 'click', '[data-f]', (_e, b) => { cs.show = b.dataset.f; render(); });
    on(el, 'click', '[data-new]', () => openModal(t('cal.new'), form(), { onMount: save({}) }));
    on(el, 'click', '[data-edit]', (_e, b) => { const e = events.find((x) => x.id === b.dataset.edit); openModal(t('common.edit'), form(e), { onMount: save(e) }); });
    on(el, 'click', '[data-del]', async (_e, b) => { if (await confirmBox(t('cal.confirm_delete'))) busy(b, async () => { await q(sb.from('calendar_events').delete().eq('id', b.dataset.del)); data.invalidate('calendar'); render(); }); });
  },
};
void tabsBar; void isTeacher;
