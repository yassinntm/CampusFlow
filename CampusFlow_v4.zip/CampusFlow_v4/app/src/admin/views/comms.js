// Communication : annonces (brouillons, programmation, ciblage), notifications (composition → aperçu → envoi, taux de lecture),
// et boîte de réception du personnel.
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, ago, fmtInstant } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { isoOfInstant, timeOfInstant, instantFrom, todayISO, addDays } from '../../core/dates.js';
import { openModal, closeModal, formData, busy, toast, empty, confirmBox, chip } from '../../core/ui.js';
import { normalize } from '../../shared/components.js';
import { FILTERS, filterNotifs, notifItem, markRead, openLink } from '../../student/views/inbox.js';
import { atop, isStaff, isTeacher, myPairs, studentsOf } from '../ui.js';

// Cible lisible d'une annonce
const audienceChip = (a) => a.scope === 'all' ? chip(t('common.all'), 'violet') : a.scope === 'users' ? chip(t('ann.scope_users', { n: a.target_users?.length || 0 }), 'green')
  : a.scope === 'module' ? chip(`${ref.groupCode(a.group_id)} · ${ref.moduleName(a.module_id)}`, 'blue') : chip(ref.groupCode(a.group_id), 'blue');
const STATUS_CHIP = { published: 'green', scheduled: 'amber', draft: '' };

// Sélecteur de stagiaires (recherche + cases à cocher), réservé au personnel
const pickStudents = (selected = []) => { const sel = new Set(selected);
  return html`<div class="picker" data-picker><input class="input" type="search" data-pq placeholder="${t('users.search')}" aria-label="${t('users.search')}">
    <div class="picker-list">${studentsOf(null).map((p) => html`<label class="check" data-name="${normalize(p.full_name + ' ' + ref.groupCode(p.group_id))}"><input type="checkbox" name="u" value="${p.id}" ${sel.has(p.id) ? 'checked' : ''}> ${p.full_name} <span class="xs muted">${ref.groupCode(p.group_id)}</span></label>`)}</div>
    <div class="xs muted" data-pcount></div></div>`; };
const wirePicker = (sheet) => { const box = sheet.querySelector('[data-picker]'); if (!box) return;
  const count = () => { box.querySelector('[data-pcount]').textContent = t('ann.selected', { n: box.querySelectorAll('input[name=u]:checked').length }); };
  box.querySelector('[data-pq]').addEventListener('input', (e) => { const n = normalize(e.target.value); box.querySelectorAll('[data-name]').forEach((l) => l.classList.toggle('hidden', n && !l.dataset.name.includes(n))); });
  box.addEventListener('change', count); count(); };

// ========================= Annonces =========================
const an = { tab: 'published' };
async function audiences() {
  if (isTeacher()) return (await myPairs()).flatMap((p) => [{ v: `g:${p.group_id}`, l: t('ann.scope_group', { g: ref.groupCode(p.group_id) }) },
    { v: `m:${p.group_id}:${p.module_id}`, l: `${ref.groupCode(p.group_id)} · ${ref.moduleName(p.module_id)}` }]).filter((x, i, a) => a.findIndex((y) => y.v === x.v) === i);
  return [{ v: 'all', l: t('ann.scope_all') }, ...store.get().ref.groups.map((g) => ({ v: `g:${g.id}`, l: t('ann.scope_group', { g: g.code }) })), { v: 'users', l: t('ann.scope_pick') }];
}
const annForm = (targets, a = {}) => {
  const cur = !a.id ? '' : a.scope === 'all' ? 'all' : a.scope === 'users' ? 'users' : a.scope === 'module' ? `m:${a.group_id}:${a.module_id}` : `g:${a.group_id}`;
  const when = a.publish_at ? { d: isoOfInstant(a.publish_at), t: timeOfInstant(a.publish_at) } : { d: addDays(todayISO(), 1), t: '08:00' };
  const mode = a.status || 'published';
  return html`<form class="stack" novalidate>
    <div class="field"><label>${t('ann.title')}</label><input class="input" name="title" required minlength="3" maxlength="140" value="${a.title || ''}"></div>
    <div class="field"><label>${t('ann.body')}</label><textarea class="input" name="body" rows="5" required minlength="3" maxlength="3000">${a.body || ''}</textarea></div>
    <div class="field"><label>${t('ann.audience')}</label><select class="input" name="target" required>${targets.map((x) => html`<option value="${x.v}" ${cur === x.v ? 'selected' : ''}>${x.l}</option>`)}</select></div>
    ${isStaff() ? html`<div class="${cur === 'users' ? '' : 'hidden'}" data-users>${pickStudents(a.target_users || [])}</div>` : ''}
    <div class="field"><label>${t('ann.when')}</label><div class="seg full">${['published', 'scheduled', 'draft'].map((k) => html`<label><input type="radio" name="status" value="${k}" ${mode === k ? 'checked' : ''}> ${t('ann.mode_' + k)}</label>`)}</div></div>
    <div class="grid2 ${mode === 'scheduled' ? '' : 'hidden'}" data-sched><div class="field"><label>${t('common.date')}</label><input class="input" type="date" name="pdate" min="${todayISO()}" value="${when.d}"></div>
      <div class="field"><label>${t('assess.due_time')}</label><input class="input" type="time" name="ptime" value="${when.t}"></div></div>
    <label class="check"><input type="checkbox" name="important" ${a.important ? 'checked' : ''}> ${t('ann.important_help')}</label>
    ${isStaff() ? html`<label class="check"><input type="checkbox" name="pinned" ${a.pinned ? 'checked' : ''}> ${t('ann.pin')}</label>` : ''}
    <p class="muted small">${t('ann.notify_note')}</p><button class="btn primary block">${a.id ? t('common.save') : t('ann.save_btn')}</button></form>`;
};
export const announcementsAdminView = {
  title: 'nav.announcements',
  async render(el) {
    if (isStaff()) await rpc('publish_due_announcements').catch(() => 0);
    data.invalidate('announcements');
    const all = await data.get('announcements');
    const mine = (a) => isStaff() || a.author_id === myId();
    const visible = isTeacher() ? all.filter((a) => a.author_id === myId() || a.status === 'published') : all;
    const list = visible.filter((a) => a.status === an.tab).sort((a, b) => (b.pinned - a.pinned) || String(b.published_at || b.publish_at || b.created_at).localeCompare(String(a.published_at || a.publish_at || a.created_at)));
    const count = (s) => visible.filter((a) => a.status === s).length;
    const targets = await audiences();
    mount(el, html`${atop(t('nav.announcements'), t('ann.admin_sub'), html`<button class="btn primary" data-new ${targets.length ? '' : 'disabled'}>${icon('plus', 18)} ${t('ann.new')}</button>`)}
      ${!targets.length ? html`<div class="warn mb">${icon('alert', 16)} <span>${t('teach.no_groups')}</span></div>` : ''}
      <div class="tabs mb">${['published', 'scheduled', 'draft'].map((k) => html`<button class="tab ${an.tab === k ? 'on' : ''}" data-tab="${k}">${t('ann.status_' + k)} · ${count(k)}</button>`)}</div>
      <div class="stack">${list.length ? list.map((a) => html`<div class="item ${a.important ? 'imp' : ''}"><div class="ii ${a.important ? 'bg-red' : 'bg-violet'}">${icon(a.pinned ? 'tack' : 'mega')}</div>
        <div class="grow min0"><div class="item-t">${a.title}</div><div class="item-b pre">${a.body}</div>
          <div class="row wrap chips">${audienceChip(a)}${a.important ? chip(t('ann.important'), 'red') : ''}${chip(t('ann.status_' + a.status), STATUS_CHIP[a.status])}
            <span class="xs muted">${a.status === 'scheduled' ? t('ann.on', { when: fmtInstant(a.publish_at) }) : a.status === 'published' ? ago(a.published_at || a.created_at) : t('ann.edited', { when: ago(a.updated_at) })}
            · ${ref.personName(a.author_id) || '—'}</span></div></div>
        ${mine(a) ? html`<div class="row nogap">${isStaff() ? html`<button class="icon-btn plain ${a.pinned ? 'pinned' : ''}" data-pin="${a.id}" title="${t('ann.pin')}" aria-label="${t('ann.pin')}" aria-pressed="${a.pinned}">${icon('tack', 17)}</button>` : ''}
          <button class="icon-btn plain" data-edit="${a.id}" aria-label="${t('common.edit')}">${icon('edit', 17)}</button><button class="icon-btn plain" data-del="${a.id}" aria-label="${t('common.delete')}">${icon('trash', 17)}</button></div>` : ''}</div>`)
        : empty(t('ann.none_' + an.tab), 'mega')}</div>`);
    const save = (a) => (sheet) => {
      const f = sheet.querySelector('form');
      const sync = () => { sheet.querySelector('[data-users]')?.classList.toggle('hidden', f.target.value !== 'users'); sheet.querySelector('[data-sched]').classList.toggle('hidden', formData(f).status !== 'scheduled'); };
      f.addEventListener('change', sync); wirePicker(sheet); sync();
      f.addEventListener('submit', (e) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
        busy(f.querySelector('button.primary'), async () => {
          const v = formData(f);
          const [kind, g, m] = v.target.split(':');
          const users = [...f.querySelectorAll('input[name=u]:checked')].map((x) => x.value);
          if (kind === 'users' && !users.length) throw new Error(t('ann.pick_one'));
          const publish_at = v.status === 'scheduled' ? instantFrom(v.pdate, v.ptime) : null;
          if (v.status === 'scheduled' && new Date(publish_at) <= new Date()) throw new Error(t('ann.future'));
          const row = { title: v.title, body: v.body, important: v.important, status: v.status, publish_at,
            scope: kind === 'all' ? 'all' : kind === 'users' ? 'users' : kind === 'm' ? 'module' : 'group',
            group_id: kind === 'g' || kind === 'm' ? g : null, module_id: kind === 'm' ? m : null, target_users: kind === 'users' ? users : null, ...(isStaff() ? { pinned: v.pinned } : {}) };
          if (a.id) await q(sb.from('announcements').update(row).eq('id', a.id)); else await q(sb.from('announcements').insert(row));
          closeModal(); an.tab = v.status; data.invalidate('announcements', 'notifications', 'sent'); render();
          toast(t('ann.saved_' + v.status), v.status === 'published' ? t('ann.sent_body') : '', 'ok');
        }); });
    };
    on(el, 'click', '[data-tab]', (_e, b) => { an.tab = b.dataset.tab; render(); });
    on(el, 'click', '[data-new]', () => openModal(t('ann.new'), annForm(targets), { onMount: save({}), wide: true }));
    on(el, 'click', '[data-edit]', (_e, b) => { const a = all.find((x) => x.id === b.dataset.edit); openModal(t('common.edit'), annForm(targets, a), { onMount: save(a), wide: true }); });
    on(el, 'click', '[data-pin]', (_e, b) => busy(b, async () => { const a = all.find((x) => x.id === b.dataset.pin); await q(sb.from('announcements').update({ pinned: !a.pinned }).eq('id', a.id)); data.invalidate('announcements'); render(); }));
    on(el, 'click', '[data-del]', async (_e, b) => { const a = all.find((x) => x.id === b.dataset.del);
      if (await confirmBox(t('ann.confirm_delete_named', { title: a.title }))) busy(b, async () => { await q(sb.from('announcements').delete().eq('id', a.id)); data.invalidate('announcements'); render(); }); });
  },
};

// ========================= Envoyer une notification =========================
export const notifyView = {
  title: 'nav.notify',
  async render(el) {
    data.invalidate('sent');
    const [sent, personal] = await Promise.all([data.get('sent'), q(sb.from('notifications').select('*').eq('target_kind', 'user').eq('created_by', myId()).eq('kind', 'system').order('created_at', { ascending: false }).limit(20))]);
    const recent = [...sent.filter((n) => n.kind === 'system' || n.kind === 'announcement'), ...personal].sort((a, b) => String(b.created_at).localeCompare(String(a.created_at))).slice(0, 25);
    const stats = recent.length ? await rpc('notification_stats', { p_ids: recent.map((n) => n.id) }) : [];
    const st = Object.fromEntries(stats.map((s) => [s.id, s]));
    const groups = store.get().ref.groups;
    const tchip = (n) => n.target_kind === 'all' ? chip(t('common.all'), 'violet') : n.target_kind === 'user' ? chip(ref.personName(n.user_id) || t('notif.personal'), 'green') : chip(ref.groupCode(n.group_id), 'blue');
    mount(el, html`${atop(t('nav.notify'), t('notify.sub'))}
      <div class="grid2 auto300 top-start">
        <form class="card stack" data-compose novalidate>
          <div class="field"><label>${t('notify.to')}</label><select class="input" name="target"><option value="all">${t('notify.all_students')}</option>
            ${groups.map((g) => html`<option value="g:${g.id}">${g.code}${g.label ? ' · ' + g.label : ''}</option>`)}<option value="u">${t('notify.one_student')}</option></select></div>
          <div class="field hidden" data-one><label>${t('role.student')}</label><select class="input" name="user"><option value="">—</option>${studentsOf(null).map((p) => html`<option value="${p.id}">${p.full_name} · ${ref.groupCode(p.group_id)}</option>`)}</select></div>
          <div class="field"><label>${t('ann.title')}</label><input class="input" name="title" required maxlength="70" placeholder="${t('notify.title_ph')}"></div>
          <div class="field"><label>${t('notify.message')}</label><textarea class="input" name="body" maxlength="280" placeholder="${t('notify.body_ph')}"></textarea></div>
          <label class="check"><input type="checkbox" name="important"> ${t('notify.important')}</label>
          <button class="btn primary">${icon('eye', 18)} ${t('notify.preview')}</button>
          <p class="xs muted">${t('notify.honest')}</p>
        </form>
        <div class="card"><h2 class="mb-6">${t('notify.recent')}</h2>${recent.length ? recent.map((n) => { const s = st[n.id];
          return html`<div class="audit"><div class="grow min0"><b>${n.title}</b><div class="xs muted">${n.body}</div></div><div class="text-end">${tchip(n)}
            <div class="xs muted mt-4">${s ? t('notify.reads', { r: s.reads, n: s.audience }) : ''} · ${ago(n.created_at)}</div></div></div>`; }) : empty(t('notif.none'), 'bell')}</div>
      </div>`);
    const f = el.querySelector('[data-compose]');
    f.target.addEventListener('change', () => el.querySelector('[data-one]').classList.toggle('hidden', f.target.value !== 'u'));
    f.addEventListener('submit', (e) => { e.preventDefault(); if (!f.checkValidity()) return f.reportValidity();
      const v = formData(f);
      if (v.target === 'u' && !v.user) return toast(t('notify.pick_student'), '', 'error');
      const row = v.target === 'all' ? { target_kind: 'all' } : v.target === 'u' ? { target_kind: 'user', user_id: v.user } : { target_kind: 'group', group_id: v.target.slice(2) };
      const n = v.target === 'all' ? studentsOf(null).length : v.target === 'u' ? 1 : studentsOf(row.group_id).length;
      const sheet = openModal(t('notify.confirm_title'), html`<p class="small muted">${t('notify.confirm_body', { n })}</p>
        <div class="preview-phone mt"><div class="xs muted b6 mb-6">${t('tt.student_preview')}</div><div class="toast static"><div class="ti">${icon('bell', 18)}</div><div><b>${v.title}</b>${v.body || ''}</div></div></div>
        <div class="row gap mt"><button class="btn ghost block" data-close>${t('common.cancel')}</button><button class="btn primary block" data-send>${icon('send', 16)} ${t('notify.send')}</button></div>`);
      sheet.querySelector('[data-send]').onclick = (ev) => busy(ev.currentTarget, async () => {
        await q(sb.from('notifications').insert({ ...row, kind: 'system', title: v.title, body: v.body || '', important: v.important, link: null }));
        closeModal(); data.invalidate('sent', 'notifications'); toast(t('notify.sent', { n }), '', 'ok'); render();
      });
    });
  },
};

// ========================= Mes notifications (personnel) =========================
const nf = { f: 'all' };
const ADMIN_LINKS = { schedule: 'timetable', assignments: 'assessments', exams: 'assessments', attendance: 'justifications', post: 'moderation', community: 'moderation', notifs: 'notifs' };
export const myNotificationsView = {
  title: 'nav.notifications',
  async render(el) {
    data.invalidate('notifications', 'reads');
    const [list, reads] = await data.all('notifications', 'reads');
    const read = new Set(reads.map((r) => r.notification_id));
    const shown = filterNotifs(list, read, nf.f);
    const unread = list.filter((n) => !read.has(n.id));
    mount(el, html`${atop(t('nav.notifications'), t('notif.unread_n', { n: unread.length }), unread.length ? html`<button class="btn ghost" data-all>${icon('check', 16)} ${t('notif.mark_all')}</button>` : '')}
      <div class="tabs mb">${FILTERS.map(([k, l]) => html`<button class="tab ${nf.f === k ? 'on' : ''}" data-f="${k}">${t(l)}</button>`)}</div>
      <div class="stack">${shown.length ? shown.map((n) => notifItem(n, read)) : empty(t('notif.none'), 'bell')}</div>`);
    on(el, 'click', '[data-f]', (_e, b) => { nf.f = b.dataset.f; render(); });
    on(el, 'click', '[data-all]', (_e, b) => busy(b, async () => { await markRead(unread.map((n) => n.id)); render(); }));
    on(el, 'click', '[data-n]', (_e, b) => busy(b, async () => { const n = list.find((x) => x.id === b.dataset.n);
      if (!read.has(n.id)) await markRead([n.id]);
      if (!openLink(n.link, ADMIN_LINKS)) render(); }));
  },
};
