// Contrôle : modération (signalements, contenus masqués, sanctions), rapports chiffrés (données réelles, CSV),
// journal d'audit protégé (lecture réservée à l'administration, aucune écriture possible depuis l'application), exports.
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtInstant, ago, dayName, fmtNum } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { hm, todayISO, addDays } from '../../core/dates.js';
import { openModal, closeModal, busy, toast, empty, confirmBox, chip } from '../../core/ui.js';
import { toCSV, download, normalize } from '../../shared/components.js';
import { atop, tabsBar, isAdmin, isTeacher, myGroups, stamp, rateChip } from '../ui.js';
import { actLabel } from './overview.js';

// ========================= Modération =========================
const modButtons = (kind, id, status) => html`<span class="row wrap">${status === 'visible'
  ? html`<button class="btn sm ghost" data-mod="hide" data-k="${kind}" data-id="${id}">${icon('eye', 14)} ${t('mod.hide')}</button>`
  : html`<button class="btn sm ghost" data-mod="restore" data-k="${kind}" data-id="${id}">${icon('restore', 14)} ${t('mod.restore')}</button>`}
  <button class="btn sm danger" data-mod="remove" data-k="${kind}" data-id="${id}">${icon('ban', 14)} ${t('mod.remove')}</button></span>`;
async function moderateAction(b) {
  const { mod, k, id } = b.dataset;
  if (mod === 'remove' && !(await confirmBox(t('mod.confirm_remove')))) return;
  let reason = null;
  if (mod === 'hide' || mod === 'remove') {
    reason = await new Promise((resolve) => { const sh = openModal(t('mod.reason_title'), html`<form class="stack"><textarea class="input" name="r" rows="2" maxlength="300" placeholder="${t('mod.reason_ph')}"></textarea>
      <button class="btn primary block">${t('common.confirm')}</button></form>`);
      sh.querySelector('form').addEventListener('submit', (e) => { e.preventDefault(); const v = e.target.r.value.trim() || null; closeModal(); resolve(v); }); });
  }
  await busy(b, async () => { await rpc('moderate', { p_kind: k, p_id: id, p_action: mod, p_reason: reason }); data.invalidate('posts', 'rides', 'studyGroups'); toast(t('mod.done_' + mod), '', 'ok'); render(); });
}
const md = { tab: 'reports' };
export const moderationView = {
  title: 'nav.moderation',
  async render(el) {
    data.invalidate('posts');
    const posts = await data.get('posts');
    if (isTeacher()) {
      // Formateur : contenus de ses groupes (masqués compris) ; le traitement des signalements reste au personnel
      const gs = new Set((await myGroups()).map((g) => g.id));
      const mine = posts.filter((p) => gs.has(p.group_id));
      const hidden = mine.filter((p) => p.status !== 'visible');
      mount(el, html`${atop(t('nav.moderation'), t('mod.teacher_help'))}<h2>${t('mod.hidden', { n: hidden.length })}</h2>
        <div class="stack mt-s">${hidden.length ? hidden.map(modCard) : empty(t('mod.nothing'), 'shield')}</div>
        <h2 class="mt">${t('mod.recent')}</h2><div class="stack mt-s">${mine.filter((p) => p.status === 'visible').slice(0, 20).map(modCard)}</div>`);
      on(el, 'click', '[data-mod]', (_e, b) => moderateAction(b));
      on(el, 'click', '[data-open]', (_e, b) => openPost(b.dataset.open, posts));
      return;
    }
    const [reports, history] = await Promise.all([q(sb.from('reports').select('*').eq('status', 'open').order('created_at', { ascending: false })),
      md.tab === 'history' ? q(sb.from('reports').select('*').neq('status', 'open').order('created_at', { ascending: false }).limit(200)) : []]);
    const groupsBy = {};
    for (const r of reports) (groupsBy[r.target_kind + ':' + r.target_id] ||= []).push(r);
    const replyIds = reports.filter((r) => r.target_kind === 'reply').map((r) => r.target_id);
    const replies = replyIds.length ? await q(sb.from('replies').select('id,post_id,author_id,body,status').in('id', replyIds)) : [];
    const [rides, sgs] = await data.all('rides', 'studyGroups');
    const target = (kind, id) => {
      if (kind === 'post') { const p = posts.find((x) => x.id === id); return p && { title: p.title, body: p.body, author: p.author_id, status: p.status, post: p.id }; }
      if (kind === 'reply') { const r = replies.find((x) => x.id === id); return r && { title: t('mod.reply'), body: r.body, author: r.author_id, status: r.status, post: r.post_id }; }
      if (kind === 'ride') { const r = rides.find((x) => x.id === id); return r && { title: t('nav.rides'), body: `${r.from_place} · ${fmtInstant(r.depart_at)} · ${r.note || ''}`, author: r.author_id, status: r.status }; }
      const g = sgs.find((x) => x.id === id); return g && { title: t('nav.studygroups'), body: `${g.subject} · ${g.place}`, author: g.created_by, status: g.status };
    };
    const entries = Object.entries(groupsBy);
    const hidden = posts.filter((p) => p.status !== 'visible');
    let body;
    if (md.tab === 'reports') body = html`<div class="stack">${entries.length ? entries.map(([key, rs]) => { const [kind, id] = key.split(':'); const tg = target(kind, id);
      return html`<div class="card"><div class="between wrap"><div class="row wrap">${chip(t('mod.k_' + kind), 'blue')}${chip(t('mod.reports', { n: rs.length }), rs.length >= 3 ? 'red' : 'amber')}
        ${tg && tg.status !== 'visible' ? chip(t('mod.status_' + tg.status), 'red') : ''}</div><span class="muted small">${ago(rs[0].created_at)}</span></div>
        ${tg ? html`<b class="block mt-s">${tg.title}</b><p class="pre small mt-s clamp4">${tg.body}</p><div class="muted small">${t('mod.author')} : ${ref.personName(tg.author) || '—'}${tg.post ? html` · <button class="link" data-open="${tg.post}">${t('mod.open')}</button>` : ''}</div>`
          : html`<p class="muted small mt-s">${t('mod.deleted')}</p>`}
        <ul class="small mt-s">${rs.map((r) => html`<li><b>${t('report.' + r.reason)}</b>${r.details ? ' — ' + r.details : ''} <span class="muted">(${ref.personName(r.reporter_id) || '—'})</span></li>`)}</ul>
        <div class="row wrap mt">${['post', 'reply'].includes(kind) && tg ? modButtons(kind, id, tg.status) : ''}
          ${!['post', 'reply'].includes(kind) && tg ? html`<button class="btn sm danger" data-mod="remove" data-k="${kind}" data-id="${id}">${icon('ban', 14)} ${t('mod.remove')}</button>` : ''}
          <button class="btn sm ghost" data-mod="dismiss" data-k="${kind}" data-id="${id}">${t('mod.dismiss')}</button>
          ${tg?.author && tg.author !== myId() ? html`<button class="btn sm ghost" data-mute="${tg.author}">${icon('ban', 14)} ${t('mod.mute3')}</button>` : ''}</div></div>`; })
      : empty(t('mod.no_reports'), 'shield')}</div>`;
    else if (md.tab === 'hidden') body = html`<div class="stack">${hidden.length ? hidden.map(modCard) : empty(t('mod.nothing'), 'shield')}</div>`;
    else body = html`<div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('audit.when')}</th><th>${t('mod.kind')}</th><th>${t('mod.reason')}</th><th>${t('mod.reporter')}</th><th>${t('mod.outcome')}</th></tr></thead>
      <tbody>${history.map((r) => html`<tr><td class="nowrap small">${fmtInstant(r.created_at)}</td><td>${t('mod.k_' + r.target_kind)}</td><td>${t('report.' + r.reason)}${r.details ? html`<div class="xs muted">${r.details}</div>` : ''}</td>
        <td>${ref.personName(r.reporter_id) || '—'}</td><td>${chip(t('mod.r_' + r.status), r.status === 'actioned' ? 'red' : '')}</td></tr>`)}</tbody></table></div>${history.length ? '' : empty(t('mod.no_history'), 'hist')}</div>`;
    mount(el, html`${atop(t('nav.moderation'), t('mod.admin_help'))}
      <div class="tabs mb">${[['reports', entries.length], ['hidden', hidden.length], ['history', null]].map(([k, n]) => html`<button class="tab ${md.tab === k ? 'on' : ''}" data-tab="${k}">${t('mod.tab_' + k)}${n != null ? ' · ' + n : ''}</button>`)}</div>${body}`);
    on(el, 'click', '[data-tab]', (_e, b) => { md.tab = b.dataset.tab; render(); });
    on(el, 'click', '[data-mod]', (_e, b) => moderateAction(b));
    on(el, 'click', '[data-open]', (_e, b) => openPost(b.dataset.open, posts));
    on(el, 'click', '[data-mute]', async (_e, b) => { if (await confirmBox(t('mod.confirm_mute'))) busy(b, async () => { await rpc('mute_user', { p_user: b.dataset.mute, p_days: 3 }); toast(t('mod.muted'), '', 'ok'); }); });
  },
};
const modCard = (p) => html`<div class="card"><div class="row wrap">${chip(ref.groupCode(p.group_id), 'blue')}${chip(t('comm.' + p.kind))}${p.status !== 'visible' ? chip(t('mod.status_' + p.status), 'red') : ''}
  <span class="xs muted">${ref.personName(p.author_id) || t('comm.anonymous')} · ${ago(p.created_at)}</span></div>
  <b class="block mt-s">${p.title}</b><p class="pre small clamp4">${p.body}</p><div class="between wrap mt-s"><button class="link" data-open="${p.id}">${t('mod.open')}</button>${modButtons('post', p.id, p.status)}</div></div>`;
// Discussion complète (réponses comprises, masquées incluses pour le personnel)
async function openPost(id, posts) {
  const p = posts.find((x) => x.id === id) || (await q(sb.from('posts_feed').select('*').eq('id', id)))[0];
  if (!p) return toast(t('mod.deleted'));
  const replies = await q(sb.from('replies').select('id,author_id,body,status,created_at').eq('post_id', id).order('created_at'));
  const sheet = openModal(p.title, html`<div class="row wrap">${chip(ref.groupCode(p.group_id), 'blue')}${p.status !== 'visible' ? chip(t('mod.status_' + p.status), 'red') : ''}<span class="xs muted">${ref.personName(p.author_id) || t('comm.anonymous')} · ${ago(p.created_at)}</span></div>
    <p class="pre mt-s">${p.body}</p><h3 class="mt">${t('comm.replies', { n: replies.length })}</h3>
    <div class="stack mt-s">${replies.map((r) => html`<div class="card"><div class="between wrap"><span class="xs muted">${ref.personName(r.author_id) || '—'} · ${ago(r.created_at)}</span>${r.status !== 'visible' ? chip(t('mod.status_' + r.status), 'red') : ''}</div>
      <p class="pre small mt-s">${r.body}</p><div class="mt-s">${modButtons('reply', r.id, r.status)}</div></div>`)}</div>`, { wide: true });
  sheet.addEventListener('click', (e) => { const b = e.target.closest('[data-mod]'); if (b) moderateAction(b); });
}

// ========================= Rapports =========================
export const reportsView = {
  title: 'nav.reports',
  async render(el) {
    const r = await rpc('admin_reports');
    const rate = (ok, tot) => (tot ? Math.round((1000 * ok) / tot) / 10 : null);
    const kpi = (l, v) => html`<div class="stat"><span>${l}</span><b>${v}</b></div>`;
    const gcols = [{ key: 'code', label: 'groupe' }, { key: 'students', label: 'stagiaires' }, { key: 'slots', label: 'cours_semaine' }, { label: 'version', get: (g) => g.version ?? '' },
      { key: 'sessions', label: 'seances_tenues' }, { label: 'taux_presence', get: (g) => rate(g.present, g.records) ?? '' }, { key: 'absent', label: 'absences' }, { key: 'late', label: 'retards' },
      { key: 'assignments', label: 'devoirs' }, { key: 'exams', label: 'examens' }, { key: 'posts', label: 'publications' }];
    const mcols = [{ key: 'name', label: 'module' }, { key: 'sessions', label: 'seances' }, { key: 'records', label: 'pointages' }, { key: 'absent', label: 'absences' }, { label: 'taux_absence', get: (m) => rate(m.absent, m.records) ?? '' }];
    const people = r.people || {};
    mount(el, html`${atop(t('nav.reports'), t('rep.sub', { when: fmtInstant(new Date().toISOString()) }), html`<button class="btn ghost" data-csv="groups">${icon('down', 16)} ${t('rep.csv_groups')}</button><button class="btn ghost" data-csv="modules">${icon('down', 16)} ${t('rep.csv_modules')}</button>`)}
      <div class="kpis">${kpi(t('role.student'), people.student || 0)}${kpi(t('role.teacher'), people.teacher || 0)}${kpi(t('role.supervisor'), people.supervisor || 0)}${kpi(t('users.suspended'), r.suspended)}</div>
      <div class="kpis mt-s">${kpi(t('rep.upcoming_assign'), r.assessments.upcoming_assignments)}${kpi(t('rep.upcoming_exams'), r.assessments.upcoming_exams)}${kpi(t('rep.submissions'), r.assessments.submissions)}${kpi(t('rep.feedback_pending'), r.assessments.feedback_pending)}</div>
      <section class="sec"><h2>${t('rep.by_group')}</h2><div class="card tcard mt-s"><div class="scroll-x"><table class="table"><thead><tr><th>${t('common.group')}</th><th>${t('admin.k_students')}</th><th>${t('admin.per_week')}</th><th>${t('admin.version')}</th><th>${t('rep.sessions')}</th><th>${t('att.rate')}</th><th>${t('att.absences')}</th><th>${t('att.lates')}</th><th>${t('nav.assignments')}</th><th>${t('nav.exams')}</th></tr></thead>
        <tbody>${r.groups.map((g) => html`<tr><td><b>${g.code}</b> <span class="xs muted">${g.label || ''}</span></td><td>${g.students}</td><td>${g.slots}</td><td>${g.version ? 'v' + g.version : '—'}</td><td>${g.sessions}</td>
          <td>${rateChip(rate(g.present, g.records))}</td><td class="red b6">${g.absent}</td><td class="amber b6">${g.late}</td><td>${g.assignments}</td><td>${g.exams}</td></tr>`)}</tbody></table></div></div></section>
      <section class="sec"><h2>${t('rep.by_module')}</h2><div class="card tcard mt-s"><div class="scroll-x"><table class="table"><thead><tr><th>${t('common.module')}</th><th>${t('rep.sessions')}</th><th>${t('rep.records')}</th><th>${t('att.absences')}</th><th>${t('rep.absence_rate')}</th></tr></thead>
        <tbody>${r.modules.filter((m) => m.records || m.sessions).map((m) => html`<tr><td>${m.name}</td><td>${m.sessions}</td><td>${m.records}</td><td>${m.absent}</td><td>${rate(m.absent, m.records) == null ? '—' : fmtNum(rate(m.absent, m.records)) + ' %'}</td></tr>`)}</tbody></table></div>
        ${r.modules.some((m) => m.records || m.sessions) ? '' : empty(t('rep.no_attendance'), 'chart')}</div></section>
      <div class="grid2 auto300 sec top-start">
        <div class="card"><h2>${t('nav.moderation')}</h2>${[['open', r.moderation.open], ['actioned', r.moderation.actioned], ['dismissed', r.moderation.dismissed], ['hidden_posts', r.moderation.hidden_posts], ['removed_posts', r.moderation.removed_posts], ['muted_users', r.moderation.muted_users]]
          .map(([k, v]) => html`<div class="audit"><span class="grow">${t('rep.mod_' + k)}</span><b>${v}</b></div>`)}</div>
        <div class="card"><h2>${t('rep.comms')}</h2>${[['justif_pending', r.justifications.pending], ['justif_accepted', r.justifications.accepted], ['justif_rejected', r.justifications.rejected],
          ['ann_published', r.announcements.published], ['ann_scheduled', r.announcements.scheduled], ['ann_drafts', r.announcements.drafts], ['notifs_30d', r.notifications_30d]]
          .map(([k, v]) => html`<div class="audit"><span class="grow">${t('rep.' + k)}</span><b>${v}</b></div>`)}</div></div>`);
    on(el, 'click', '[data-csv]', (_e, b) => download(`rapport_${b.dataset.csv}_${stamp()}.csv`, b.dataset.csv === 'groups' ? toCSV(r.groups, gcols) : toCSV(r.modules, mcols)));
  },
};

// ========================= Journal d'audit =========================
const au = { action: '', entity: '', text: '', from: '' };
export const auditView = {
  title: 'nav.audit',
  async render(el) {
    if (!au.from) au.from = addDays(todayISO(), -30);
    const rows = await q(sb.from('audit_log').select('*').gte('at', au.from + 'T00:00:00Z').order('at', { ascending: false }).limit(2000));
    const actions = [...new Set(rows.map((r) => r.action))].sort(); const entities = [...new Set(rows.map((r) => r.entity))].sort();
    const nt = normalize(au.text);
    const shown = rows.filter((r) => (!au.action || r.action === au.action) && (!au.entity || r.entity === au.entity) && (!nt || normalize(JSON.stringify(r.details) + ' ' + ref.personName(r.actor_id) + ' ' + (r.entity_id || '')).includes(nt)));
    mount(el, html`${atop(t('nav.audit'), t('audit.protected'), html`<button class="btn ghost" data-export>${icon('down', 16)} CSV</button>`)}
      <div class="row wrap mb"><input class="input w-auto" type="date" data-from value="${au.from}" max="${todayISO()}" aria-label="${t('audit.from')}">
        <select class="input w-auto" data-a aria-label="${t('audit.action')}"><option value="">${t('audit.all_actions')}</option>${actions.map((a) => html`<option ${au.action === a ? 'selected' : ''} value="${a}">${actLabel(a)}</option>`)}</select>
        <select class="input w-auto" data-en aria-label="${t('audit.entity')}"><option value="">${t('audit.all_entities')}</option>${entities.map((a) => html`<option ${au.entity === a ? 'selected' : ''} value="${a}">${a}</option>`)}</select>
        <input class="input grow" type="search" data-text value="${au.text}" placeholder="${t('audit.search')}" aria-label="${t('audit.search')}"></div>
      <p class="muted small mb">${t('audit.help', { n: shown.length })}</p>
      <div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('audit.when')}</th><th>${t('audit.who')}</th><th>${t('audit.action')}</th><th>${t('audit.entity')}</th><th>${t('audit.details')}</th></tr></thead>
      <tbody>${shown.slice(0, 300).map((r) => html`<tr><td class="nowrap small">${fmtInstant(r.at)}</td><td>${ref.personName(r.actor_id) || t('admin.system')}</td><td>${chip(actLabel(r.action))}</td><td class="small">${r.entity}</td>
        <td><code class="small clamp2">${JSON.stringify(r.details || {})}</code></td></tr>`)}</tbody></table></div>${shown.length ? '' : empty(t('audit.none'), 'hist')}</div>`);
    on(el, 'change', '[data-from]', (_e, i) => { au.from = i.value || addDays(todayISO(), -30); render(); });
    on(el, 'change', '[data-a]', (_e, s) => { au.action = s.value; render(); });
    on(el, 'change', '[data-en]', (_e, s) => { au.entity = s.value; render(); });
    on(el, 'change', '[data-text]', (_e, i) => { au.text = i.value; render(); });
    on(el, 'click', '[data-export]', () => download(`journal_audit_${stamp()}.csv`, toCSV(shown, [{ key: 'at', label: 'date' }, { label: 'auteur', get: (r) => ref.personName(r.actor_id) }, { key: 'action', label: 'action' },
      { key: 'entity', label: 'objet' }, { key: 'entity_id', label: 'id' }, { label: 'details', get: (r) => JSON.stringify(r.details || {}) }])));
  },
};

// ========================= Exports =========================
export const exportsView = {
  title: 'nav.exports',
  async render(el) {
    const items = [
      ['timetable', 'cal', async () => { data.invalidate('slots'); const s = await data.get('slots');
        return toCSV(s, [{ label: 'groupe', get: (x) => ref.groupCode(x.group_id) }, { label: 'jour', get: (x) => dayName(x.weekday) }, { label: 'debut', get: (x) => hm(x.start_time) }, { label: 'fin', get: (x) => hm(x.end_time) },
          { label: 'module', get: (x) => ref.moduleName(x.module_id) }, { label: 'formateur', get: (x) => ref.personName(x.teacher_id) }, { label: 'salle', get: (x) => ref.roomName(x.room_id) }, { key: 'kind', label: 'type' }, { key: 'status', label: 'statut' }, { key: 'note', label: 'note' }]); }],
      ['assessments', 'target', async () => { data.invalidate('assessments'); const a = await data.get('assessments');
        return toCSV(a, [{ key: 'kind', label: 'type' }, { label: 'groupe', get: (x) => ref.groupCode(x.group_id) || 'tous' }, { label: 'module', get: (x) => ref.moduleName(x.module_id) }, { key: 'title', label: 'titre' }, { key: 'due_at', label: 'echeance' }, { key: 'priority', label: 'priorite' }]); }],
      ['attendance', 'check', async () => { const [recs, sess] = await Promise.all([q(sb.from('attendance_records').select('*')), data.get('sessions')]); const by = Object.fromEntries(sess.map((s) => [s.id, s]));
        return toCSV(recs.filter((r) => by[r.session_id]), [{ label: 'date', get: (r) => by[r.session_id].session_date }, { label: 'groupe', get: (r) => ref.groupCode(by[r.session_id].group_id) }, { label: 'module', get: (r) => ref.moduleName(by[r.session_id].module_id) },
          { label: 'stagiaire', get: (r) => ref.personName(r.student_id) }, { key: 'status', label: 'statut' }, { key: 'minutes_late', label: 'retard_min' }]); }],
      ['announcements', 'mega', async () => { data.invalidate('announcements'); return toCSV(await data.get('announcements'), [{ key: 'created_at', label: 'date' }, { key: 'status', label: 'statut' }, { key: 'scope', label: 'portee' }, { label: 'groupe', get: (x) => ref.groupCode(x.group_id) }, { key: 'title', label: 'titre' }, { key: 'body', label: 'texte' }]); }],
      ['calendar', 'target', async () => { data.invalidate('calendar'); return toCSV(await data.get('calendar'), [{ key: 'start_date', label: 'debut' }, { key: 'end_date', label: 'fin' }, { key: 'kind', label: 'type' }, { key: 'title', label: 'titre' }, { label: 'groupe', get: (x) => ref.groupCode(x.group_id) || 'tous' }]); }],
      ['reference', 'book', async () => { const { groups, modules, rooms } = store.get().ref;
        return toCSV([...groups.map((g) => ({ type: 'groupe', code: g.code, nom: g.label })), ...modules.map((m) => ({ type: 'module', code: m.code, nom: m.name })), ...rooms.map((r) => ({ type: 'salle', code: r.kind, nom: r.name }))],
          ['type', 'code', 'nom'].map((k) => ({ key: k, label: k }))); }],
    ];
    mount(el, html`${atop(t('nav.exports'), t('exp.help'))}<div class="gcards">${items.map(([k, ic]) => html`<div class="card stack"><div class="row">${icon(ic, 20)}<b>${t('exp.' + k)}</b></div>
      <p class="muted small">${t('exp.' + k + '_d')}</p><button class="btn ghost" data-x="${k}">${icon('down', 16)} CSV</button></div>`)}</div>
      <div class="card sec"><b>${icon('shield', 16)} ${t('exp.backup_title')}</b><p class="muted small mt-s">${t('exp.backup_body')}</p></div>`);
    on(el, 'click', '[data-x]', (_e, b) => busy(b, async () => { const it = items.find((x) => x[0] === b.dataset.x); download(`campusflow_${it[0]}_${stamp()}.csv`, await it[2]()); }));
  },
};
void tabsBar; void isAdmin;
