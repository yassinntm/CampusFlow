// Assiduité : appel (formateur, surveillance, administration), suivi par groupe avec historique des séances et corrections,
// justificatifs d'absence. Les enregistrements passent par des fonctions serveur qui vérifient le droit sur la séance.
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, ago, fmtNum } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { on, render } from '../../core/router.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, hm, toMin, nowMinutes } from '../../core/dates.js';
import { busy, toast, empty, options, chip } from '../../core/ui.js';
import { effectiveSlots, toCSV, download } from '../../shared/components.js';
import { atop, groupTabs, isTeacher, refreshRef, studentsOf, stamp, rateChip, backLink } from '../ui.js';

const ST = ['present', 'absent', 'late', 'excused'];
const STC = { present: 'green', absent: 'red', late: 'amber', excused: 'blue' };

// ========================= Appel =========================
export const rollView = {
  title: 'nav.roll',
  async render(el, param) {
    await refreshRef('people');
    data.invalidate('sessions', 'exceptions');
    const [slots, sessions, exceptions] = await data.all('slots', 'sessions', 'exceptions');
    const mine = isTeacher() ? slots.filter((s) => s.teacher_id === myId()) : slots;
    if (!param) {
      // Séances des 7 derniers jours (pas d'appel pour un cours futur ni pour une séance annulée ce jour-là)
      const today = todayISO(); const rows = [];
      for (let i = 0; i < 7; i++) {
        const d = addDays(today, -i);
        for (const s of effectiveSlots(mine, exceptions, d)) if (s.status === 'active' && (i > 0 || toMin(s.start_time) <= nowMinutes() + 15)) rows.push({ s, d, se: sessions.find((x) => x.slot_id === s.id && x.session_date === d) });
      }
      const todo = rows.filter((r) => !r.se).length;
      mount(el, html`${atop(t('nav.roll'), t('roll.sub', { n: todo }))}<p class="muted small mb">${t('roll.intro')}</p>
        <div class="stack">${rows.length ? rows.map(({ s, d, se }) => html`<a class="item" href="#/roll/${s.id}|${d}">
          <div class="ii bg-${se ? 'green' : 'amber'}">${icon(se ? 'check' : 'clock', 18)}</div><div class="grow"><div class="item-t">${ref.moduleName(s.module_id)} · ${ref.groupCode(s.group_id)}</div>
          <div class="item-b">${fmtDate(d, { weekday: 'short', day: 'numeric', month: 'short' })} · ${hm(s.start_time)}–${hm(s.end_time)} · ${ref.roomName(s.room_id)}${isTeacher() ? '' : ' · ' + (ref.personName(s.teacher_id) || '—')}</div></div>
          ${chip(se ? t('roll.done') : t('roll.todo'), se ? 'green' : 'amber')}</a>`) : empty(t('roll.nothing'), 'check')}</div>`);
      return;
    }
    const [slotId, date] = param.split('|');
    const slot = slots.find((s) => s.id === slotId);
    if (!slot || !/^\d{4}-\d{2}-\d{2}$/.test(date || '')) { mount(el, html`${backLink('roll')}${empty(t('roll.not_found'), 'alert')}`); return; }
    let sessionId;
    try { sessionId = await rpc('open_session', { p_slot: slotId, p_date: date }); }
    catch (e) { mount(el, html`${backLink('roll')}<div class="warn mt">${icon('alert', 16)} <span>${e.message}</span></div>`); return; }
    data.invalidate('sessions');
    const students = studentsOf(slot.group_id);
    const existing = await q(sb.from('attendance_records').select('student_id,status,minutes_late').eq('session_id', sessionId));
    const state = Object.fromEntries(students.map((p) => [p.id, { status: null, minutes_late: null }]));
    existing.forEach((r) => { if (state[r.student_id]) state[r.student_id] = { status: r.status, minutes_late: r.minutes_late }; });
    const draw = () => {
      const counts = Object.fromEntries(ST.map((k) => [k, Object.values(state).filter((x) => x.status === k).length]));
      const missing = Object.values(state).filter((x) => !x.status).length;
      mount(el, html`${backLink('roll')}
        ${atop(`${ref.moduleName(slot.module_id)} · ${ref.groupCode(slot.group_id)}`, `${fmtDate(date)} · ${hm(slot.start_time)}–${hm(slot.end_time)} · ${ref.roomName(slot.room_id)}`)}
        <div class="row wrap mb">${ST.map((k) => chip(`${t('att.' + k)} ${counts[k]}`, STC[k]))}${missing ? chip(t('roll.missing', { n: missing })) : ''}</div>
        <div class="between wrap"><button class="btn sm ghost" data-all-present>${icon('check', 14)} ${t('roll.all_present')}</button><span class="muted small">${t('roll.count', { n: students.length })}</span></div>
        <div class="stack mt">${students.length ? students.map((p) => html`<div class="att-row"><div class="grow"><b>${p.full_name}</b>
          ${state[p.id].status === 'late' ? html`<label class="small muted row">${t('roll.minutes')} <input class="input xs" type="number" min="1" max="240" data-min="${p.id}" value="${state[p.id].minutes_late ?? ''}"></label>` : ''}</div>
          <div class="att-btns" role="group" aria-label="${p.full_name}">${ST.map((k) => html`<button class="att ${k} ${state[p.id].status === k ? 'on' : ''}" data-st="${k}" data-p="${p.id}" aria-pressed="${state[p.id].status === k}" title="${t('att.' + k)}">${t('att.short_' + k)}</button>`)}</div></div>`)
          : empty(t('roll.no_students'), 'users')}</div>
        <button class="btn primary block mt sticky-save" data-save ${missing === students.length ? 'disabled' : ''}>${icon('check', 16)} ${t('roll.save')}</button>
        <p class="muted small mt-s">${t('roll.note')}</p>`);
    };
    draw();
    on(el, 'click', '[data-st]', (_e, b) => { state[b.dataset.p].status = b.dataset.st; if (b.dataset.st !== 'late') state[b.dataset.p].minutes_late = null; draw(); });
    on(el, 'click', '[data-all-present]', () => { Object.values(state).forEach((x) => { if (!x.status) x.status = 'present'; }); draw(); });
    on(el, 'change', '[data-min]', (_e, i) => { state[i.dataset.min].minutes_late = i.value ? Number(i.value) : null; });
    on(el, 'click', '[data-save]', (_e, b) => busy(b, async () => {
      const recs = Object.entries(state).filter(([, v]) => v.status).map(([student_id, v]) => ({ student_id, status: v.status, minutes_late: v.status === 'late' ? v.minutes_late : null }));
      const n = await rpc('save_attendance', { p_session: sessionId, p_records: recs });
      data.invalidate('attendance', 'summary', 'sessions');
      toast(t('roll.saved', { n }), '', 'ok');
    }));
  },
};

// ========================= Suivi de l'assiduité (par groupe) =========================
const at = { group: '', tab: 'students' };
export const attendanceAdminView = {
  title: 'nav.attendance',
  async render(el) {
    await refreshRef('people');
    data.invalidate('summary', 'sessions');
    const [summary, sessions] = await data.all('summary', 'sessions');
    const groups = store.get().ref.groups;
    if (!at.group && groups.length) at.group = groups[0].id;
    const students = studentsOf(at.group);
    const rows = students.map((p) => ({ p, s: summary.find((x) => x.student_id === p.id) })).sort((a, b) => (a.s?.rate ?? 101) - (b.s?.rate ?? 101));
    const gs = sessions.filter((s) => s.group_id === at.group);
    const tot = rows.reduce((a, r) => a + (r.s?.total || 0), 0), ok = rows.reduce((a, r) => a + (r.s ? r.s.present + r.s.late + r.s.excused : 0), 0);
    const atRisk = rows.filter((r) => r.s?.rate != null && r.s.rate < 80).length;
    let body;
    if (at.tab === 'students') body = html`<div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('auth.full_name')}</th><th>${t('att.rate')}</th><th>${t('att.present')}</th><th>${t('att.absent')}</th><th>${t('att.late')}</th><th>${t('att.excused')}</th><th>${t('att.sessions')}</th></tr></thead>
      <tbody>${rows.map(({ p, s }) => html`<tr><td><b>${p.full_name}</b></td><td>${rateChip(s?.rate ?? null)}</td><td>${s?.present ?? 0}</td><td class="red b6">${s?.absent ?? 0}</td><td class="amber b6">${s?.late ?? 0}</td><td>${s?.excused ?? 0}</td><td>${s?.total ?? 0}</td></tr>`)}</tbody></table></div>
      ${rows.length ? '' : empty(t('att.no_students'), 'users')}</div>`;
    else body = html`<div class="card tcard"><div class="scroll-x"><table class="table"><thead><tr><th>${t('common.date')}</th><th>${t('common.module')}</th><th>${t('common.teacher')}</th><th>${t('att.status_col')}</th><th></th></tr></thead>
      <tbody>${gs.map((s) => html`<tr><td class="nowrap">${fmtDate(s.session_date, { weekday: 'short', day: 'numeric', month: 'short' })} · ${hm(s.start_time)}</td><td>${ref.moduleName(s.module_id)}</td><td>${ref.personName(s.teacher_id) || '—'}</td>
        <td>${chip(t('att.session_' + s.status), s.status === 'held' ? 'green' : 'red')}</td>
        <td class="text-end">${s.slot_id && s.status === 'held' ? html`<a class="btn sm ghost" href="#/roll/${s.slot_id}|${s.session_date}">${icon('edit', 14)} ${t('att.correct')}</a>` : ''}</td></tr>`)}</tbody></table></div>
      ${gs.length ? '' : empty(t('att.no_sessions'), 'cal')}</div>`;
    mount(el, html`${atop(t('nav.attendance'), t('att.admin_help', { n: gs.length }), html`<a class="btn ghost" href="#/justifications">${icon('shield', 16)} ${t('nav.justifications')}</a><button class="btn ghost" data-export>${icon('down', 16)} CSV</button>`)}
      ${groupTabs(groups, at.group)}
      <div class="kpis mt"><div class="stat"><span>${t('admin.k_rate')}</span><b>${tot ? fmtNum(Math.round((1000 * ok) / tot) / 10) + ' %' : '—'}</b></div>
        <div class="stat"><span>${t('att.sessions')}</span><b>${gs.length}</b></div><div class="stat"><span>${t('att.at_risk')}</span><b ${atRisk ? 'style="color:var(--red)"' : ''}>${atRisk}</b></div>
        <div class="stat"><span>${t('admin.k_students')}</span><b>${students.length}</b></div></div>
      <div class="seg mt mb">${['students', 'sessions'].map((k) => html`<button class="${at.tab === k ? 'on' : ''}" data-tab="${k}">${t('att.tab_' + k)}</button>`)}</div>${body}`);
    on(el, 'click', '[data-g]', (_e, b) => { at.group = b.dataset.g; render(); });
    on(el, 'click', '[data-tab]', (_e, b) => { at.tab = b.dataset.tab; render(); });
    on(el, 'click', '[data-export]', (_e, b) => busy(b, async () => {
      const recs = await q(sb.from('attendance_records').select('session_id,student_id,status,minutes_late,note').in('session_id', gs.map((s) => s.id)));
      const by = Object.fromEntries(gs.map((s) => [s.id, s]));
      download(`assiduite_${ref.groupCode(at.group)}_${stamp()}.csv`, toCSV(recs, [{ label: 'date', get: (r) => by[r.session_id].session_date }, { label: 'debut', get: (r) => hm(by[r.session_id].start_time) },
        { label: 'module', get: (r) => ref.moduleName(by[r.session_id].module_id) }, { label: 'stagiaire', get: (r) => ref.personName(r.student_id) }, { key: 'status', label: 'statut' },
        { key: 'minutes_late', label: 'retard_min' }, { key: 'note', label: 'note' }]));
    }));
  },
};

// ========================= Justificatifs =========================
const jf = { filter: 'pending' };
export const justificationsView = {
  title: 'nav.justifications',
  async render(el) {
    data.invalidate('justifications');
    const [justifs, sessions] = await data.all('justifications', 'sessions');
    const bySession = Object.fromEntries(sessions.map((s) => [s.id, s]));
    const list = justifs.filter((j) => (jf.filter === 'pending' ? j.status === 'pending' : j.status !== 'pending'));
    mount(el, html`${atop(t('nav.justifications'), t('justif.sub', { n: justifs.filter((j) => j.status === 'pending').length }))}
      <div class="seg mb">${['pending', 'reviewed'].map((f) => html`<button class="${jf.filter === f ? 'on' : ''}" data-f="${f}">${t('justif.f_' + f)}</button>`)}</div>
      <div class="stack">${list.length ? list.map((j) => { const s = bySession[j.session_id];
        return html`<div class="item"><div class="ii bg-amber">${icon('shield', 18)}</div><div class="grow"><div class="item-t">${ref.personName(j.student_id) || '—'} · ${ref.groupCode(s?.group_id)}</div>
          <div class="item-b">${s ? html`${ref.moduleName(s.module_id)} · ${fmtDate(s.session_date, { weekday: 'short', day: 'numeric', month: 'short' })} · ${hm(s.start_time)}` : ''}</div>
          <div class="item-b pre">« ${j.reason} »</div><div class="muted small mt-s">${ago(j.created_at)}</div>
          ${j.status === 'pending' ? html`<div class="row mt"><button class="btn sm primary" data-review="${j.session_id}|${j.student_id}|1">${icon('check', 14)} ${t('justif.accept')}</button>
            <button class="btn sm danger" data-review="${j.session_id}|${j.student_id}|0">${icon('x', 14)} ${t('justif.reject')}</button></div>`
          : html`<div class="mt-s">${chip(t('justif.' + j.status), j.status === 'accepted' ? 'green' : 'red')}${j.reviewed_by ? html` <span class="xs muted">${ref.personName(j.reviewed_by)}</span>` : ''}</div>`}</div></div>`; })
        : empty(t('justif.none'), 'shield')}</div><p class="muted small mt">${t('justif.policy')}</p>`);
    on(el, 'click', '[data-f]', (_e, b) => { jf.filter = b.dataset.f; render(); });
    on(el, 'click', '[data-review]', (_e, b) => busy(b, async () => {
      const [s, st, ok] = b.dataset.review.split('|');
      await rpc('review_justification', { p_session: s, p_student: st, p_accept: ok === '1' });
      data.invalidate('justifications', 'attendance', 'summary'); render(); toast(t(ok === '1' ? 'justif.accepted' : 'justif.rejected'), '', 'ok');
    }));
  },
};
void options;
