// Vue d'ensemble — reprend la console de la démo : KPI, cartes par groupe (version, taux de lecture, brouillon), journal d'activité.
// Les formateurs ont un tableau de bord dédié : séances du jour (appel), rendus à corriger, échéances.
import { html, mount } from '../../core/html.js';
import { icon } from '../../core/icons.js';
import { t, fmtDate, fmtInstant, ago, fmtNum } from '../../core/i18n.js';
import { store, ref, myId } from '../../core/store.js';
import { sb, q, rpc } from '../../services/api.js';
import { data } from '../../services/data.js';
import { todayISO, addDays, mondayOf, isoOfInstant, toMin, nowMinutes } from '../../core/dates.js';
import { empty } from '../../core/ui.js';
import { slotCard, effectiveSlots, assignItem } from '../../shared/components.js';
import { atop, isAdmin, isTeacher, refreshRef, myPairs } from '../ui.js';

const actLabel = (a) => { const [base, sub] = String(a).split(':'); const k = 'audit.a_' + base; const v = t(k); return v === k ? a : v + (sub ? ` (${sub})` : ''); };
export { actLabel };

export const overviewView = {
  title: 'nav.overview',
  async render(el) {
    if (isTeacher()) return teacherHome(el);
    await refreshRef('people');
    const today = todayISO();
    const [rep, assessments, anns, notifs, justifs, sessions] = await Promise.all([rpc('admin_reports'), data.get('assessments'), data.get('announcements'),
      data.get('sent'), data.get('justifications'), data.get('sessions')]);
    const mon = mondayOf(today), sat = addDays(mon, 6);
    const week = assessments.filter((a) => { const d = isoOfInstant(a.due_at); return d >= mon && d <= sat; }).length;
    const pendingDrafts = rep.groups.reduce((n, g) => n + (g.drafts ? 1 : 0), 0);
    // Taux de lecture des 30 derniers jours, par groupe (notifications collectives seulement)
    const recent = notifs.filter((n) => n.target_kind !== 'user' && new Date(n.created_at) > new Date(Date.now() - 30 * 864e5));
    const stats = recent.length ? await rpc('notification_stats', { p_ids: recent.map((n) => n.id) }) : [];
    const byId = Object.fromEntries(stats.map((s) => [s.id, s]));
    const readRate = (gid, students) => {
      // notifications envoyées à ce groupe uniquement : lectures / stagiaires actifs du groupe
      const ns = recent.filter((n) => n.target_kind === 'group' && n.group_id === gid);
      if (!ns.length || !students) return null;
      const r = ns.reduce((a, n) => a + (byId[n.id]?.reads || 0), 0), aud = ns.reduce((a, n) => a + (byId[n.id]?.audience || 0), 0);
      return aud ? Math.min(100, Math.round((100 * r) / aud)) : null;
    };
    const audit = isAdmin() ? await q(sb.from('audit_log').select('id,at,actor_id,action,entity').order('at', { ascending: false }).limit(10)) : [];
    const tot = rep.groups.reduce((a, g) => a + g.records, 0), ok = rep.groups.reduce((a, g) => a + g.present, 0);
    const kpi = (label, v, to, color = '') => html`<a class="stat" href="#/${to}"><span>${label}</span><b ${color ? `style="color:var(--${color})"` : ''}>${v}</b></a>`;
    mount(el, html`${atop(t('nav.overview'), fmtDate(today), html`<a class="btn ghost" href="#/notify">${icon('send', 18)} ${t('admin.notify_btn')}</a>
        ${isAdmin() ? html`<a class="btn primary" href="#/timetable">${icon('cal', 18)} ${t('admin.manage_tt')}</a>` : html`<a class="btn primary" href="#/roll">${icon('check', 18)} ${t('nav.roll')}</a>`}`)}
      <div class="kpis">
        ${kpi(t('admin.k_students'), rep.people?.student || 0, 'students')}
        ${kpi(t('admin.k_due_week'), week, isAdmin() ? 'assessments' : 'reports')}
        ${kpi(t('admin.k_announcements'), anns.filter((a) => a.status === 'published').length, 'announcements')}
        ${kpi(t('admin.k_drafts'), pendingDrafts, isAdmin() ? 'timetable' : 'reports', pendingDrafts ? 'amber' : 'green')}
      </div>
      <div class="kpis mt-s">
        ${kpi(t('admin.k_rate'), tot ? fmtNum(Math.round((1000 * ok) / tot) / 10) + ' %' : '—', 'attendance')}
        ${kpi(t('admin.k_sessions_today'), sessions.filter((s) => s.session_date === today).length, 'roll')}
        ${kpi(t('admin.k_justifs'), justifs.filter((j) => j.status === 'pending').length, 'justifications', justifs.some((j) => j.status === 'pending') ? 'amber' : '')}
        ${kpi(t('admin.k_reports'), rep.moderation.open, 'moderation', rep.moderation.open ? 'red' : '')}
      </div>
      <div class="sec gcards">${rep.groups.map((g) => { const rate = readRate(g.id, g.students);
        return html`<div class="card stack"><div class="between"><h2>${g.code}</h2>${g.version ? html`<span class="chip green">${icon('shield', 12)} ${t('sched.official')}</span>` : html`<span class="chip amber">${t('admin.no_tt')}</span>`}</div>
          <div class="grid2"><div><div class="xs muted">${t('admin.k_students')}</div><b>${g.students}</b></div><div><div class="xs muted">${t('admin.per_week')}</div><b>${g.slots}</b></div>
            <div><div class="xs muted">${t('admin.version')}</div><b>${g.version ? 'v' + g.version : '—'}</b></div><div><div class="xs muted">${t('admin.read_rate')}</div><b>${rate == null ? '—' : rate + ' %'}</b></div></div>
          <div class="xs muted">${g.published_at ? t('admin.published_ago', { when: ago(g.published_at) }) : t('admin.never_published')}</div>
          ${g.drafts ? html`<span class="chip amber">${t('admin.draft_open', { n: g.drafts })}</span>` : g.version ? html`<span class="chip green">${icon('check', 12)} ${t('admin.up_to_date')}</span>` : ''}
          <a class="btn sm ghost" href="#/timetable/${g.id}">${isAdmin() ? t('admin.open_editor') : t('admin.open_tt')} ${icon('chev', 16, 'class="flip"')}</a></div>`; })}</div>
      ${isAdmin() ? html`<div class="sec card"><div class="between"><h2>${t('admin.activity')}</h2><a class="link" href="#/audit">${t('common.see_all')}</a></div>
        ${audit.length ? audit.map((a) => html`<div class="audit"><span class="muted">${icon('hist', 16)}</span><span class="grow"><b>${ref.personName(a.actor_id) || t('admin.system')}</b> · ${actLabel(a.action)} · ${a.entity}</span><span class="xs muted">${ago(a.at)}</span></div>`) : empty(t('audit.none'), 'hist')}</div>`
      : html`<div class="sec card"><h2>${t('admin.recent_sent')}</h2>${recent.slice(0, 8).map((n) => html`<div class="audit"><span class="muted">${icon('send', 16)}</span><span class="grow"><b>${n.title}</b></span><span class="xs muted">${ago(n.created_at)}</span></div>`)}
        ${recent.length ? '' : empty(t('notif.none'), 'bell')}</div>`}`);
  },
};

async function teacherHome(el) {
  const today = todayISO();
  const [slots, exceptions, sessions, justifs, assessments, submissions] = await data.all('slots', 'exceptions', 'sessions', 'justifications', 'assessments', 'submissions');
  const pairs = await myPairs();
  const mine = slots.filter((s) => s.teacher_id === myId());
  const todays = effectiveSlots(mine, exceptions, today);
  const done = new Set(sessions.filter((s) => s.session_date === today).map((s) => s.slot_id));
  const myAssess = assessments.filter((a) => a.created_by === myId() || pairs.some((p) => p.group_id === a.group_id && p.module_id === a.module_id));
  const toReview = submissions.filter((s) => !s.feedback_at && myAssess.some((a) => a.id === s.assessment_id));
  const upcoming = myAssess.filter((a) => new Date(a.due_at) > new Date()).slice(0, 4);
  const groups = new Set(pairs.map((p) => p.group_id));
  mount(el, html`${atop(t('home.hello', { name: (store.get().profile.full_name || '').split(' ')[0] }), fmtDate(today), html`<a class="btn primary" href="#/roll">${icon('check', 18)} ${t('nav.roll')}</a>`)}
    ${!pairs.length ? html`<div class="warn mb">${icon('alert', 16)} <span>${t('teach.no_groups')}</span></div>` : ''}
    <div class="kpis"><div class="stat"><span>${t('teach.today_sessions')}</span><b>${todays.filter((s) => s.status === 'active').length}</b></div>
      <div class="stat"><span>${t('teach.groups')}</span><b>${groups.size}</b></div>
      <a class="stat" href="#/assessments"><span>${t('teach.to_review')}</span><b ${toReview.length ? 'style="color:var(--amber)"' : ''}>${toReview.length}</b></a>
      <a class="stat" href="#/justifications"><span>${t('teach.pending_justifs')}</span><b>${justifs.filter((j) => j.status === 'pending').length}</b></a></div>
    <div class="grid-admin sec">
      <section class="card"><h2>${t('home.today')}</h2><div class="stack mt-s">${todays.length ? todays.map((s) => slotCard(s, { date: today, showGroup: true,
        actions: s.status === 'active' && toMin(s.start_time) <= nowMinutes() + 15 ? html`<a class="btn sm ${done.has(s.id) ? 'ghost' : 'primary'}" href="#/roll/${s.id}|${today}">${icon('check', 14)} ${done.has(s.id) ? t('roll.edit') : t('roll.take')}</a>` : '' }))
        : empty(t('home.no_class_today'), 'coffee')}</div></section>
      <section class="card"><div class="between"><h2>${t('teach.my_assessments')}</h2><a class="link" href="#/assessments">${t('common.see_all')}</a></div>
        <div class="stack mt-s">${upcoming.length ? upcoming.map((a) => assignItem(a)) : empty(t('home.no_deadline'), 'check')}</div></section></div>`);
}
