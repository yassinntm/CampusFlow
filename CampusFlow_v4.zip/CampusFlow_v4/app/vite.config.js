import { defineConfig } from 'vite';
import { fileURLToPath } from 'url';

// Deux applications, un seul projet et un seul backend :
//   /        → CampusFlow Stagiaire  (index.html)
//   /admin/  → CampusFlow Administration (admin/index.html)
// Mode « e2e » : le client Supabase est remplacé par un faux client relié à la base de test PGlite (tests uniquement).
export default defineConfig(({ mode }) => ({
  base: './',
  plugins: [{
    name: 'csp-e2e',
    transformIndexHtml: (h) => h.replace('%E2E_CONNECT%', mode === 'e2e' ? ' http://localhost:* ws://localhost:*' : ''),
  }],
  build: {
    target: 'es2022',
    sourcemap: mode !== 'production',
    rollupOptions: {
      input: {
        student: fileURLToPath(new URL('./index.html', import.meta.url)),
        admin: fileURLToPath(new URL('./admin/index.html', import.meta.url)),
      },
    },
  },
  resolve: mode === 'e2e'
    ? { alias: { '@supabase/supabase-js': fileURLToPath(new URL('../tests/e2e/fake-supabase.js', import.meta.url)) } }
    : {},
}));
