// Service worker CampusFlow : met en cache UNIQUEMENT l'interface (HTML/JS/CSS/icônes du même domaine).
// Les appels à Supabase (données personnelles, jetons) ne passent jamais par ce cache.
const VERSION = 'cf-v4.0.0';
// Deux applications : Stagiaire (./) et Administration (./admin/) — chaque page est mise en cache sous sa propre adresse
const SHELL = ['./', './index.html', './admin/', './admin/index.html', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;          // Supabase, polices, etc. : réseau direct
  if (req.mode === 'navigate') {                                                     // page : réseau d'abord, sinon version en cache
    const admin = url.pathname.includes('/admin/');
    e.respondWith(fetch(req).then((r) => { if (r.ok) { const copy = r.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); } return r; })
      .catch(() => caches.match(req, { ignoreSearch: true }).then((hit) => hit || caches.match(admin ? './admin/index.html' : './index.html'))));
    return;
  }
  if (url.pathname.includes('/assets/') || url.pathname.includes('/icons/')) {        // fichiers versionnés : cache d'abord
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((r) => { if (r.ok) { const copy = r.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); } return r; })));
  }
});
